﻿CREATE VIEW [stg].[DrillingInfoPermits_V]
WITH SCHEMABINDING, VIEW_METADATA
AS
SELECT
		[API10]						= CASE WHEN (ISNUMERIC([t].[API10]) = 1) THEN CONVERT(BIGINT, [t].[API10]) END,

	[t].[API12],
	[t].[Abstract],
	[t].[ActiveCommonName],
	[t].[ActiveTickerName],

		[AmendmentFiledDate]		= CONVERT(DATE, [t].[AmendmentFiledDate], 127),
		[ApprovedDate]				= CONVERT(DATE, [t].[ApprovedDate], 127),

	[t].[Block],
	[t].[BottomHoleLatitudeWGS84],
	[t].[BottomHoleLongitudeWGS84],
	[t].[ContactName],
	[t].[ContactPhone],
	[t].[CountyParish],

		[CreatedDate]				= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[CreatedDate], 127), '-06:00'),

	[t].[DIBasin],
	[t].[DICountryCode],
	[t].[DICountryName],
	[t].[DICountyParishName],
	[t].[DIPlay],
	[t].[DIStateProvinceCode],
	[t].[DIStateProvinceName],
	[t].[DISubPlay],

		[DeletedDate]				= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[DeletedDate], 127), '-06:00'),

	[t].[District],
	[t].[DrillType],

		[ExpiredDate]				= CONVERT(DATE, [t].[ExpiredDate], 127),

	[t].[Field],
	[t].[Formation],
	[t].[H2SArea],
	[t].[LeaseName],
	[t].[LeaseNumber],
	[t].[OFSRegion],
	[t].[OperatorAddress],
	[t].[OperatorAlias],
	[t].[OperatorCity],
	[t].[OperatorCity30mi],
	[t].[OperatorCity50mi],
	[t].[OperatorState],
	[t].[OperatorZip],

		[OrigApprovedDate]			= CONVERT(DATE, [t].[OrigApprovedDate], 127),

	[t].[PermitDepth],
	[t].[PermitDepthUOM],
	[t].[PermitID],
	[t].[PermitNumber],
	[t].[PermitStatus],
	[t].[PermitType],
	[t].[Range],
	[t].[ReportedOperator],
	[t].[Section],
	[t].[StateProvince],

		[SubmittedDate]				= CONVERT(DATE, [t].[SubmittedDate], 127),

	[t].[SurfaceLatitudeWGS84],
	[t].[SurfaceLongitudeWGS84],
	[t].[Survey],
	[t].[Township],
	[t].[TrueVerticalDepth],
	[t].[TrueVerticalDepthUOM],

		[UpdatedDate]				= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[UpdatedDate], 127), '-06:00'),

	[t].[WGID],
	[t].[WellNumber],
	[t].[WellStatus],
	[t].[WellType],
	[t].[txUrlLinkSuffix]
FROM
	[stg].[DrillingInfoPermits]		[t]	WITH (NOLOCK);
