﻿CREATE VIEW [stg].[DrillingInfoDealsForSale_V]
WITH SCHEMABINDING, VIEW_METADATA
AS
SELECT
	[t].[AcresNetUndeveloped],
	[t].[Assets],

		[BidDeadline]						= CONVERT(DATE, [t].[BidDeadline], 127),

	[t].[Blocks],							--	Semicolon delimited
	[t].[Country],
	[t].[CountyParish],

		[CreatedDate]						= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[CreatedDate], 127), '-06:00'),

	[t].[DIBasin],

		[DateAnnounced]						= CONVERT(DATE, [t].[DateAnnounced], 127),

	[t].[DealHighlights],
	[t].[DealStatus],
	[t].[DealType],

	[t].[DealsForSaleID],

	[t].[DealsForSaleNotes],

		[DeletedDate]						= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[DeletedDate], 127), '-06:00'),

	[t].[Geometry],
	[t].[Headline],
	[t].[Hydrocarbon],

	[t].[Latitude],
	[t].[Licenses],
	[t].[Longitude],

	[t].[OnshoreOffshore],
	[t].[OpNonOp],
	[t].[OperatorCompanyName],
	[t].[OperatorTicker],

	[t].[ProductionMBOEDGross],
	[t].[ProductionMBOEDNet],
	[t].[ProductionPercentOil],

	[t].[Region],

	[t].[Reserves2PMMBOEGross],
	[t].[Reserves2PPercentOil],
	[t].[ReservesProvedMMBOEGross],
	[t].[ReservesProvedMMBOENet],
	[t].[ReservesProvedPercentOil],

	[t].[ResourceType],

	[t].[Sellers],
	[t].[SellersFinancialAdvisors],
	[t].[SellersPeerGroup],
	[t].[State],							--	Comma Delimited
	[t].[TransactionType],

	[t].[USPlay],
	[t].[USRegion],
	[t].[USSubRegion],

		[UpdatedDate]						= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[UpdatedDate], 127), '-06:00'),

	[t].[ValueRangeMM],

	[t].[txUrlLinkSuffix]
FROM
	[stg].[DrillingInfoDealsForSale]		[t]	WITH (NOLOCK);