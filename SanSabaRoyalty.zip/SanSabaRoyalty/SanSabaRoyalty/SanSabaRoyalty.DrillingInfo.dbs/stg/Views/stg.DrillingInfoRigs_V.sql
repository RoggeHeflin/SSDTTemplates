﻿CREATE VIEW [stg].[DrillingInfoRigs_V]
WITH SCHEMABINDING, VIEW_METADATA
AS
SELECT
		[API10]							= CASE WHEN (ISNUMERIC([t].[API10]) = 1) THEN CONVERT(BIGINT, [t].[API10]) ELSE NULL END,

	[t].[Abstract],
	[t].[Block],
	[t].[ContractorAddress],
	[t].[ContractorCity],
	[t].[ContractorContact],
	[t].[ContractorEmail],
	[t].[ContractorName],
	[t].[ContractorPhone],
	[t].[ContractorState],
	[t].[ContractorWebsite],
	[t].[ContractorZip],

		[CreatedDate]					= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[CreatedDate], 127), '-06:00'),

	[t].[DIBasin],
	[t].[DICountryCode],
	[t].[DICountryName],
	[t].[DICountyParishName],
	[t].[DIPlay],
	[t].[DIStateProvinceCode],
	[t].[DIStateProvinceName],
	[t].[DISubPlay],
	[t].[DataSource],

		[DeletedDate]					= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[DeletedDate], 127), '-06:00'),

	[t].[DirectionsToLocation],
	[t].[District],
	[t].[DrawWorks],
	[t].[DrillType],
	[t].[Field],
	[t].[Formation],
	[t].[FormationDepth],
	[t].[H2SArea],
	[t].[LandOffshore],
	[t].[LeaseName],
	[t].[MajorCity30mi],
	[t].[MajorCity50mi],
	[t].[Mobility],
	[t].[OFSRegion],
	[t].[OperatorAddress],
	[t].[OperatorAlias],
	[t].[OperatorCity],
	[t].[OperatorCompanyName],
	[t].[OperatorContact],
	[t].[OperatorPhone],
	[t].[OperatorState],
	[t].[OperatorTicker],
	[t].[OperatorZip],

		[PermitAmendedDate]				= CONVERT(DATE, [t].[PermitAmendedDate], 127),
		[PermitApprovedDate]			= CONVERT(DATE, [t].[PermitApprovedDate], 127),

	[t].[PermitBHLatitudeWGS84],
	[t].[PermitBHLongitudeWGS84],
	[t].[PermitDepth],
	[t].[PermitLatitudeWGS84],
	[t].[PermitLongitudeWGS84],
	[t].[PermitNumber],

		[PermitOriginalApprovedDate]	= CONVERT(DATE, [t].[PermitOriginalApprovedDate], 127),
		[PermitPostedDate]				= CONVERT(DATE, [t].[PermitPostedDate], 127),

	[t].[PermitType],
	[t].[PowerType],
	[t].[Range],
	[t].[RatedHP],
	[t].[RatedWaterDepth],
	[t].[ReportedOperator],
	[t].[RigID],
	[t].[RigLatitudeWGS84],
	[t].[RigLongitudeWGS84],
	[t].[RigNameNumber],
	[t].[Section],

		[SpudDate]						= CONVERT(DATE, [t].[SpudDate], 127),

	[t].[Survey],
	[t].[TemporaryLocation],
	[t].[Township],
	[t].[TrueVerticalDepth],

		[UpdatedDate]					= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[UpdatedDate], 127), '-06:00'),

	[t].[WellNumber],
	[t].[WellType],
	[t].[txUrlLinkSuffix]
FROM
	[stg].[DrillingInfoRigs]	[t]	WITH (NOLOCK);