﻿CREATE VIEW [stg].[DrillingInfoLeasesLandtrac_V]
WITH SCHEMABINDING, VIEW_METADATA
AS
SELECT
	[t].[AreaAcres],
	[t].[BLM],
	[t].[Bonus],

	[t].[CentroidLatitude],
	[t].[CentroidLongitude],
	[t].[CountyParish],

		[CreatedDate]						= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[CreatedDate], 127), '-06:00'),

	[t].[DIBasin],
	[t].[DILink],
	[t].[DIPlay],
	[t].[DISubplay],

		[DeletedDate]						= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[DeletedDate], 127), '-06:00'),

	[t].[DepthClauseAvailable],
	[t].[DepthClauseTypes],
		[EffectiveDate]						= CONVERT(DATE, [t].[EffectiveDate], 127),
		[ExpirationofPrimaryTerm]			= CONVERT(DATE, [t].[ExpirationofPrimaryTerm], 127),

	[t].[ExtBonus],
	[t].[ExtTermMonths],

	[t].[Geometry],

	[t].[Grantee],
	[t].[GranteeAddress],
	[t].[GranteeAlias],

	[t].[Grantor],
	[t].[GrantorAddress],

		[InstrumentDate]					= CONVERT(DATE, [t].[InstrumentDate], 127),
	[t].[InstrumentType],

	[t].[LeaseId],

		[MajorityAssignmentEffectiveDate]	= CONVERT(DATE, [t].[MajorityAssignmentEffectiveDate], 127),
	[t].[MajorityAssignmentVolPage],
	[t].[MajorityLegalAssignee],
	[t].[MajorityLegalAssigneeInterest],

	[t].[MaxDepth],
	[t].[MinDepth],

	[t].[Nomination],
	[t].[OptionsExtensions],

		[RecordDate]						= CONVERT(DATE, [t].[RecordDate], 127),
	[t].[RecordNo],
	[t].[Remarks],
	[t].[Royalty],
	[t].[SpatialAssignee],
	[t].[State],
	[t].[StateLease],
	[t].[TermMonths],

		[UpdatedDate]						= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[UpdatedDate], 127), '-06:00'),

	[t].[VolPage],
	[t].[txUrlLinkSuffix]
FROM
	[stg].[DrillingInfoLeasesLandtrac]		[t]	WITH (NOLOCK);