﻿CREATE VIEW [stg].[DrillingInfoWells_V]
WITH SCHEMABINDING, VIEW_METADATA
AS
SELECT
	[t].[Abstract],
	[t].[Basin],
	[t].[Confidential],
		[ConfidentialDate]			= CONVERT(DATE, [t].[ConfidentialDate], 127),
	[t].[Country],
	[t].[County],

		[CreatedDate]				= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[CreatedDate], 127), '-06:00'),

	[t].[CurrentOperator],
	[t].[CurrentStatus],
		[CurrentStatusDate]			= CONVERT(DATE, [t].[CurrentStatusDate], 127),

		[DeletedDate]				= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[DeletedDate], 127), '-06:00'),

	[t].[DepthUom],
	[t].[District],

	[t].[ElevRefDatum],
	[t].[ElevRefDatumepsgCode],
	[t].[ElevUom],
	[t].[Environment],

	[t].[Field],
	[t].[FluidType],

	[t].[Formation],
	[t].[GovernmentID],
	[t].[GroundElev],
	[t].[GroundElevationType],
	[t].[InitialClassification],

	[t].[LeaseName],
	[t].[LeaseNumber],

		[LicenseDate]				= CONVERT(DATE, [t].[LicenseDate], 127),
		[OnProductionDate]			= CONVERT(DATE, [t].[OnProductionDate], 127),

	[t].[OperatorCompanyName],
	[t].[OperatorTicker],
	[t].[OriginalOperator],

	[t].[PermitNumber],
	[t].[ProvinceState],

	[t].[Range],
	[t].[RangeDirection],
	[t].[Region],
	[t].[Remark],

	[t].[Section],
	[t].[Source],
		[SpudDate]					= CONVERT(DATE, [t].[SpudDate], 127),
	[t].[SpudDateSource],

	[t].[TopLevelCommonName],
	[t].[Township],
	[t].[TownshipDirection],
	[t].[UID],

		[UpdatedDate]				= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[UpdatedDate], 127), '-06:00'),

	[t].[WaterDepth],
	[t].[WaterDepthDatum],
	[t].[WellName],
	[t].[WellNumber],
	[t].[Wgs84Latitude],
	[t].[Wgs84Longitude],
	[t].[txUrlLinkSuffix]
FROM
	[stg].[DrillingInfoWells]		[t]	WITH (NOLOCK);