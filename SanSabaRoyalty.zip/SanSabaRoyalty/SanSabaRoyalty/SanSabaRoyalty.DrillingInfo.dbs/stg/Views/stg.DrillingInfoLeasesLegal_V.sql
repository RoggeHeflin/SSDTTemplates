﻿CREATE VIEW [stg].[DrillingInfoLeasesLegal_V]
WITH SCHEMABINDING, VIEW_METADATA
AS
SELECT
	[t].[Abstract],
	[t].[AbstractNo],
	[t].[AreaAcres],
	[t].[BLM],
	[t].[Block],
	[t].[Bonus],
	[t].[CountyParish],

		[Created]							= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[Created], 127), '-06:00'),
		[CreatedDate]						= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[CreatedDate], 127), '-06:00'),

	[t].[DIBasin],
	[t].[DILink],
	[t].[DIPlay],
	[t].[DISubplay],

		[DeletedDate]						= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[DeletedDate], 127), '-06:00'),

		[EffectiveDate]						= CONVERT(DATE, [t].[EffectiveDate], 127),
		[ExpirationofPrimaryTerm]			= CONVERT(DATE, [t].[ExpirationofPrimaryTerm], 127),
	[t].[ExtBonus],
	[t].[ExtTermMonths],

	[t].[Geometry],

	[t].[Grantee],
	[t].[GranteeAddress],
	[t].[GranteeAlias],
	[t].[Grantor],
	[t].[GrantorAddress],

		[InstrumentDate]					= CONVERT(DATE, [t].[InstrumentDate], 127),
	[t].[InstrumentType],

	[t].[LatitudeWGS84],
	[t].[LeaseCount],
	[t].[LeaseCountSymbol],
	[t].[LeaseId],
	[t].[LongitudeWGS84],

		[MajorityAssignmentEffectiveDate]	= CONVERT(DATE, [t].[MajorityAssignmentEffectiveDate], 127),
	[t].[MajorityAssignmentVolPage],
	[t].[MajorityLegalAssignee],
	[t].[MajorityLegalAssigneeInterest],

	[t].[MappingID],
	[t].[MaxDepth],
	[t].[MinDepth],

	[t].[Nomination],
	[t].[OptionsExtensions],
	[t].[PolygonGroupID],
	[t].[QuarterCalls],

	[t].[Range],
	[t].[RangeDirection],

		[RecordDate]						= CONVERT(DATE, [t].[RecordDate], 127),
	[t].[RecordNo],
	[t].[Remarks],
	[t].[Royalty],
	[t].[Section],

	[t].[State],

	[t].[StateLease],
	[t].[SurveyName],
	[t].[TermMonths],
	[t].[Township],
	[t].[TownshipDirection],

		[Updated]							= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[Updated], 127), '-06:00'),
		[UpdatedDate]						= SWITCHOFFSET(CONVERT(DATETIMEOFFSET(4), [t].[UpdatedDate], 127), '-06:00'),

	[t].[VolPage],
	[t].[txUrlLinkSuffix]
FROM
	[stg].[DrillingInfoLeasesLegal]		[t]	WITH (NOLOCK);