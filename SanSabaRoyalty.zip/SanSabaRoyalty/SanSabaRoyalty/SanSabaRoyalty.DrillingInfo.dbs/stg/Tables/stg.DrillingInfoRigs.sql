﻿CREATE TABLE [stg].[DrillingInfoRigs]
(
	[DrillingInfoRigsId]			INT					NOT	NULL	IDENTITY(1,1)	NOT FOR REPLICATION,

	[API10]							BIGINT					NULL,
	[Abstract]						VARCHAR(8)				NULL,
	[Block]							VARCHAR(48)				NULL,

	[ContractorAddress]				VARCHAR(96)				NULL,
	[ContractorCity]				VARCHAR(24)				NULL,
	[ContractorContact]				VARCHAR(24)				NULL,
	[ContractorEmail]				VARCHAR(254)			NULL,
	[ContractorName]				VARCHAR(96)				NULL,
	[ContractorPhone]				VARCHAR(32)				NULL,
	[ContractorState]				CHAR(2)					NULL,
	[ContractorWebsite]				VARCHAR(64)				NULL,
	[ContractorZip]					VARCHAR(10)				NULL,

	[CreatedDate]					VARCHAR(28)			NOT	NULL,	--	DATE

	[DIBasin]						VARCHAR(168)			NULL,
	[DICountryCode]					CHAR(2)					NULL,
	[DICountryName]					VARCHAR(80)				NULL,
	[DICountyParishName]			VARCHAR(32)				NULL,
	[DIPlay]						VARCHAR(96)				NULL,
	[DIStateProvinceCode]			CHAR(2)					NULL,
	[DIStateProvinceName]			VARCHAR(80)				NULL,
	[DISubPlay]						VARCHAR(96)				NULL,

	[DataSource]					VARCHAR(16)				NULL,

	[DeletedDate]					VARCHAR(28)				NULL,	--	DATE

	[DirectionsToLocation]			VARCHAR(MAX)			NULL,

	[District]						VARCHAR(8)				NULL,
	[DrawWorks]						VARCHAR(40)				NULL,
	[DrillType]						VARCHAR(8)				NULL,
	[Field]							VARCHAR(56)				NULL,
	[Formation]						VARCHAR(256)			NULL,
	[FormationDepth]				INT						NULL,
	[H2SArea]						VARCHAR(8)				NULL,
	[LandOffshore]					VARCHAR(8)				NULL,
	[LeaseName]						VARCHAR(56)				NULL,
	[MajorCity30mi]					VARCHAR(24)				NULL,
	[MajorCity50mi]					VARCHAR(24)				NULL,
	[Mobility]						VARCHAR(16)				NULL,

	[OFSRegion]						VARCHAR(48)				NULL,

	[OperatorAddress]				VARCHAR(96)				NULL,
	[OperatorAlias]					VARCHAR(56)				NULL,
	[OperatorCity]					VARCHAR(24)				NULL,
	[OperatorCompanyName]			VARCHAR(128)			NULL,
	[OperatorContact]				VARCHAR(48)				NULL,
	[OperatorPhone]					VARCHAR(32)				NULL,
	[OperatorState]					CHAR(2)					NULL,
	[OperatorTicker]				VARCHAR(16)				NULL,
	[OperatorZip]					VARCHAR(10)				NULL,

	[PermitAmendedDate]				VARCHAR(28)				NULL,	--	DATE
	[PermitApprovedDate]			VARCHAR(28)				NULL,	--	DATE
	[PermitBHLatitudeWGS84]			DECIMAL(10, 8)			NULL,
	[PermitBHLongitudeWGS84]		DECIMAL(11, 8)			NULL,
	[PermitDepth]					INT						NULL,
	[PermitLatitudeWGS84]			DECIMAL(10, 8)			NULL,
	[PermitLongitudeWGS84]			DECIMAL(11, 8)			NULL,
	[PermitNumber]					VARCHAR(24)				NULL,
	[PermitOriginalApprovedDate]	VARCHAR(28)				NULL,	--	DATE
	[PermitPostedDate]				VARCHAR(28)				NULL,	--	DATE
	[PermitType]					VARCHAR(16)				NULL,

	[PowerType]						VARCHAR(8)				NULL,
	[Range]							VARCHAR(8)				NULL,
	[RatedHP]						INT						NULL,
	[RatedWaterDepth]				INT						NULL,
	[ReportedOperator]				VARCHAR(56)				NULL,

	[RigID]							BIGINT				NOT	NULL,

	[RigLatitudeWGS84]				DECIMAL(10, 8)			NULL,
	[RigLongitudeWGS84]				DECIMAL(11, 8)			NULL,
	[RigNameNumber]					VARCHAR(24)				NULL,

	[Section]						VARCHAR(16)				NULL,
	[SpudDate]						VARCHAR(28)				NULL,	--	DATE
	[Survey]						VARCHAR(56)				NULL,
	[TemporaryLocation]				VARCHAR(1)				NULL,
	[Township]						VARCHAR(8)				NULL,
	[TrueVerticalDepth]				INT						NULL,

	[UpdatedDate]					VARCHAR(28)			NOT	NULL,	--	DATE

	[WellNumber]					VARCHAR(16)				NULL,
	[WellType]						VARCHAR(24)				NULL,

	[txUrlLinkSuffix]				VARCHAR(256)		NOT	NULL,
	[txBatchId]						INT					NOT	NULL	CONSTRAINT [DF_DrillingInfoRigs_txBatchId]			DEFAULT(0),

	[txInserted]					VARCHAR(28)			NOT	NULL	CONSTRAINT [DF_DrillingInfoRigs_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_DrillingInfoRigs_txInsertedSid]		DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoRigs_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoRigs_txInsertedHost]		DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_DrillingInfoRigs_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoRigs_txInsertedApp]		DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_DrillingInfoRigs_txInsertedApp]		CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_DrillingInfoRigs_txRowReplication]	DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_DrillingInfoRigs_txRowVersion]		UNIQUE([txRowVersion]),

	CONSTRAINT [PK_DrillingInfoRigs]		PRIMARY KEY CLUSTERED([DrillingInfoRigsId] ASC),
	CONSTRAINT [UK_DrillingInfoRigs]		UNIQUE NONCLUSTERED([RigID] ASC, [UpdatedDate] ASC, [DeletedDate] ASC)
);
GO

CREATE NONCLUSTERED INDEX [UX_DrillingInfoRigs_DIBasin]
ON [stg].[DrillingInfoRigs]
(
	[DIBasin]
);