﻿CREATE TABLE [stg].[DrillingInfoLeasesLandtrac]
(
	[DrillingInfoLeasesLandtracId]		INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[AreaAcres]							FLOAT(53)				NULL,
	[BLM]								BIT						NULL,
	[Bonus]								FLOAT(53)				NULL,

	[CentroidLatitude]					DECIMAL(10, 8)			NULL,
	[CentroidLongitude]					DECIMAL(11, 8)			NULL,
	[CountyParish]						VARCHAR(32)				NULL,

	[CreatedDate]						VARCHAR(28)			NOT	NULL,	--	DATE

	[DIBasin]							VARCHAR(168)			NULL,
	[DILink]							VARCHAR(2048)			NULL,
	[DIPlay]							VARCHAR(96)				NULL,
	[DISubplay]							VARCHAR(96)				NULL,

	[DeletedDate]						VARCHAR(28)				NULL,	--	DATE

	[DepthClauseAvailable]				BIT						NULL,
	[DepthClauseTypes]					VARCHAR(16)				NULL,
	[EffectiveDate]						VARCHAR(28)				NULL,	--	DATE
	[ExpirationofPrimaryTerm]			VARCHAR(28)				NULL,	--	DATE
	[ExtBonus]							FLOAT(53)				NULL,
	[ExtTermMonths]						INT						NULL,

	[Geometry]							VARCHAR(MAX)			NULL,

	[Grantee]							VARCHAR(192)			NULL,
	[GranteeAddress]					VARCHAR(96)				NULL,
	[GranteeAlias]						VARCHAR(96)				NULL,

	[Grantor]							VARCHAR(192)			NULL,
	[GrantorAddress]					VARCHAR(96)				NULL,

	[InstrumentDate]					VARCHAR(28)				NULL,	--	DATE
	[InstrumentType]					VARCHAR(24)				NULL,

	[LeaseId]							BIGINT				NOT	NULL,

	[MajorityAssignmentEffectiveDate]	VARCHAR(28)				NULL,	--	DATE
	[MajorityAssignmentVolPage]			VARCHAR(24)				NULL,
	[MajorityLegalAssignee]				VARCHAR(96)				NULL,
	[MajorityLegalAssigneeInterest]		INT						NULL,

	[MaxDepth]							INT						NULL,
	[MinDepth]							INT						NULL,

	[Nomination]						BIT						NULL,
	[OptionsExtensions]					BIT						NULL,

	[RecordDate]						VARCHAR(28)				NULL,	--	DATE
	[RecordNo]							VARCHAR(24)				NULL,
	[Remarks]							VARCHAR(MAX)			NULL,
	[Royalty]							FLOAT(53)				NULL,
	[SpatialAssignee]					VARCHAR(48)				NULL,
	[State]								CHAR(2)					NULL,
	[StateLease]						BIT						NULL,
	[TermMonths]						INT						NULL,

	[UpdatedDate]						VARCHAR(28)			NOT	NULL,	--	DATE

	[VolPage]							VARCHAR(24)				NULL,

	[txUrlLinkSuffix]					VARCHAR(256)		NOT	NULL,
	[txBatchId]							INT					NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLandtrac_txBatchId]			DEFAULT(0),

	[txInserted]						VARCHAR(28)			NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLandtrac_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLandtrac_txInsertedSid]		DEFAULT(SUSER_SID()),
	[txInsertedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLandtrac_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLandtrac_txInsertedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_DrillingInfoLeasesLandtrac_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLandtrac_txInsertedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_DrillingInfoLeasesLandtrac_txInsertedApp]		CHECK([txInsertedApp] <> ''),
	[txRowReplication]					UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLandtrac_txRowReplication]		DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]						ROWVERSION			NOT	NULL	CONSTRAINT [UX_DrillingInfoLeasesLandtrac_txRowVersion]			UNIQUE([txRowVersion]),

	CONSTRAINT [PK_DrillingInfoLeasesLandtrac]		PRIMARY KEY CLUSTERED([DrillingInfoLeasesLandtracId]	ASC),
	CONSTRAINT [UK_DrillingInfoLeasesLandtrac]		UNIQUE NONCLUSTERED([LeaseId] ASC, [UpdatedDate] ASC, [DeletedDate] ASC)
);
GO

CREATE NONCLUSTERED INDEX [UX_DrillingInfoLeasesLandtrac_DIBasin]
ON [stg].[DrillingInfoLeasesLandtrac]
(
	[DIBasin]
);