﻿CREATE TABLE [stg].[DrillingInfoWells]
(
	[DrillingInfoWellsId]			INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[Abstract]						VARCHAR(16)				NULL,
	[Basin]							VARCHAR(168)			NULL,
	[Confidential]					CHAR(1)					NULL,
	[ConfidentialDate]				VARCHAR(28)				NULL,	--	DATE
	[Country]						VARCHAR(80)				NULL,
	[County]						VARCHAR(32)				NULL,

	[CreatedDate]					VARCHAR(28)			NOT	NULL,	--	DATE

	[CurrentOperator]				VARCHAR(96)				NULL,
	[CurrentStatus]					VARCHAR(24)				NULL,
	[CurrentStatusDate]				VARCHAR(28)				NULL,	--	DATE

	[DeletedDate]					VARCHAR(28)				NULL,	--	DATE

	[DepthUom]						VARCHAR(8)				NULL,
	[District]						VARCHAR(8)				NULL,

	[ElevRefDatum]					VARCHAR(8)				NULL,
	[ElevRefDatumepsgCode]			BIGINT					NULL,
	[ElevUom]						VARCHAR(8)				NULL,
	[Environment]					FLOAT(53)				NULL,

	[Field]							VARCHAR(56)				NULL,
	[FluidType]						VARCHAR(16)				NULL,

	[Formation]						VARCHAR(256)			NULL,
	[GovernmentID]					BIGINT					NULL,
	[GroundElev]					FLOAT(53)				NULL,
	[GroundElevationType]			VARCHAR(16)				NULL,
	[InitialClassification]			VARCHAR(16)				NULL,

	[LeaseName]						VARCHAR(56)				NULL,
	[LeaseNumber]					VARCHAR(24)				NULL,

	[LicenseDate]					VARCHAR(28)				NULL,	--	DATE
	[OnProductionDate]				VARCHAR(28)				NULL,	--	DATE

	[OperatorCompanyName]			VARCHAR(128)			NULL,
	[OperatorTicker]				VARCHAR(16)				NULL,
	[OriginalOperator]				VARCHAR(96)				NULL,

	[PermitNumber]					VARCHAR(24)				NULL,
	[ProvinceState]					VARCHAR(32)				NULL,

	[Range]							VARCHAR(8)				NULL,
	[RangeDirection]				VARCHAR(24)				NULL,
	[Region]						VARCHAR(48)				NULL,
	[Remark]						VARCHAR(MAX)			NULL,

	[Section]						VARCHAR(16)				NULL,
	[Source]						CHAR(2)					NULL,
	[SpudDate]						VARCHAR(28)				NULL,	--	DATE
	[SpudDateSource]				VARCHAR(16)				NULL,

	[TopLevelCommonName]			VARCHAR(96)				NULL,
	[Township]						VARCHAR(8)				NULL,
	[TownshipDirection]				VARCHAR(8)				NULL,
	[UID]							BIGINT					NULL,

	[UpdatedDate]					VARCHAR(28)			NOT	NULL,	--	DATE

	[WaterDepth]					FLOAT(53)				NULL,
	[WaterDepthDatum]				VARCHAR(8)				NULL,
	[WellName]						VARCHAR(96)				NULL,
	[WellNumber]					VARCHAR(16)				NULL,
	[Wgs84Latitude]					DECIMAL(10, 8)			NULL,
	[Wgs84Longitude]				DECIMAL(11, 8)			NULL,

	[txUrlLinkSuffix]				VARCHAR(256)			NULL,
	[txBatchId]						INT					NOT	NULL	CONSTRAINT [DF_DrillingInfoWells_txBatchId]			DEFAULT(0),

	[txInserted]					VARCHAR(28)			NOT	NULL	CONSTRAINT [DF_DrillingInfoWells_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_DrillingInfoWells_txInsertedSid]			DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoWells_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoWells_txInsertedHost]		DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_DrillingInfoWells_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoWells_txInsertedApp]			DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_DrillingInfoWells_txInsertedApp]			CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_DrillingInfoWells_txRowReplication]		DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_DrillingInfoWells_txRowVersion]			UNIQUE([txRowVersion]),

	CONSTRAINT [PK_DrillingInfoWells]		PRIMARY KEY CLUSTERED([DrillingInfoWellsId]	ASC)
	--CONSTRAINT [UK_DrillingInfoWells]		UNIQUE NONCLUSTERED([WellNumber] ASC, [UpdatedDate] ASC, [DeletedDate] ASC)
);

GO

CREATE NONCLUSTERED INDEX [UX_DrillingInfoWells_Basin]
ON [stg].[DrillingInfoWells]
(
	[Basin]
);