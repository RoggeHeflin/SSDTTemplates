﻿CREATE TABLE [stg].[DrillingInfoDealsForSale]
(
	[DrillingInfoDealsForSaleId]	INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[AcresNetUndeveloped]			FLOAT(53)				NULL,
	[Assets]						VARCHAR(512)			NULL,

	[BidDeadline]					VARCHAR(28)				NULL,	--	DATE

	[Blocks]						VARCHAR(1024)			NULL,	--	Semicolon delimited
	[Country]						VARCHAR(80)				NULL,
	[CountyParish]					VARCHAR(2048)			NULL,

	[CreatedDate]					VARCHAR(28)			NOT	NULL,	--	DATE

	[DIBasin]						VARCHAR(168)			NULL,

	[DateAnnounced]					VARCHAR(28)				NULL,	--	DATE

	[DealHighlights]				VARCHAR(MAX)			NULL,
	[DealStatus]					VARCHAR(16)				NULL,
	[DealType]						VARCHAR(16)				NULL,

	[DealsForSaleID]				BIGINT					NULL,

	[DealsForSaleNotes]				VARCHAR(1024)			NULL,

	[DeletedDate]					VARCHAR(28)				NULL,	--	DATE

	[Geometry]						VARCHAR(MAX)			NULL,
	[Headline]						VARCHAR(256)			NULL,
	[Hydrocarbon]					VARCHAR(24)				NULL,

	[Latitude]						DECIMAL(10, 8)			NULL,
	[Licenses]						VARCHAR(768)			NULL,
	[Longitude]						DECIMAL(11, 8)			NULL,

	[OnshoreOffshore]				VARCHAR(8)				NULL,
	[OpNonOp]						VARCHAR(16)				NULL,
	[OperatorCompanyName]			VARCHAR(128)			NULL,
	[OperatorTicker]				VARCHAR(16)				NULL,

	[ProductionMBOEDGross]			FLOAT(53)				NULL,
	[ProductionMBOEDNet]			FLOAT(53)				NULL,
	[ProductionPercentOil]			FLOAT(53)				NULL,

	[Region]						VARCHAR(48)				NULL,

	[Reserves2PMMBOEGross]			FLOAT(53)				NULL,
	[Reserves2PPercentOil]			FLOAT(53)				NULL,
	[ReservesProvedMMBOEGross]		FLOAT(53)				NULL,
	[ReservesProvedMMBOENet]		FLOAT(53)				NULL,
	[ReservesProvedPercentOil]		FLOAT(53)				NULL,

	[ResourceType]					VARCHAR(16)				NULL,

	[Sellers]						VARCHAR(128)			NULL,
	[SellersFinancialAdvisors]		VARCHAR(128)			NULL,
	[SellersPeerGroup]				VARCHAR(128)			NULL,
	[State]							VARCHAR(96)				NULL,	--	Comma Delimited
	[TransactionType]				VARCHAR(96)				NULL,

	[USPlay]						VARCHAR(96)				NULL,
	[USRegion]						VARCHAR(48)				NULL,
	[USSubRegion]					VARCHAR(48)				NULL,

	[UpdatedDate]					VARCHAR(28)			NOT	NULL,	--	DATE

	[ValueRangeMM]					VARCHAR(48)				NULL,

	[txUrlLinkSuffix]				VARCHAR(256)			NULL,
	[txBatchId]						INT					NOT	NULL	CONSTRAINT [DF_DrillingInfoDealsForSale_txBatchId]				DEFAULT(0),

	[txInserted]					DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_DrillingInfoDealsForSale_txInserted]				DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_DrillingInfoDealsForSale_txInsertedSid]			DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoDealsForSale_txInsertedUser]			DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoDealsForSale_txInsertedHost]			DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_DrillingInfoDealsForSale_txInsertedHost]			CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoDealsForSale_txInsertedApp]			DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_DrillingInfoDealsForSale_txInsertedApp]			CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_DrillingInfoDealsForSale_txRowReplication]		DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_DrillingInfoDealsForSale_txRowVersion]			UNIQUE([txRowVersion]),

	CONSTRAINT [PK_DrillingInfoDealsForSale]		PRIMARY KEY CLUSTERED([DrillingInfoDealsForSaleId]	ASC),
	CONSTRAINT [UK_DrillingInfoDealsForSale]		UNIQUE NONCLUSTERED([DealsForSaleID] ASC)
);
GO

CREATE NONCLUSTERED INDEX [UX_DrillingInfoDealsForSale_DIBasin]
ON [stg].[DrillingInfoDealsForSale]
(
	[DIBasin]
);