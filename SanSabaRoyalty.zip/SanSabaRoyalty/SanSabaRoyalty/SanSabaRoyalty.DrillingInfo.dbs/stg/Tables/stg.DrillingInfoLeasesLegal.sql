﻿CREATE TABLE [stg].[DrillingInfoLeasesLegal]
(
	[DrillingInfoLeasesLegalId]			INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[Abstract]							INT						NULL,
	[AbstractNo]						INT						NULL,
	[AreaAcres]							FLOAT(53)				NULL,
	[BLM]								BIGINT					NULL,
	[Block]								VARCHAR(48)				NULL,
	[Bonus]								INT						NULL,
	[CountyParish]						VARCHAR(32)				NULL,

	[Created]							VARCHAR(28)			NOT	NULL,	--	DATE
	[CreatedDate]						VARCHAR(28)			NOT	NULL,	--	DATE

	[DIBasin]							VARCHAR(168)			NULL,
	[DILink]							VARCHAR(2048)			NULL,
	[DIPlay]							VARCHAR(96)				NULL,
	[DISubplay]							VARCHAR(96)				NULL,

	[DeletedDate]						VARCHAR(28)				NULL,	--	DATE

	[EffectiveDate]						VARCHAR(28)				NULL,	--	DATE
	[ExpirationofPrimaryTerm]			VARCHAR(28)				NULL,	--	DATE
	[ExtBonus]							INT						NULL,
	[ExtTermMonths]						INT						NULL,

	[Geometry]							VARCHAR(MAX)			NULL,

	[Grantee]							VARCHAR(192)			NULL,
	[GranteeAddress]					VARCHAR(96)				NULL,
	[GranteeAlias]						VARCHAR(96)				NULL,

	[Grantor]							VARCHAR(192)			NULL,
	[GrantorAddress]					VARCHAR(96)				NULL,

	[InstrumentDate]					VARCHAR(28)				NULL,	--	DATE
	[InstrumentType]					VARCHAR(24)				NULL,

	[LatitudeWGS84]						DECIMAL(10, 8)			NULL,
	[LeaseCount]						INT						NULL,
	[LeaseCountSymbol]					FLOAT(53)				NULL,

	[LeaseId]							BIGINT				NOT	NULL,

	[LongitudeWGS84]					DECIMAL(11, 8)			NULL,

	[MajorityAssignmentEffectiveDate]	VARCHAR(28)				NULL,	--	DATE
	[MajorityAssignmentVolPage]			VARCHAR(24)				NULL,
	[MajorityLegalAssignee]				VARCHAR(96)				NULL,
	[MajorityLegalAssigneeInterest]		INT						NULL,

	[MappingID]							INT						NULL,
	[MaxDepth]							INT						NULL,
	[MinDepth]							INT						NULL,

	[Nomination]						BIT						NULL,
	[OptionsExtensions]					BIT						NULL,
	[PolygonGroupID]					INT						NULL,
	[QuarterCalls]						VARCHAR(56)				NULL,

	[Range]								VARCHAR(24)				NULL,
	[RangeDirection]					VARCHAR(24)				NULL,

	[RecordDate]						VARCHAR(28)				NULL,	--	DATE
	[RecordNo]							VARCHAR(24)				NULL,
	[Remarks]							VARCHAR(MAX)			NULL,
	[Royalty]							FLOAT(53)				NULL,
	[Section]							FLOAT(53)				NULL,

	[State]								CHAR(2)					NULL,

	[StateLease]						BIT						NULL,
	[SurveyName]						VARCHAR(56)				NULL,
	[TermMonths]						INT						NULL,
	[Township]							FLOAT(8)				NULL,
	[TownshipDirection]					VARCHAR(8)				NULL,

	[Updated]							VARCHAR(28)			NOT	NULL,	--	DATE
	[UpdatedDate]						VARCHAR(28)			NOT	NULL,	--	DATE

	[VolPage]							VARCHAR(24)				NULL,

	[txUrlLinkSuffix]					VARCHAR(256)			NULL,
	[txBatchId]							INT					NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLegal_txBatchId]			DEFAULT(0),

	[txInserted]						VARCHAR(28)			NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLegal_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLegal_txInsertedSid]		DEFAULT(SUSER_SID()),
	[txInsertedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLegal_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLegal_txInsertedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_DrillingInfoLeasesLegal_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLegal_txInsertedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_DrillingInfoLeasesLegal_txInsertedApp]		CHECK([txInsertedApp] <> ''),
	[txRowReplication]					UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_DrillingInfoLeasesLegal_txRowReplication]	DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]						ROWVERSION			NOT	NULL	CONSTRAINT [UX_DrillingInfoLeasesLegal_txRowVersion]		UNIQUE([txRowVersion]),

	CONSTRAINT [PK_DrillingInfoLeasesLegal]		PRIMARY KEY CLUSTERED([DrillingInfoLeasesLegalId] ASC),
	CONSTRAINT [UK_DrillingInfoLeasesLegal]		UNIQUE NONCLUSTERED([LeaseId] ASC, [UpdatedDate] ASC, [DeletedDate] ASC, [Abstract] ASC, [MappingID])
);
GO

CREATE NONCLUSTERED INDEX [UX_DrillingInfoLeasesLegal_DIBasin]
ON [stg].[DrillingInfoLeasesLegal]
(
	[DIBasin]
);