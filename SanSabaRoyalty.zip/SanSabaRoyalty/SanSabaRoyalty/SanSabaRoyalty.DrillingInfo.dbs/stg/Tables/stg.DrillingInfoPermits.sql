﻿CREATE TABLE [stg].[DrillingInfoPermits]
(
	[DrillingInfoPermitsId]			INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[API10]							VARCHAR(16)				NULL,
	[API12]							BIGINT					NULL,
	[Abstract]						VARCHAR(8)				NULL,
	[ActiveCommonName]				VARCHAR(96)				NULL,
	[ActiveTickerName]				VARCHAR(8)				NULL,

	[AmendmentFiledDate]			VARCHAR(28)				NULL,	--	DATE
	[ApprovedDate]					VARCHAR(28)				NULL,	--	DATE

	[Block]							VARCHAR(48)				NULL,
	[BottomHoleLatitudeWGS84]		DECIMAL(10, 8)			NULL,
	[BottomHoleLongitudeWGS84]		DECIMAL(11, 8)			NULL,

	[ContactName]					VARCHAR(56)				NULL,
	[ContactPhone]					VARCHAR(32)				NULL,
	[CountyParish]					VARCHAR(32)				NULL,

	[CreatedDate]					VARCHAR(28)			NOT	NULL,	--	DATE

	[DIBasin]						VARCHAR(168)			NULL,
	[DICountryCode]					CHAR(2)					NULL,
	[DICountryName]					VARCHAR(80)				NULL,
	[DICountyParishName]			VARCHAR(32)				NULL,
	[DIPlay]						VARCHAR(96)				NULL,
	[DIStateProvinceCode]			CHAR(2)					NULL,
	[DIStateProvinceName]			VARCHAR(24)				NULL,
	[DISubPlay]						VARCHAR(96)				NULL,

	[DeletedDate]					VARCHAR(28)				NULL,	--	DATE

	[District]						VARCHAR(8)				NULL,
	[DrillType]						VARCHAR(8)				NULL,
	[ExpiredDate]					VARCHAR(28)				NULL,	--	DATE

	[Field]							VARCHAR(56)				NULL,
	[Formation]						VARCHAR(256)			NULL,
	[H2SArea]						VARCHAR(8)				NULL,
	[LeaseName]						VARCHAR(56)				NULL,
	[LeaseNumber]					VARCHAR(24)				NULL,

	[OFSRegion]						VARCHAR(48)				NULL,

	[OperatorAddress]				VARCHAR(96)				NULL,
	[OperatorAlias]					VARCHAR(96)				NULL,
	[OperatorCity]					VARCHAR(24)				NULL,
	[OperatorCity30mi]				VARCHAR(24)				NULL,
	[OperatorCity50mi]				VARCHAR(24)				NULL,
	[OperatorState]					CHAR(2)					NULL,
	[OperatorZip]					VARCHAR(10)				NULL,

	[OrigApprovedDate]				VARCHAR(28)				NULL,	--	DATE

	[PermitDepth]					INT						NULL,
	[PermitDepthUOM]				VARCHAR(8)				NULL,
	[PermitID]						BIGINT				NOT	NULL,
	[PermitNumber]					VARCHAR(24)				NULL,
	[PermitStatus]					VARCHAR(24)				NULL,
	[PermitType]					VARCHAR(32)				NULL,

	[Range]							VARCHAR(8)				NULL,
	[ReportedOperator]				VARCHAR(96)				NULL,
	[Section]						VARCHAR(16)				NULL,
	[StateProvince]					CHAR(2)					NULL,

	[SubmittedDate]					VARCHAR(28)				NULL,	--	DATE

	[SurfaceLatitudeWGS84]			DECIMAL(10, 8)			NULL,
	[SurfaceLongitudeWGS84]			DECIMAL(11, 8)			NULL,
	[Survey]						VARCHAR(56)				NULL,
	[Township]						VARCHAR(8)				NULL,
	[TrueVerticalDepth]				INT						NULL,
	[TrueVerticalDepthUOM]			VARCHAR(8)				NULL,

	[UpdatedDate]					VARCHAR(28)			NOT	NULL,	--	DATE

	[WGID]							BIGINT					NULL,

	[WellNumber]					VARCHAR(16)				NULL,
	[WellStatus]					VARCHAR(16)				NULL,
	[WellType]						VARCHAR(24)				NULL,

	[txUrlLinkSuffix]				VARCHAR(256)			NULL,
	[txBatchId]						INT					NOT	NULL	CONSTRAINT [DF_DrillingInfoPErmits_txBatchId]			DEFAULT(0),

	[txInserted]					VARCHAR(28)			NOT	NULL	CONSTRAINT [DF_DrillingInfoPermits_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_DrillingInfoPermits_txInsertedSid]		DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoPermits_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoPermits_txInsertedHost]		DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_DrillingInfoPermits_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_DrillingInfoPermits_txInsertedApp]		DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_DrillingInfoPermits_txInsertedApp]		CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_DrillingInfoPermits_txRowReplication]	DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_DrillingInfoPermits_txRowVersion]		UNIQUE([txRowVersion]),

	CONSTRAINT [PK_DrillingInfoPermits]		PRIMARY KEY CLUSTERED([DrillingInfoPermitsId] ASC),
	CONSTRAINT [UK_DrillingInfoPermits]		UNIQUE NONCLUSTERED([PermitID] ASC, [UpdatedDate] ASC, [DeletedDate] ASC)
);
GO

CREATE NONCLUSTERED INDEX [UX_DrillingInfoPermits_DIBasin]
ON [stg].[DrillingInfoPermits]
(
	[DIBasin]
);