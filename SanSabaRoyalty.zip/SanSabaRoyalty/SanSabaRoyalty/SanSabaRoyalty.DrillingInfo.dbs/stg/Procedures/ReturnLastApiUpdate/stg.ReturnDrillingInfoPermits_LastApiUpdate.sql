﻿CREATE PROCEDURE [stg].[ReturnDrillingInfoPermits_LastApiUpdate]
AS
BEGIN

	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 100;
	SET DEADLOCK_PRIORITY HIGH;

	DECLARE @TxnCount		INT				= @@TRANCOUNT;
	DECLARE @TxnActive		VARCHAR(32)		= REPLACE(CONVERT(VARCHAR(36), NEWID(), 0), '-', '');
	DECLARE @ErrorCode		INT				= 0;

	DECLARE @TrackingLogId	INT;
	EXECUTE @TrackingLogId	= [track].[InsertProcedureLogBegin] @@PROCID;

	IF (@TxnCount = 0) BEGIN TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	BEGIN TRY
	-----------------------------------------------------------------------------------------------

		SELECT
			[UpdateDate]	=	CONVERT(DATETIME, MAX([e].[UpdateDateEnd]))
		FROM
			[track].[BatchLogBegin]			[b]
		INNER JOIN
			[track].[BatchLogEnd]			[e]
				ON	([b].[BatchLogId]	=	[e].[BatchLogId])
		WHERE
				([b].[SchemaName]	= 'stg')
			AND	([b].[TableName]	= 'DrillingInfoPermits');

	-----------------------------------------------------------------------------------------------
	IF (@TxnCount = 0) COMMIT TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	END TRY
	BEGIN CATCH

		SET @ErrorCode = @@ERROR;

		IF (XACT_STATE() = -1) ROLLBACK	TRANSACTION	@TxnActive;
		IF (XACT_STATE() =  1) COMMIT	TRANSACTION	@TxnActive;

		EXECUTE [track].[InsertProcedureLogError] @TrackingLogId;

		THROW;

		RETURN @ErrorCode;

	END CATCH;

	EXECUTE [track].[InsertProcedureLogEnd] @TrackingLogId;

	RETURN @ErrorCode;

END;