﻿CREATE PROCEDURE [stg].[InsertBatchLogEnd_DrillingInfoDealsForSale]
(
	@BatchLogId		INT
)
AS
BEGIN

	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 100;
	SET DEADLOCK_PRIORITY HIGH;

	DECLARE @TxnCount		INT				= @@TRANCOUNT;
	DECLARE @TxnActive		VARCHAR(32)		= REPLACE(CONVERT(VARCHAR(36), NEWID(), 0), '-', '');
	DECLARE @ErrorCode		INT				= 0;

	DECLARE @TrackingLogId	INT;
	EXECUTE @TrackingLogId	= [track].[InsertProcedureLogBegin] @@PROCID;

	IF (@TxnCount = 0) BEGIN TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	BEGIN TRY
	-----------------------------------------------------------------------------------------------

		INSERT INTO [track].[BatchLogEnd]
		(
			[BatchLogId],
			[RowCount],
			[UpdateDateBeg],
			[UpdateDateEnd],
			[SourceNotes]
		)
		SELECT
				[BatchLogId]		= @BatchLogId,

				[RowCount]			= [a].[Items],
				[UpdateDateBeg]		= CONVERT(DATETIMEOFFSET(4), [a].[UpdateDateBeg], 127),
				[UpdateDateEnd]		= CONVERT(DATETIMEOFFSET(4), [a].[UpdateDateEnd], 127),

				[SourceNotes]		= [u].[txUrlLinkSuffix]
		FROM (
			SELECT
				[Items]				= COUNT(*),
				[UpdateDateBeg]		= MIN([t].[UpdatedDate]),
				[UpdateDateEnd]		= MAX([t].[UpdatedDate])
			FROM
				[stg].[DrillingInfoDealsForSale]	[t]
			WHERE
				([t].[txBatchId]	= @BatchLogId)
			) [a]
		CROSS JOIN (
			SELECT TOP (1)
				[t].[txUrlLinkSuffix]
			FROM
				[stg].[DrillingInfoDealsForSale]	[t]
			WHERE
				([t].[txBatchId]	= @BatchLogId)
			ORDER BY
				[t].[DrillingInfoDealsForSaleId]	ASC
			) [u];

	-----------------------------------------------------------------------------------------------
	IF (@TxnCount = 0) COMMIT TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	END TRY
	BEGIN CATCH

		SET @ErrorCode = @@ERROR;

		IF (XACT_STATE() = -1) ROLLBACK	TRANSACTION	@TxnActive;
		IF (XACT_STATE() =  1) COMMIT	TRANSACTION	@TxnActive;

		EXECUTE [track].[InsertProcedureLogError] @TrackingLogId;

		THROW;

		RETURN @ErrorCode;

	END CATCH;

	EXECUTE [track].[InsertProcedureLogEnd] @TrackingLogId;

	RETURN @ErrorCode;

END;