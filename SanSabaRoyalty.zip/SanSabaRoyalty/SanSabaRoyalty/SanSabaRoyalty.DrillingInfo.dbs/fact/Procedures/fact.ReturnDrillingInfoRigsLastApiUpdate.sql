﻿--CREATE PROCEDURE [fact].[ReturnDrillingInfoRigsLastApiUpdate]
--AS
--BEGIN

--	SET NOCOUNT ON;
--	SET LOCK_TIMEOUT 100;
--	SET DEADLOCK_PRIORITY HIGH;

--	SELECT TOP(1)
--		[UpdatedDate]	= CONVERT(VARCHAR(28), MAX([t].[UpdatedDate]), 127)
--	FROM
--		[fact].[DrillingInfoRigs]	[t];

--END;