﻿CREATE PROCEDURE [fact].[InsertDrillingInfoRigs]
AS
BEGIN

	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 100;
	SET DEADLOCK_PRIORITY HIGH;

	DECLARE @TxnCount		INT				= @@TRANCOUNT;
	DECLARE @TxnActive		VARCHAR(32)		= REPLACE(CONVERT(VARCHAR(36), NEWID(), 0), '-', '');
	DECLARE @ErrorCode		INT				= 0;

	DECLARE @TrackingLogId	INT;
	EXECUTE @TrackingLogId	= [track].[InsertProcedureLogBegin] @@PROCID;

	IF (@TxnCount = 0) BEGIN TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	BEGIN TRY
	-----------------------------------------------------------------------------------------------

	INSERT INTO [fact].[DrillingInfoRigs]
	(
		[API10],
		[Abstract],
		[Block],
		[ContractorAddress],
		[ContractorCity],
		[ContractorContact],
		[ContractorEmail],
		[ContractorName],
		[ContractorPhone],
		[ContractorState],
		[ContractorWebsite],
		[ContractorZip],
		[CreatedDate],
		[DIBasin],
		[DICountryCode],
		[DICountryName],
		[DICountyParishName],
		[DIPlay],
		[DIStateProvinceCode],
		[DIStateProvinceName],
		[DISubPlay],
		[DataSource],
		[DeletedDate],
		[DirectionsToLocation],
		[District],
		[DrawWorks],
		[DrillType],
		[Field],
		[Formation],
		[FormationDepth],
		[H2SArea],
		[LandOffshore],
		[LeaseName],
		[MajorCity30mi],
		[MajorCity50mi],
		[Mobility],
		[OFSRegion],
		[OperatorAddress],
		[OperatorAlias],
		[OperatorCity],
		[OperatorCompanyName],
		[OperatorContact],
		[OperatorPhone],
		[OperatorState],
		[OperatorTicker],
		[OperatorZip],
		[PermitAmendedDate],
		[PermitApprovedDate],
		[PermitBHLatitudeWGS84],
		[PermitBHLongitudeWGS84],
		[PermitDepth],
		[PermitLatitudeWGS84],
		[PermitLongitudeWGS84],
		[PermitNumber],
		[PermitOriginalApprovedDate],
		[PermitPostedDate],
		[PermitType],
		[PowerType],
		[Range],
		[RatedHP],
		[RatedWaterDepth],
		[ReportedOperator],
		[RigID],
		[RigLatitudeWGS84],
		[RigLongitudeWGS84],
		[RigNameNumber],
		[Section],
		[SpudDate],
		[Survey],
		[TemporaryLocation],
		[Township],
		[TrueVerticalDepth],
		[UpdatedDate],
		[WellNumber],
		[WellType]
	)
	SELECT
		[t].[API10],
		[t].[Abstract],
		[t].[Block],
		[t].[ContractorAddress],
		[t].[ContractorCity],
		[t].[ContractorContact],
		[t].[ContractorEmail],
		[t].[ContractorName],
		[t].[ContractorPhone],
		[t].[ContractorState],
		[t].[ContractorWebsite],
		[t].[ContractorZip],
		[t].[CreatedDate],
		[t].[DIBasin],
		[t].[DICountryCode],
		[t].[DICountryName],
		[t].[DICountyParishName],
		[t].[DIPlay],
		[t].[DIStateProvinceCode],
		[t].[DIStateProvinceName],
		[t].[DISubPlay],
		[t].[DataSource],
		[t].[DeletedDate],
		[t].[DirectionsToLocation],
		[t].[District],
		[t].[DrawWorks],
		[t].[DrillType],
		[t].[Field],
		[t].[Formation],
		[t].[FormationDepth],
		[t].[H2SArea],
		[t].[LandOffshore],
		[t].[LeaseName],
		[t].[MajorCity30mi],
		[t].[MajorCity50mi],
		[t].[Mobility],
		[t].[OFSRegion],
		[t].[OperatorAddress],
		[t].[OperatorAlias],
		[t].[OperatorCity],
		[t].[OperatorCompanyName],
		[t].[OperatorContact],
		[t].[OperatorPhone],
		[t].[OperatorState],
		[t].[OperatorTicker],
		[t].[OperatorZip],
		[t].[PermitAmendedDate],
		[t].[PermitApprovedDate],
		[t].[PermitBHLatitudeWGS84],
		[t].[PermitBHLongitudeWGS84],
		[t].[PermitDepth],
		[t].[PermitLatitudeWGS84],
		[t].[PermitLongitudeWGS84],
		[t].[PermitNumber],
		[t].[PermitOriginalApprovedDate],
		[t].[PermitPostedDate],
		[t].[PermitType],
		[t].[PowerType],
		[t].[Range],
		[t].[RatedHP],
		[t].[RatedWaterDepth],
		[t].[ReportedOperator],
		[t].[RigID],
		[t].[RigLatitudeWGS84],
		[t].[RigLongitudeWGS84],
		[t].[RigNameNumber],
		[t].[Section],
		[t].[SpudDate],
		[t].[Survey],
		[t].[TemporaryLocation],
		[t].[Township],
		[t].[TrueVerticalDepth],
		[t].[UpdatedDate],
		[t].[WellNumber],
		[t].[WellType]
	FROM
		[stg].[DrillingInfoRigs_V]	[t]
	WHERE
		([t].[API10]	IS NOT NULL);

	-----------------------------------------------------------------------------------------------
	IF (@TxnCount = 0) COMMIT TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	END TRY
	BEGIN CATCH

		SET @ErrorCode = @@ERROR;

		IF (XACT_STATE() = -1) ROLLBACK	TRANSACTION	@TxnActive;
		IF (XACT_STATE() =  1) COMMIT	TRANSACTION	@TxnActive;

		EXECUTE [track].[InsertProcedureLogError] @TrackingLogId;

		THROW;

		RETURN @ErrorCode;

	END CATCH;

	EXECUTE [track].[InsertProcedureLogEnd] @TrackingLogId;

	RETURN @ErrorCode;

END;