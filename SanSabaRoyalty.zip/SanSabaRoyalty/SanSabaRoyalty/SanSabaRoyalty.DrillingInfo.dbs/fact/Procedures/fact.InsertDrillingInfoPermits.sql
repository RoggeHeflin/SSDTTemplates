﻿CREATE PROCEDURE [fact].[InsertDrillingInfoPermits]
AS
BEGIN

	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 100;
	SET DEADLOCK_PRIORITY HIGH;

	DECLARE @TxnCount		INT				= @@TRANCOUNT;
	DECLARE @TxnActive		VARCHAR(32)		= REPLACE(CONVERT(VARCHAR(36), NEWID(), 0), '-', '');
	DECLARE @ErrorCode		INT				= 0;

	DECLARE @TrackingLogId	INT;
	EXECUTE @TrackingLogId	= [track].[InsertProcedureLogBegin] @@PROCID;

	IF (@TxnCount = 0) BEGIN TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	BEGIN TRY
	-----------------------------------------------------------------------------------------------

	INSERT INTO [fact].[DrillingInfoPermits]
	(
		[API10],
		[API12],
		[Abstract],
		[ActiveCommonName],
		[ActiveTickerName],
		[AmendmentFiledDate],
		[ApprovedDate],
		[Block],
		[BottomHoleLatitudeWGS84],
		[BottomHoleLongitudeWGS84],
		[ContactName],
		[ContactPhone],
		[CountyParish],
		[CreatedDate],
		[DIBasin],
		[DICountryCode],
		[DICountryName],
		[DICountyParishName],
		[DIPlay],
		[DIStateProvinceCode],
		[DIStateProvinceName],
		[DISubPlay],
		[DeletedDate],
		[District],
		[DrillType],
		[ExpiredDate],
		[Field],
		[Formation],
		[H2SArea],
		[LeaseName],
		[LeaseNumber],
		[OFSRegion],
		[OperatorAddress],
		[OperatorAlias],
		[OperatorCity],
		[OperatorCity30mi],
		[OperatorCity50mi],
		[OperatorState],
		[OperatorZip],
		[OrigApprovedDate],
		[PermitDepth],
		[PermitDepthUOM],
		[PermitID],
		[PermitNumber],
		[PermitStatus],
		[PermitType],
		[Range],
		[ReportedOperator],
		[Section],
		[StateProvince],
		[SubmittedDate],
		[SurfaceLatitudeWGS84],
		[SurfaceLongitudeWGS84],
		[Survey],
		[Township],
		[TrueVerticalDepth],
		[TrueVerticalDepthUOM],
		[UpdatedDate],
		[WGID],
		[WellNumber],
		[WellStatus],
		[WellType]
	)
	SELECT
			[API10]					= CONVERT(BIGINT, [t].[API10]),
		[t].[API12],
		[t].[Abstract],
		[t].[ActiveCommonName],
		[t].[ActiveTickerName],
			[AmendmentFiledDate]	= CONVERT(DATE, [t].[AmendmentFiledDate], 127),
			[ApprovedDate]			= CONVERT(DATE, [t].[ApprovedDate], 127),
		[t].[Block],
		[t].[BottomHoleLatitudeWGS84],
		[t].[BottomHoleLongitudeWGS84],
		[t].[ContactName],
		[t].[ContactPhone],
		[t].[CountyParish],
			[CreatedDate]			= SWITCHOFFSET([t].[CreatedDate], '-06:00'),
		[t].[DIBasin],
		[t].[DICountryCode],
		[t].[DICountryName],
		[t].[DICountyParishName],
		[t].[DIPlay],
		[t].[DIStateProvinceCode],
		[t].[DIStateProvinceName],
		[t].[DISubPlay],
			[DeletedDate]			= SWITCHOFFSET([t].[DeletedDate], '-06:00'),
		[t].[District],
		[t].[DrillType],
		[t].[ExpiredDate],
		[t].[Field],
		[t].[Formation],
		[t].[H2SArea],
		[t].[LeaseName],
		[t].[LeaseNumber],
		[t].[OFSRegion],
		[t].[OperatorAddress],
		[t].[OperatorAlias],
		[t].[OperatorCity],
		[t].[OperatorCity30mi],
		[t].[OperatorCity50mi],
		[t].[OperatorState],
		[t].[OperatorZip],
		[t].[OrigApprovedDate],
		[t].[PermitDepth],
		[t].[PermitDepthUOM],
		[t].[PermitID],
		[t].[PermitNumber],
		[t].[PermitStatus],
		[t].[PermitType],
		[t].[Range],
		[t].[ReportedOperator],
		[t].[Section],
		[t].[StateProvince],
		[t].[SubmittedDate],
		[t].[SurfaceLatitudeWGS84],
		[t].[SurfaceLongitudeWGS84],
		[t].[Survey],
		[t].[Township],
		[t].[TrueVerticalDepth],
		[t].[TrueVerticalDepthUOM],
			[UpdatedDate]			= SWITCHOFFSET([t].[UpdatedDate], '-06:00'),
		[t].[WGID],
		[t].[WellNumber],
		[t].[WellStatus],
		[t].[WellType]
	FROM
		[stg].[DrillingInfoPermits]		[t]
	WHERE
			([t].[API10]	IS NOT NULL)
		AND	([t].[API10]	<>	'UNKNOWN');

	-----------------------------------------------------------------------------------------------
	IF (@TxnCount = 0) COMMIT TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	END TRY
	BEGIN CATCH

		SET @ErrorCode = @@ERROR;

		IF (XACT_STATE() = -1) ROLLBACK	TRANSACTION	@TxnActive;
		IF (XACT_STATE() =  1) COMMIT	TRANSACTION	@TxnActive;

		EXECUTE [track].[InsertProcedureLogError] @TrackingLogId;

		THROW;

		RETURN @ErrorCode;

	END CATCH;

	EXECUTE [track].[InsertProcedureLogEnd] @TrackingLogId;

	RETURN @ErrorCode;

END;