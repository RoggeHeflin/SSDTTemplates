﻿CREATE VIEW [fact].[DrillingInfoPermitsCurrent]
WITH SCHEMABINDING, VIEW_METADATA
AS
SELECT
	[t].[API10],
	[t].[API12],
	[t].[Abstract],
	[t].[ActiveCommonName],
	[t].[ActiveTickerName],
	[t].[AmendmentFiledDate],
	[t].[ApprovedDate],
	[t].[Block],
	[t].[BottomHoleLatitudeWGS84],
	[t].[BottomHoleLongitudeWGS84],
	[t].[ContactName],
	[t].[ContactPhone],
	[t].[CountyParish],
	[t].[CreatedDate],
	[t].[DIBasin],
	[t].[DICountryCode],
	[t].[DICountryName],
	[t].[DICountyParishName],
	[t].[DIPlay],
	[t].[DIStateProvinceCode],
	[t].[DIStateProvinceName],
	[t].[DISubPlay],
	[t].[DeletedDate],
	[t].[District],
	[t].[DrillType],
	[t].[ExpiredDate],
	[t].[Field],
	[t].[Formation],
	[t].[H2SArea],
	[t].[LeaseName],
	[t].[LeaseNumber],
	[t].[OFSRegion],
	[t].[OperatorAddress],
	[t].[OperatorAlias],
	[t].[OperatorCity],
	[t].[OperatorCity30mi],
	[t].[OperatorCity50mi],
	[t].[OperatorState],
	[t].[OperatorZip],
	[t].[OrigApprovedDate],
	[t].[PermitDepth],
	[t].[PermitDepthUOM],
	[t].[PermitID],
	[t].[PermitNumber],
	[t].[PermitStatus],
	[t].[PermitType],
	[t].[Range],
	[t].[ReportedOperator],
	[t].[Section],
	[t].[StateProvince],
	[t].[SubmittedDate],
	[t].[SurfaceLatitudeWGS84],
	[t].[SurfaceLongitudeWGS84],
	[t].[Survey],
	[t].[Township],
	[t].[TrueVerticalDepth],
	[t].[TrueVerticalDepthUOM],
	[t].[UpdatedDate],
	[t].[WGID],
	[t].[WellNumber],
	[t].[WellStatus],
	[t].[WellType]
FROM
	[fact].[DrillingInfoPermits]		[t]
INNER JOIN (
	SELECT
		[t].[API10],
			[UpdatedDate]	= MAX([t].[UpdatedDate])
	FROM
		[fact].[DrillingInfoPermits]	[t]
	GROUP BY
		[t].[API10]
	) [f]
		ON	([t].[API10]		=	[f].[API10])
		AND	([t].[UpdatedDate]	=	[f].[UpdatedDate]);