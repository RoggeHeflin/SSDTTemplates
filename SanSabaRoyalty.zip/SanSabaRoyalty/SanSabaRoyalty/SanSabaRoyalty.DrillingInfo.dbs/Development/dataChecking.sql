﻿
SELECT
	[t].[LeaseName],
	[t].*
FROM
	[stg].[DrillingInfoPermits]	[t]
WHERE
	([t].[LeaseName] LIKE '%GALVAN RANCH%');


SELECT
	[t].[LeaseName],
	[t].*
FROM
	[stg].[DrillingInfoWells]	[t]
WHERE
	([t].[LeaseName] LIKE '%SKEE%');


SELECT
	[p].[LeaseName],
	[w].[WellName],
	[p].*
FROM
	[stg].[DrillingInfoPermits]		[p]
INNER JOIN
	[stg].[DrillingInfoWells]		[w]
		ON	([p].[LeaseName]	=	[w].[LeaseName])


SELECT
	[l].*
FROM
	[stg].[DrillingInfoLeasesLegal]	[l]
WHERE
	([l].[DIBasin] = 'FORT WORTH');

	
SELECT
	geography::STGeomFromText([l].[Geometry], 4326),
	geometry::STGeomFromText([l].[Geometry], 0),
	[l].[Geometry],
	[l].[Grantor],
	[l].[Royalty],
	[l].*
FROM
	[stg].[DrillingInfoLeasesLandtrac]	[l]
WHERE
		([l].[Grantor] LIKE '%RUSSELL')
	AND	([l].[Grantor] LIKE '%W%')
	AND	([l].[GrantorAddress] LIKE '%37%')
	AND	([l].[GrantorAddress] LIKE '%LAK%');

		([l].[DIBasin] = 'FORT WORTH')
	AND	([l].[Royalty]	> 0.0);		--	21940
	--AND	([l].[Royalty]	IS NULL);	--	22524
