﻿EXECUTE [stg].[DeleteDrillingInfoRigs];

SELECT
	FORMAT(COUNT(*), '###,###,###')
FROM
	[stg].[DrillingInfoWells]	[t] WITH (NOLOCK);


SELECT
	MAX(LEN([t].[CountyParish]))
FROM
	[stg].[DrillingInfoDealsForSale]	[t] WITH (NOLOCK);


SELECT DISTINCT
	[t].[CountyParish]
FROM
	[stg].[DrillingInfoDealsForSale]	[t] WITH (NOLOCK);


--SELECT COUNT(*) FROM [stg].[DrillingInfoLeasesLandtrac_V]	[t]	WITH (NOLOCK);
--SELECT COUNT(*) FROM [stg].[DrillingInfoLeasesLegal_V]		[t]	WITH (NOLOCK);
--SELECT COUNT(*) FROM [stg].[DrillingInfoPermits_V]			[t]	WITH (NOLOCK);
--SELECT COUNT(*) FROM [stg].[DrillingInfoRigs_V]				[t]	WITH (NOLOCK);
--SELECT COUNT(*) FROM [stg].[DrillingInfoWells_V]			[t]	WITH (NOLOCK);



SELECT
	[t].*
FROM
	[track].[ApplicationLog]	[t] WITH (NOLOCK);

DELETE FROM [track].[ApplicationLogErrors];
DELETE FROM [track].[ApplicationLogEnd];
DELETE FROM [track].[ApplicationLogBegin];

EXECUTE [stg].[DeleteDrillingInfoRigs];

SELECT COUNT(*) FROM [stg].[DrillingInfoRigs];
