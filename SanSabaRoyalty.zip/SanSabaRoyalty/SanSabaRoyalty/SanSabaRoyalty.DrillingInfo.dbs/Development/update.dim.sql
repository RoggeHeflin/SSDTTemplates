﻿

SELECT DISTINCT
	[t].[OperatorCompanyName],
	[t].[OperatorTicker]
FROM
	[stg].[DrillingInfoDealsForSale]		[t]	WITH (NOLOCK);


SELECT DISTINCT
	[t].[OperatorAddress],
	[t].[OperatorAlias],
	[t].[OperatorCity],
	[t].[OperatorCity30mi],
	[t].[OperatorCity50mi],
	[t].[OperatorState],
	[t].[OperatorZip]
FROM
	[stg].[DrillingInfoPermits]		[t]	WITH (NOLOCK);


SELECT DISTINCT
	[t].[OperatorAddress],
	[t].[OperatorAlias],
	[t].[OperatorCity],
	[t].[OperatorCompanyName],
	[t].[OperatorContact],
	[t].[OperatorPhone],
	[t].[OperatorState],
	[t].[OperatorTicker],
	[t].[OperatorZip]
FROM
	[stg].[DrillingInfoRigs]		[t]	WITH (NOLOCK);


SELECT DISTINCT
	[t].[OperatorCompanyName],
	[t].[OperatorTicker]
FROM
	[stg].[DrillingInfoWells]		[t]	WITH (NOLOCK);



--	https://en.wikipedia.org/wiki/Levenshtein_distance
--	https://en.wikipedia.org/wiki/String_metric

SELECT DISTINCT
	[t].[Grantee],
	[t].[GranteeAddress],
	[t].[GranteeAlias],
	SOUNDEX([t].[Grantee])
FROM
	[stg].[DrillingInfoLeasesLegal]		[t]



SELECT DISTINCT
	[t].[Grantee],
	[t].[GranteeAddress],
	[t].[GranteeAlias]
FROM
	[stg].[DrillingInfoLeasesLandtrac]		[t]
