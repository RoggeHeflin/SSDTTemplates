﻿TRUNCATE TABLE [fact].[DrillingInfoPermits];;

SELECT
	[t].[API10],
	[t].[UpdatedDate],
	COUNT(*)
FROM
	[fact].[DrillingInfoPermits]	[t]
GROUP BY
	[t].[API10],
	[t].[UpdatedDate]
ORDER BY
	COUNT(*) DESC;

SELECT
	MAX([t].[LeaseName])
FROM
	[stg].[DrillingInfoPermits]	[t]
WHERE
	([t].[API10] = '4207733519');
