﻿CREATE PROCEDURE [dim].[InsertCurrentStatusLookup]
AS
BEGIN

	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 100;
	SET DEADLOCK_PRIORITY HIGH;

	DECLARE @TxnCount		INT				= @@TRANCOUNT;
	DECLARE @TxnActive		VARCHAR(32)		= REPLACE(CONVERT(VARCHAR(36), NEWID(), 0), '-', '');
	DECLARE @ErrorCode		INT				= 0;

	DECLARE @TrackingLogId	INT;
	EXECUTE @TrackingLogId	= [track].[InsertProcedureLogBegin] @@PROCID;

	IF (@TxnCount = 0) BEGIN TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	BEGIN TRY
	-----------------------------------------------------------------------------------------------

		DECLARE @CurrentStatus	TABLE
		(
			[CurrentStatus]				VARCHAR(24)			NOT	NULL,
			INDEX IX_@CurrentStatus NONCLUSTERED([CurrentStatus])
		);

		INSERT INTO @CurrentStatus
		(
			[CurrentStatus]
		)
		SELECT DISTINCT
			[CurrentStatus]		= RTRIM(LTRIM([s].[value]))
		FROM
			[stg].[DrillingInfoWells]	[t]
		CROSS APPLY
			STRING_SPLIT([t].[CurrentStatus], ',')	[s]
		WHERE
				([t].[CurrentStatus]	IS NOT NULL)
			AND	([s].[value]			<> '');

		INSERT INTO [dim].[CurrentStatusLookUp]
		(
			[CurrentStatus]
		)
		SELECT DISTINCT
			[t].[CurrentStatus]
		FROM
			@CurrentStatus		[t]
		WHERE
			([t].[CurrentStatus] NOT IN (SELECT [x].[CurrentStatus] FROM [dim].[CurrentStatusLookUp] [x] WITH(NOLOCK)));

	-----------------------------------------------------------------------------------------------
	IF (@TxnCount = 0) COMMIT TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	END TRY
	BEGIN CATCH

		SET @ErrorCode = @@ERROR;

		IF (XACT_STATE() = -1) ROLLBACK	TRANSACTION	@TxnActive;
		IF (XACT_STATE() =  1) COMMIT	TRANSACTION	@TxnActive;

		EXECUTE [track].[InsertProcedureLogError] @TrackingLogId;

		THROW;

		RETURN @ErrorCode;

	END CATCH;

	EXECUTE [track].[InsertProcedureLogEnd] @TrackingLogId;

	RETURN @ErrorCode;

END;