﻿CREATE PROCEDURE [dim].[InsertBasinLookUp]
AS
BEGIN

	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 100;
	SET DEADLOCK_PRIORITY HIGH;

	DECLARE @TxnCount		INT				= @@TRANCOUNT;
	DECLARE @TxnActive		VARCHAR(32)		= REPLACE(CONVERT(VARCHAR(36), NEWID(), 0), '-', '');
	DECLARE @ErrorCode		INT				= 0;

	DECLARE @TrackingLogId	INT;
	EXECUTE @TrackingLogId	= [track].[InsertProcedureLogBegin] @@PROCID;

	IF (@TxnCount = 0) BEGIN TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	BEGIN TRY
	-----------------------------------------------------------------------------------------------

		DECLARE @Basin TABLE
		(
			[Basin]				VARCHAR(48)		NOT	NULL,
			INDEX IX_@Basin NONCLUSTERED([Basin])
		);

		INSERT INTO @Basin
		(
			[Basin]
		)
		SELECT DISTINCT
			[Basin]		= RTRIM(LTRIM([s].[value]))
		FROM
			[stg].[DrillingInfoDealsForSale]	[t]
		CROSS APPLY
			STRING_SPLIT([t].[DIBasin], ',')	[s]
		WHERE
				([t].[DIBasin]	IS NOT NULL)
			AND	([s].[value]	<> '');

		INSERT INTO @Basin
		(
			[Basin]
		)
		SELECT DISTINCT
			[Basin]		= RTRIM(LTRIM([s].[value]))
		FROM
			[stg].[DrillingInfoLeasesLandtrac]	[t]
		CROSS APPLY
			STRING_SPLIT([t].[DIBasin], ',')	[s]
		WHERE
				([t].[DIBasin]	IS NOT NULL)
			AND	([s].[value]	<> '');

		INSERT INTO @Basin
		(
			[Basin]
		)
		SELECT DISTINCT
			[Basin]		= RTRIM(LTRIM([s].[value]))
		FROM
			[stg].[DrillingInfoLeasesLegal]	[t]
		CROSS APPLY
			STRING_SPLIT([t].[DIBasin], ',')	[s]
		WHERE
				([t].[DIBasin]	IS NOT NULL)
			AND	([s].[value]	<> '');

		INSERT INTO @Basin
		(
			[Basin]
		)
		SELECT DISTINCT
			[Basin]		= RTRIM(LTRIM([s].[value]))
		FROM
			[stg].[DrillingInfoPermits]	[t]
		CROSS APPLY
			STRING_SPLIT([t].[DIBasin], ',')	[s]
		WHERE
				([t].[DIBasin]	IS NOT NULL)
			AND	([s].[value]	<> '');

		INSERT INTO @Basin
		(
			[Basin]
		)
		SELECT DISTINCT
			[Basin]		= RTRIM(LTRIM([s].[value]))
		FROM
			[stg].[DrillingInfoRigs]	[t]
		CROSS APPLY
			STRING_SPLIT([t].[DIBasin], ',')	[s]
		WHERE
				([t].[DIBasin]	IS NOT NULL)
			AND	([s].[value]	<> '');

		INSERT INTO @Basin
		(
			[Basin]
		)
		SELECT DISTINCT
			[Basin]		= RTRIM(LTRIM([s].[value]))
		FROM
			[stg].[DrillingInfoWells]	[t]
		CROSS APPLY
			STRING_SPLIT([t].[Basin], ',')	[s]
		WHERE
				([t].[Basin]	IS NOT NULL)
			AND	([s].[value]	<> '');	

		INSERT INTO [dim].[BasinLookUp]
		(
			[Basin]
		)
		SELECT DISTINCT
			[t].[Basin]
		FROM
			@Basin		[t]
		WHERE
			([t].[Basin] NOT IN (SELECT [x].[Basin] FROM [dim].[BasinLookUp] [x] WITH(NOLOCK)));

	-----------------------------------------------------------------------------------------------
	IF (@TxnCount = 0) COMMIT TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	END TRY
	BEGIN CATCH

		SET @ErrorCode = @@ERROR;

		IF (XACT_STATE() = -1) ROLLBACK	TRANSACTION	@TxnActive;
		IF (XACT_STATE() =  1) COMMIT	TRANSACTION	@TxnActive;

		EXECUTE [track].[InsertProcedureLogError] @TrackingLogId;

		THROW;

		RETURN @ErrorCode;

	END CATCH;

	EXECUTE [track].[InsertProcedureLogEnd] @TrackingLogId;

	RETURN @ErrorCode;

END;