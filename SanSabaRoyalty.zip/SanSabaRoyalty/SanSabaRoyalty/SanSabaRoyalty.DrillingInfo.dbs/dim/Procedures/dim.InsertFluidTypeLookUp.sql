﻿CREATE PROCEDURE [dim].[InsertFluidTypeLookUp]
AS
BEGIN

	SET NOCOUNT ON;
	SET LOCK_TIMEOUT 100;
	SET DEADLOCK_PRIORITY HIGH;

	DECLARE @TxnCount		INT				= @@TRANCOUNT;
	DECLARE @TxnActive		VARCHAR(32)		= REPLACE(CONVERT(VARCHAR(36), NEWID(), 0), '-', '');
	DECLARE @ErrorCode		INT				= 0;

	DECLARE @TrackingLogId	INT;
	EXECUTE @TrackingLogId	= [track].[InsertProcedureLogBegin] @@PROCID;

	IF (@TxnCount = 0) BEGIN TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	BEGIN TRY
	-----------------------------------------------------------------------------------------------

		DECLARE @FluidType	TABLE
		(
			[FluidType]				VARCHAR(16)			NOT	NULL,
			INDEX IX_@FluidType NONCLUSTERED([FluidType])
		);

		INSERT INTO @FluidType
		(
			[FluidType]
		)
		SELECT DISTINCT
			[FluidType]		= RTRIM(LTRIM([s].[value]))
		FROM
			[stg].[DrillingInfoWells]	[t]
		CROSS APPLY
			STRING_SPLIT([t].[FluidType], ',')	[s]
		WHERE
				([t].[FluidType]	IS NOT NULL)
			AND	([s].[value]		<> '');

		INSERT INTO [dim].[FluidTypeLookUp]
		(
			[FluidType]
		)
		SELECT DISTINCT
			[t].[FluidType]
		FROM
			@FluidType		[t]
		WHERE
			([t].[FluidType] NOT IN (SELECT [x].[FluidType] FROM [dim].[FluidTypeLookUp] [x] WITH(NOLOCK)));

	-----------------------------------------------------------------------------------------------
	IF (@TxnCount = 0) COMMIT TRANSACTION @TxnActive ELSE SAVE TRANSACTION @TxnActive;
	END TRY
	BEGIN CATCH

		SET @ErrorCode = @@ERROR;

		IF (XACT_STATE() = -1) ROLLBACK	TRANSACTION	@TxnActive;
		IF (XACT_STATE() =  1) COMMIT	TRANSACTION	@TxnActive;

		EXECUTE [track].[InsertProcedureLogError] @TrackingLogId;

		THROW;

		RETURN @ErrorCode;

	END CATCH;

	EXECUTE [track].[InsertProcedureLogEnd] @TrackingLogId;

	RETURN @ErrorCode;

END;