﻿CREATE TABLE [dim].[FormationLookUp]
(
	[FormationLookUpId]				INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[Formation]						VARCHAR(48)			NOT	NULL,

	[txInserted]					DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_FormationLookUp_txInserted]				DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_FormationLookUp_txInsertedSid]			DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_FormationLookUp_txInsertedUser]			DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_FormationLookUp_txInsertedHost]			DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_FormationLookUp_txInsertedHost]			CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_FormationLookUp_txInsertedApp]			DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_FormationLookUp_txInsertedApp]			CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_FormationLookUp_txRowReplication]		DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_FormationLookUp_txRowVersion]			UNIQUE([txRowVersion]),

	CONSTRAINT [PK_FormationLookUp]		PRIMARY KEY CLUSTERED([FormationLookUpId]	ASC),
	CONSTRAINT [UK_FormationLookUp]		UNIQUE NONCLUSTERED([Formation] ASC)
);