﻿CREATE TABLE [dim].[CurrentStatusLookUp]
(
	[CurrentStatusLookUpId]			INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[CurrentStatus]					VARCHAR(24)			NOT	NULL,

	[txInserted]					DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_CurrentStatusLookUp_txInserted]				DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_CurrentStatusLookUp_txInsertedSid]			DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_CurrentStatusLookUp_txInsertedUser]			DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_CurrentStatusLookUp_txInsertedHost]			DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_CurrentStatusLookUp_txInsertedHost]			CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_CurrentStatusLookUp_txInsertedApp]			DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_CurrentStatusLookUp_txInsertedApp]			CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_CurrentStatusLookUp_txRowReplication]		DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_CurrentStatusLookUp_txRowVersion]			UNIQUE([txRowVersion]),

	CONSTRAINT [PK_CurrentStatusLookUp]		PRIMARY KEY CLUSTERED([CurrentStatusLookUpId]	ASC),
	CONSTRAINT [UK_CurrentStatusLookUp]		UNIQUE NONCLUSTERED([CurrentStatus] ASC)
);