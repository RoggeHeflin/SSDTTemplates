﻿CREATE TABLE [dim].[FluidTypeLookUp]
(
	[FluidTypeLookUpId]				INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[FluidType]						VARCHAR(16)			NOT	NULL,

	[txInserted]					DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_FluidTypeLookUp_txInserted]				DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_FluidTypeLookUp_txInsertedSid]			DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_FluidTypeLookUp_txInsertedUser]			DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_FluidTypeLookUp_txInsertedHost]			DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_FluidTypeLookUp_txInsertedHost]			CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_FluidTypeLookUp_txInsertedApp]			DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_FluidTypeLookUp_txInsertedApp]			CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_FluidTypeLookUp_txRowReplication]		DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_FluidTypeLookUp_txRowVersion]			UNIQUE([txRowVersion]),

	CONSTRAINT [PK_FluidTypeLookUp]		PRIMARY KEY CLUSTERED([FluidTypeLookUpId]	ASC),
	CONSTRAINT [UK_FluidTypeLookUp]		UNIQUE NONCLUSTERED([FluidType] ASC)
);