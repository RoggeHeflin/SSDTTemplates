﻿CREATE TABLE [dim].[BasinLookUp]
(
	[BasinLookUpId]					INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[Basin]							VARCHAR(48)			NOT	NULL,

	[txInserted]					DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_BasinLookUp_txInserted]				DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_BasinLookUp_txInsertedSid]			DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_BasinLookUp_txInsertedUser]			DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_BasinLookUp_txInsertedHost]			DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_BasinLookUp_txInsertedHost]			CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_BasinLookUp_txInsertedApp]			DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_BasinLookUp_txInsertedApp]			CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_BasinLookUp_txRowReplication]		DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_BasinLookUp_txRowVersion]			UNIQUE([txRowVersion]),

	CONSTRAINT [PK_BasinLookUp]		PRIMARY KEY CLUSTERED([BasinLookUpId]	ASC),
	CONSTRAINT [UK_BasinLookUp]		UNIQUE NONCLUSTERED([Basin] ASC)
);