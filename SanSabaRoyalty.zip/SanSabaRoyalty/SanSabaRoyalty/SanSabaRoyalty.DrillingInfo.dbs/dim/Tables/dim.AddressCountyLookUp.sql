﻿CREATE TABLE [dim].[AddressCountyLookUp]
(
	[AddressCountyLookUpId]			INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[Column1]						INT					NOT	NULL,

	[txInserted]					DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_AddressCountyLookUp_txInserted]				DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_AddressCountyLookUp_txInsertedSid]			DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_AddressCountyLookUp_txInsertedUser]			DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_AddressCountyLookUp_txInsertedHost]			DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_AddressCountyLookUp_txInsertedHost]			CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_AddressCountyLookUp_txInsertedApp]			DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_AddressCountyLookUp_txInsertedApp]			CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_AddressCountyLookUp_txRowReplication]		DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_AddressCountyLookUp_txRowVersion]			UNIQUE([txRowVersion]),

	CONSTRAINT [PK_AddressCountyLookUp]		PRIMARY KEY CLUSTERED([AddressCountyLookUpId]	ASC),
	CONSTRAINT [UK_AddressCountyLookUp]		UNIQUE NONCLUSTERED([Column1] ASC)
);