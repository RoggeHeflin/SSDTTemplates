﻿CREATE TABLE [dim].[OperatorLookUp]
(
	[OperatorLookUpId]				INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[Column1]						INT					NOT	NULL,

	[txInserted]					DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_OperatorLookUp_txInserted]				DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSid]					VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_OperatorLookUp_txInsertedSid]			DEFAULT(SUSER_SID()),
	[txInsertedUser]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_OperatorLookUp_txInsertedUser]			DEFAULT(SUSER_SNAME()),
	[txInsertedHost]				NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_OperatorLookUp_txInsertedHost]			DEFAULT(HOST_NAME()),
																	CONSTRAINT [CL_OperatorLookUp_txInsertedHost]			CHECK([txInsertedHost] <> ''),
	[txInsertedApp]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_OperatorLookUp_txInsertedApp]			DEFAULT(APP_NAME()),
																	CONSTRAINT [CL_OperatorLookUp_txInsertedApp]			CHECK([txInsertedApp] <> ''),
	[txRowReplication]				UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_OperatorLookUp_txRowReplication]			DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]					ROWVERSION			NOT	NULL	CONSTRAINT [UX_OperatorLookUp_txRowVersion]				UNIQUE([txRowVersion]),

	CONSTRAINT [PK_OperatorLookUp]		PRIMARY KEY CLUSTERED([OperatorLookUpId]	ASC),
	CONSTRAINT [UK_OperatorLookUp]		UNIQUE NONCLUSTERED([Column1] ASC)
);