import base64
import http.client
import json
import pandas as pd
from datetime import datetime, timedelta

import sqlalchemy
import numpy as np
# import pyspark


class DrillingInfoApplication:
    def __init__(self, api_key: str, api_id: str, api_secret: str,
                 sql_server: str, sql_port: str, sql_database: str, sql_driver: str,
                 sql_schema_stage: str, sql_schema_fact: str
                 ):

        self.api_key: str = api_key
        self.api_id: str = api_id
        self.api_secret: str = api_secret

        self.sql_server: str = sql_server
        self.sql_port: str = sql_port
        self.sql_database: str = sql_database
        self.sql_driver: str = sql_driver
        self.sql_schema_stage: str = sql_schema_stage
        self.sql_schema_fact: str = sql_schema_fact

        self.di: DrillingInfoApplication.DirectAccess = self.DirectAccess(self.api_key, self.api_id, self.api_secret)
        self.eng: sqlalchemy.engine = sqlalchemy.create_engine(
            f'mssql+pyodbc://{self.sql_server}:{self.sql_port}/{self.sql_database}?driver={self.sql_driver}')

    class DirectAccess:
        url: str = 'di-api.drillinginfo.com'
        url_version: str = '/v2/direct-access'
        user_agent: str = 'San Saba Royalty'

        def __init__(self, api_key: str, api_id: str, api_secret: str):
            self.api_key: str = api_key
            self.api_id: str = api_id
            self.api_secret: str = api_secret
            self.api_token = self.Token(self.api_key, self.api_id, self.api_secret, self.url, self.url_version,
                                        self.user_agent)

        class Token:
            def __init__(self, api_key: str, api_id: str, api_secret: str, url: str, url_version: str, user_agent: str):
                self.api_key = api_key
                self.api_id = api_id
                self.api_secret = api_secret
                self.url = url
                self.url_version = url_version
                self.user_agent = user_agent

                self.jsn = self.__get_api_token()
                self.expires_at: datetime = datetime.now() + timedelta(seconds=self.jsn['expires_in'])

            def __get_api_token(self) -> dict:
                url_suffix: str = self.url_version + '/tokens'
                content_type: str = 'application/x-www-form-urlencoded'
                payload: str = "grant_type=client_credentials"
                api_encrypted: str = 'basic ' + base64.b64encode(
                    (self.api_id + ":" + self.api_secret).encode()).decode()
                headers = {
                    'X-API-KEY': self.api_key,
                    'Content-Type': content_type,
                    'Authorization': api_encrypted,
                    'User - Agent': self.user_agent
                }

                con = http.client.HTTPSConnection(self.url)
                con.request("POST", url_suffix, payload, headers)

                res = con.getresponse()
                byt = res.read()
                jsn = json.loads(byt)

                return jsn

            def __is_expired(self) -> bool:
                return datetime.now() >= self.expires_at

            def bearer_token(self) -> str:
                if self.__is_expired():
                    self.jsn = self.__get_api_token()
                return 'bearer ' + self.jsn['access_token']

        def __get_api_results_dataframe(self, url_suffix: str, df=pd.DataFrame()) -> pd.DataFrame:
            payload = ''
            headers = {
                'X-API-KEY': self.api_key,
                'Authorization': self.api_token.bearer_token()
            }

            con = http.client.HTTPSConnection(self.url)
            con.request('GET', self.url_version + url_suffix, payload, headers)
            res = con.getresponse()
            byt = res.read()
            dtf = pd.read_json(byt)

            dfa = df.append(dtf)

            hdr = res.getheader('Link')
            hdr = hdr[1:len(hdr) - 13]

            print(hdr)

            if len(dtf.index) == 0:
                return dfa
            else:
                return self.__get_api_results_dataframe(hdr, dfa)

        def get_api_results(self, data_set: str, **options) -> pd.DataFrame:
            s = '?'

            for k, v in options.items():
                s = s + ('' if (s == '?') else '&') + ("{0}={1}".format(k, v))
            url_suffix = '/' + data_set + s

            return self.__get_api_results_dataframe(url_suffix)

    def process_data(self, sql_table: str, api_dataset: str, api_filter: dict):
        sql_delete: str = f'[{self.sql_schema_stage}].[Truncate{sql_table}]'
        sql_insert: str = f'[{self.sql_schema_fact}].[Insert{sql_table}]'
        sql_return_update: str = f'[{self.sql_schema_fact}].[Return{sql_table}LastApiUpdate]'

        with self.eng.connect().execution_options(autocommit=True) as con:
            con.execute(sql_delete)

        with self.eng.connect() as con:
            update_datestamp: str = str(con.execute(sql_return_update).fetchone()[0])

        if update_datestamp == 'None':
            api_filter['DeletedDate'] = 'eq(null)'
        else:
            api_filter['UpdatedDate'] = f'gt({update_datestamp})'

        self.load_data(sql_table, api_dataset, api_filter)

        with self.eng.connect().execution_options(autocommit=True) as con:
            con.execute(sql_insert)

    def load_data(self, sql_table: str, api_dataset: str, api_filter: dict):
        df: pd.DataFrame = self.di.get_api_results(api_dataset, **api_filter)
        df.to_sql(name=sql_table, schema=self.sql_schema_stage, con=self.eng, if_exists='append')

        # sdf = spark.createDataFrame(df)
        # sdf.write.mode('append').saveAsTable(f'{self.sql_schema_stage}.{sql_table}')

    def load_data_to_sql(self, sql_table: str, df: pd.DataFrame):
        df.to_sql(name=sql_table, schema=self.sql_schema_stage, con=self.eng, if_exists='append')


########################################################################################################################
# region Initialization

key: str = '3c7466645939dba3b07d705ee9900dd9'
client: str = '532-direct-access'
secret: str = 'a973bd7c-ec61-413a-bda9-887a85570522'

sql_server: str = 'ThinkPadT440p\\SQL'
sql_port: str = '54075'
sql_database: str = 'DrillingInfo'
sql_driver: str = 'SQL Server Native Client 11.0'

sql_schema_stage: str = 'stg'
sql_schema_fact: str = 'fact'

dia: DrillingInfoApplication = DrillingInfoApplication(key, client, secret,
                                                       sql_server, sql_port, sql_database, sql_driver,
                                                       sql_schema_stage, sql_schema_fact)
# endregion

########################################################################################################################
# region rigs

tgt: str = 'DrillingInfoRigs'
src: str = 'rigs'

ftr: dict = {}
ftr.clear()
ftr['pagesize'] = 10000
ftr['DIStateProvinceCode'] = 'TX'

dia.process_data(tgt, src, ftr)

# endregion

########################################################################################################################
# region permits

tgt: str = 'DrillingInfoPermits'
src: str = 'permits'

ftr: dict = {}
ftr.clear()
ftr['pagesize'] = 10000
ftr['StateProvince'] = 'TX'
ftr['UpdatedDate'] = 'gt(2021-02-01)'

dia.process_data(tgt, src, ftr)

# endregion

########################################################################################################################
# region Leases: Legal

tgt: str = 'DrillingInfoLeasesLegal'
src: str = 'legal-leases'

ftr: dict = {}
ftr.clear()
ftr['pagesize'] = 10000
ftr['State'] = 'TX'
ftr['UpdatedDate'] = 'gt(2021-02-01)'

dia.process_data(tgt, src, ftr)

# endregion

########################################################################################################################
# region Leases: Landtrac

tgt: str = 'DrillingInfoLeasesLegal'
src: str = 'landtrac-leases'

ftr: dict = {}
ftr.clear()
ftr['pagesize'] = 10000
ftr['State'] = 'TX'
ftr['UpdatedDate'] = 'gt(2021-02-01)'

# endregion

########################################################################################################################
# region debug data profile

da_debug = dia.DirectAccess(key, client, secret)
df_debug = da_debug.get_api_results(src, **ftr)
dia.load_data_to_sql(tgt, df_debug)

msr = np.vectorize(len)
res = dict(zip(df_debug, msr(df_debug.values.astype(str)).max(axis=0)))
print(res)

# endregion

########################################################################################################################
# region datasets

# producing-entities
# producing-entity-stats
# producing-entity-details
# well-origins
# wellbores
# trajectories
# trajectory-stations
# completions
# formation-tops
# welltest-headers
# welltest-details
# perforations
# casing-tubings
# treatment-jobs
# treatment-materials
# treatment-stages
# packers
# intl-scout-articles
# permits
# applications
# application-formations
# application-locations
# orders
# order-formations
# order-locations
# additive-summary-headers
# additive-summary-details
# rigs
# rig-analytics
# landtrac-leases
# landtrac-units
# legal-leases
# well-rollups
# well-spacings
# well-production-details
# injection-entity-details
# company-acreage
# deals-for-sale
# transactions
# landtrac-midland-maps
# respondents

# endregion

########################################################################################################################
# region databricks

# engine = create_engine(
#     "databricks+pyhive://token:<databrickstoken>@<region>.azuredatabricks.net:443/<database>",
#     connect_args={"http_path": "<azure_databricks_http_path>"}
# )

bricks_token: str = 'dapi821d59cc309b66f7ebb6618c187b7531'
bricks_region: str = 'adb-4434002371391114.14'
bricks_database: str = 'default'
bricks_cluster: str = 'DrillingInfo'
bricks_path: str = 'https://adb-4434002371391114.14.azuredatabricks.net/?o=4434002371391114#'

bricks = sqlalchemy.create_engine(
    f'databricks+pyhive://token:{bricks_token}@{bricks_region}.azuredatabricks.net:443/{bricks_database}',
    connect_args={'http_path': bricks_path}
)

metadata = sqlalchemy.MetaData(bind=None)
table = sqlalchemy.Table('rigs', metadata, autoload=True, autoload_with=bricks)
stmt = sqlalchemy.select([table])

col = getattr(table.c, 'UpdatedDate')
qry = sqlalchemy.select([sqlalchemy.func.max(col)], table)

with bricks.connect() as con:
    res = con.execute(qry)
    val = res.fetchone()[0]
    con.close()

print(val)

# endregion
