﻿CREATE TABLE [dbo].[LeaseAnalyses]
(
	[LeaseAnalysisId]					INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[OfferDate]							DATE				NOT	NULL,
	[EffectiveDate]						DATE				NOT	NULL,
	[SignatoryId]						INT					NOT	NULL	CONSTRAINT [FK_LeaseAnalyses_Signatories]			REFERENCES [dbo].[Signatories]([SignatoryId]),

	[WellName]							NVARCHAR(256)		NOT	NULL,
	[WellCounty]						NVARCHAR(256)		NOT	NULL,
	[WellState]							NVARCHAR(2)			NOT	NULL,
	[WellAcres]							DECIMAL(10, 2)		NOT	NULL,

	[WellOperator]						NVARCHAR(256)		NOT	NULL,

	[NetRevenue_Pcnt]					DECIMAL(11, 10)		NOT	NULL,
	[NetRevenue_Interest_Pcnt]			DECIMAL(11, 10)		NOT	NULL,
	[NetRevenue_Month_Gas]				MONEY				NOT	NULL,
	[NetRevenue_Month_Oil]				MONEY				NOT	NULL,
	[NetRevenue_Month]					MONEY				NOT	NULL,

	[InitialProduction_MCFD]			DECIMAL(10, 4)		NOT	NULL,
	[InitialProduction_BOPD]			DECIMAL(10, 4)		NOT	NULL,
	[GrossProduction_MCFD]				DECIMAL(12, 6)		NOT	NULL,
	[GrossProduction_BOPD]				DECIMAL(12, 6)		NOt	NULL,

	[Payout_MCF]						MONEY				NOT	NULL,
	[Payout_BBL]						MONEY				NOT	NULL,

	[SeveranceTax_Oil_Pcnt]				DECIMAL(7, 6)		NOT	NULL,
	[SeveranceTax_Gas_Pcnt]				DECIMAL(7, 6)		NOT	NULL,

	[Price_Gas_MFC]						DECIMAL(8, 4)		NOT	NULL,
	[Price_Oil_BBL]						DECIMAL(8, 4)		NOT	NULL,

	[PDP_WellCount]						INT						NULL,
	[PDP_Value]							MONEY					NULL,
	[PDP_RiskFactor]					DECIMAL(8, 4)			NULL,
	[PDP_NRI_OnePcnt]					MONEY					NULL,

	[PDP_A_Value]						MONEY					NULL,
	[PDP_B_Value]						MONEY					NULL,
	[PDP_PresentWorth_A_Pcnt]			DECIMAL(8, 4)			NULL,
	[PDP_PresentWorth_B_Pcnt]			DECIMAL(8, 4)			NULL,

	[PDP_NoProd_WellCount]				INT						NULL,
	[PDP_NoProd_Value]					MONEY					NULL,
	[PDP_NoProd_RiskFactor]				DECIMAL(8, 4)			NULL,
	[PDP_NoProd_NRI_OnePcnt]			MONEY					NULL,

	[PDP_NoProd_A_Value]				MONEY					NULL,
	[PDP_NoProd_B_Value]				MONEY					NULL,
	[PDP_NoProd_PresentWorth_A_Pcnt]	DECIMAL(8, 4)			NULL,
	[PDP_NoProd_PresentWorth_B_Pcnt]	DECIMAL(8, 4)			NULL,

	[PUD1_WellCount]					INT						NULL,
	[PUD1_Value]						MONEY					NULL,
	[PUD1_RiskFactor]					DECIMAL(8, 4)			NULL,
	[PUD1_NRI_OnePcnt]					MONEY					NULL,

	[PUD2_WellCount]					INT						NULL,
	[PUD2_Value]						MONEY					NULL,
	[PUD2_RiskFactor]					DECIMAL(8, 4)			NULL,
	[PUD2_NRI_OnePcnt]					MONEY					NULL,

	[PotentialWells_Count]				INT						NULL,
	[Permit_Count]						INT						NULL,
	[Value_Possible]					MONEY					NULL,
	[Value_PerRoyAcre]					MONEY					NULL,
	[Value_AddOnMult]					DECIMAL(8, 4)			NULL,
	[Value_AddOnAcreage]				DECIMAL(8, 4)			NULL,

	[ProducingFormations]				NVARCHAR(256)			NULL,

	[Offer_OnePcnt]						MONEY				NOT	NULL,

	[PDP_Pcnt]							DECIMAL(8, 4)			NULL,
	[PUD_Pcnt]							DECIMAL(8, 4)			NULL,

	[txInserted]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txInsertedSID]			DEFAULT(SUSER_SID()),
	[txInsertedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txInsertedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseAnalyses_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txInsertedApp]			DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseAnalyses_txInsertedApp]			CHECK([txInsertedApp] <> ''),

	[txModified]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txModified]			DEFAULT(SYSDATETIMEOFFSET()),
	[txModifiedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txModifiedSID]			DEFAULT(SUSER_SID()),
	[txModifiedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txModifiedUser]		DEFAULT(SUSER_SNAME()),
	[txModifiedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txModifiedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseAnalyses_txModifiedHost]		CHECK([txModifiedHost] <> ''),
	[txModifiedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txModifiedApp]			DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseAnalyses_txModifiedApp]			CHECK([txModifiedApp] <> ''),

	[txRowVersion]						ROWVERSION			NOT	NULL	CONSTRAINT [UX_LeaseAnalyses_txRowVersion]			UNIQUE([txRowVersion]),
	[txRowReplication]					UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_LeaseAnalyses_txRowReplication]		DEFAULT(NEWSEQUENTIALID()) ROWGUIDCOL,
																		CONSTRAINT [UX_LeaseAnalyses_txRowReplication]		UNIQUE([txRowReplication]),

	CONSTRAINT [PK_LeaseAnalyses]	PRIMARY KEY NONCLUSTERED([LeaseAnalysisId] ASC),
	CONSTRAINT [UK_LeaseAnalyses]	UNIQUE CLUSTERED(
										[WellName]			ASC,
										[WellCounty]		ASC,
										[WellState]			ASC,
										[OfferDate]			ASC,
										[EffectiveDate]		ASC
									)
);
GO

CREATE TRIGGER [dbo].[LeaseAnalyses_Trigger_AfterUpdate]
ON [dbo].[LeaseAnalyses]
AFTER UPDATE
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [dbo].[LeaseAnalyses]
	SET
		[txModified]		= SYSDATETIMEOFFSET(),
		[txModifiedSID]		= SUSER_SID(),
		[txModifiedUser]	= SUSER_SNAME(),
		[txModifiedHost]	= HOST_NAME(),
		[txModifiedApp]		= APP_NAME()
	WHERE
		([dbo].[LeaseAnalyses].[LeaseAnalysisId] IN (SELECT [i].[LeaseAnalysisId] FROM inserted [i]));

END;