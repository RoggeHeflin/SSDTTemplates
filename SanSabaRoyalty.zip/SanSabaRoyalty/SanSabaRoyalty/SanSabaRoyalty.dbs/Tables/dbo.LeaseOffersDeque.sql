﻿CREATE TABLE [dbo].[LeaseOffersDeque]
(
	[LeaseOffersDequeId]				INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[LeaseOfferId]						INT					NOT	NULL	CONSTRAINT [FK_LeaseOffersDeque_LeaseOffer]			REFERENCES [dbo].[LeaseOffers]([LeaseOfferId]),

	[txInserted]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txInsertedSID]		DEFAULT(SUSER_SID()),
	[txInsertedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txInsertedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseOffersDeque_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txInsertedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseOffersDeque_txInsertedApp]		CHECK([txInsertedApp] <> ''),

	[txModified]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txModified]			DEFAULT(SYSDATETIMEOFFSET()),
	[txModifiedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txModifiedSID]		DEFAULT(SUSER_SID()),
	[txModifiedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txModifiedUser]		DEFAULT(SUSER_SNAME()),
	[txModifiedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txModifiedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseOffersDeque_txModifiedHost]		CHECK([txModifiedHost] <> ''),
	[txModifiedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txModifiedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseOffersDeque_txModifiedApp]		CHECK([txModifiedApp] <> ''),

	[txRowVersion]						ROWVERSION			NOT	NULL	CONSTRAINT [UX_LeaseOffersDeque_txRowVersion]		UNIQUE([txRowVersion]),
	[txRowReplication]					UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_LeaseOffersDeque_txRowReplication]	DEFAULT(NEWSEQUENTIALID()) ROWGUIDCOL,
																		CONSTRAINT [UX_LeaseOffersDeque_txRowReplication]	UNIQUE([txRowReplication]),

	CONSTRAINT [PK_LeaseOffersDeque]	PRIMARY KEY NONCLUSTERED([LeaseOffersDequeId] ASC),
	CONSTRAINT [UK_LeaseOffersDeque]	UNIQUE CLUSTERED([LeaseOfferId] ASC)
);
GO

CREATE TRIGGER [dbo].[LeaseOffersDeque_Trigger_AfterUpdate]
ON [dbo].[LeaseOffersDeque]
AFTER UPDATE
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [dbo].[LeaseOffersDeque]
	SET
		[txModified]		= SYSDATETIMEOFFSET(),
		[txModifiedSID]		= SUSER_SID(),
		[txModifiedUser]	= SUSER_SNAME(),
		[txModifiedHost]	= HOST_NAME(),
		[txModifiedApp]		= APP_NAME()
	WHERE
		([dbo].[LeaseOffersDeque].[LeaseOffersDequeId] IN (SELECT [i].[LeaseOffersDequeId] FROM inserted [i]));

END;