﻿CREATE TABLE [dbo].[LeaseProductionPermits]
(
	[LeaseProductionPermitsId]			INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[LeaseAnalysisId]					INT					NOT	NULL	CONSTRAINT [FK_LeaseProductionPermits__LeaseAnalyses]		REFERENCES [dbo].[LeaseAnalyses]([LeaseAnalysisId]),
	[RowNumber]							INT					NOT	NULL,

	[API_Number]						NVARCHAR(12)		NOT	NULL,
	[OperatorName]						NVARCHAR(256)		NOT	NULL,

	[WellName]							NVARCHAR(256)		NOT	NULL,
	[WellCounty]						NVARCHAR(256)		NOT	NULL,
	[WellNumber]						NVARCHAR(256)		NOT	NULL,
	[WellType]							NVARCHAR(256)			NULL,
	[WellStatus]						NVARCHAR(256)			NULL,

	[Issue_Date]						DATE					NULL,

	[Depth_Permit]						DECIMAL(10, 2)			NULL,
	[Depth_Total]						DECIMAL(10, 2)			NULL,

	[HasImages]							NVARCHAR(3)				NULL,
	[HasDoc]							NVARCHAR(256)			NULL,

	[Letter]							NVARCHAR(256)			NULL,
	[FieldName]							NVARCHAR(256)			NULL,
	[PracIP_BOD]						DECIMAL(10, 4)			NULL,
	[PracIP_MCFD]						DECIMAL(10, 4)			NULL,
	[ProductionFirst_Date]				DATE					NULL,
	[ProductionLast_Date]				DATE					NULL,
	[ProdAvg_BOD]						DECIMAL(8, 4)			NULL,
	[ProdAvg_MCFD]						DECIMAL(8, 4)			NULL,

	[Cumulative_Oil]					DECIMAL(10, 2)			NULL,
	[Cumulative_Gas]					DECIMAL(10, 2)			NULL,

	[txInserted]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txInsertedSID]		DEFAULT(SUSER_SID()),
	[txInsertedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txInsertedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseProductionPermits_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txInsertedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseProductionPermits_txInsertedApp]		CHECK([txInsertedApp] <> ''),

	[txModified]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txModified]			DEFAULT(SYSDATETIMEOFFSET()),
	[txModifiedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txModifiedSID]		DEFAULT(SUSER_SID()),
	[txModifiedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txModifiedUser]		DEFAULT(SUSER_SNAME()),
	[txModifiedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txModifiedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseProductionPermits_txModifiedHost]		CHECK([txModifiedHost] <> ''),
	[txModifiedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txModifiedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseProductionPermits_txModifiedApp]		CHECK([txModifiedApp] <> ''),

	[txRowVersion]						ROWVERSION			NOT	NULL	CONSTRAINT [UX_LeaseProductionPermits_txRowVersion]			UNIQUE([txRowVersion]),
	[txRowReplication]					UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_LeaseProductionPermits_txRowReplication]		DEFAULT(NEWSEQUENTIALID()) ROWGUIDCOL,
																		CONSTRAINT [UX_LeaseProductionPermits_txRowReplication]		UNIQUE([txRowReplication]),

	CONSTRAINT [PK_LeaseProductionPermits]	PRIMARY KEY NONCLUSTERED([LeaseProductionPermitsId] ASC),
	CONSTRAINT [UK_LeaseProductionPermits]	UNIQUE CLUSTERED(
										[LeaseAnalysisId]		ASC,
										[API_Number]			ASC
									)
);
GO

CREATE TRIGGER [dbo].[LeaseProductionPermits_Trigger_AfterUpdate]
ON [dbo].[LeaseProductionPermits]
AFTER UPDATE
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [dbo].[LeaseProductionPermits]
	SET
		[txModified]		= SYSDATETIMEOFFSET(),
		[txModifiedSID]		= SUSER_SID(),
		[txModifiedUser]	= SUSER_SNAME(),
		[txModifiedHost]	= HOST_NAME(),
		[txModifiedApp]		= APP_NAME()
	WHERE
		([dbo].[LeaseProductionPermits].[LeaseProductionPermitsId] IN (SELECT [i].[LeaseProductionPermitsId] FROM inserted [i]));

END;