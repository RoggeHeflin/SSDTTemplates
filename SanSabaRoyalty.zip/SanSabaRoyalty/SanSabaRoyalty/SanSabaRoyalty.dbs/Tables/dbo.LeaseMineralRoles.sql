﻿CREATE TABLE [dbo].[LeaseMineralRoles]
(
	[LeaseMineralRolesId]				INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[LeaseAnalysisId]					INT					NOT	NULL	CONSTRAINT [FK_LeaseMineralRoles__LeaseAnalyses]		REFERENCES [dbo].[LeaseAnalyses]([LeaseAnalysisId]),
	[RowNumber]							INT					NOT	NULL,

	[WellName]							NVARCHAR(256)		NOT	NULL,
	[WellSurvey]						NVARCHAR(256)		NOT	NULL,
	[WellAbstract]						NVARCHAR(256)		NOT	NULL,
	[WellOperator]						NVARCHAR(256)		NOT	NULL,

	[OwnerName]							NVARCHAR(256)		NOT	NULL,
	[OwnerAddress1]						NVARCHAR(256)			NULL,
	[OwnerAddress2]						NVARCHAR(256)		NOT	NULL,
	[OwnerCounty]						NVARCHAR(256)		NOT	NULL,
	[OwnerCity]							NVARCHAR(256)		NOT	NULL,
	[OwnerState]						NVARCHAR(2)			NOT	NULL,
	[OwnerPostalCode]					NVARCHAR(12)		NOT	NULL,
	[OwnerPostalCodeExt]				NVARCHAR(12)			NULL,

	[OwnerInterestType]					NCHAR(2)			NOT	NULL,
	[OwnerInterestPcnt]					DECIMAL(11, 10)		NOT	NULL,

	[WellField]							VARCHAR(256)			NULL,
	[OwnerValue]						MONEY				NOT	NULL,
	[LeaseAcres]						DECIMAL(8, 2)			NULL,
	[LeaseDate]							DATE				NOT	NULL,

	[txInserted]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txInserted]		DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txInsertedSID]		DEFAULT(SUSER_SID()),
	[txInsertedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txInsertedUser]	DEFAULT(SUSER_SNAME()),
	[txInsertedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txInsertedHost]	DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseMineralRoles_txInsertedHost]	CHECK([txInsertedHost] <> ''),
	[txInsertedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txInsertedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseMineralRoles_txInsertedApp]		CHECK([txInsertedApp] <> ''),

	[txModified]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txModified]		DEFAULT(SYSDATETIMEOFFSET()),
	[txModifiedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txModifiedSID]		DEFAULT(SUSER_SID()),
	[txModifiedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txModifiedUser]	DEFAULT(SUSER_SNAME()),
	[txModifiedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txModifiedHost]	DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseMineralRoles_txModifiedHost]	CHECK([txModifiedHost] <> ''),
	[txModifiedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txModifiedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseMineralRoles_txModifiedApp]		CHECK([txModifiedApp] <> ''),

	[txRowVersion]						ROWVERSION			NOT	NULL	CONSTRAINT [UX_LeaseMineralRoles_txRowVersion]		UNIQUE([txRowVersion]),
	[txRowReplication]					UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_LeaseMineralRoles_txRowReplication]	DEFAULT(NEWSEQUENTIALID()) ROWGUIDCOL,
																		CONSTRAINT [UX_LeaseMineralRoles_txRowReplication]	UNIQUE([txRowReplication]),

	CONSTRAINT [PK_LeaseMineralRoles]	PRIMARY KEY NONCLUSTERED([LeaseMineralRolesId] ASC),
	CONSTRAINT [UK_LeaseMineralRoles]	UNIQUE CLUSTERED(
											[LeaseAnalysisId]		ASC,
											[OwnerName]				ASC,
											[OwnerInterestType]		ASC
										)
);
GO

CREATE TRIGGER [dbo].[LeaseMineralRoles_Trigger_AfterUpdate]
ON [dbo].[LeaseMineralRoles]
AFTER UPDATE
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [dbo].[LeaseMineralRoles]
	SET
		[txModified]		= SYSDATETIMEOFFSET(),
		[txModifiedSID]		= SUSER_SID(),
		[txModifiedUser]	= SUSER_SNAME(),
		[txModifiedHost]	= HOST_NAME(),
		[txModifiedApp]		= APP_NAME()
	WHERE
		([dbo].[LeaseMineralRoles].[LeaseMineralRolesId] IN (SELECT [i].[LeaseMineralRolesId] FROM inserted [i]));

END;