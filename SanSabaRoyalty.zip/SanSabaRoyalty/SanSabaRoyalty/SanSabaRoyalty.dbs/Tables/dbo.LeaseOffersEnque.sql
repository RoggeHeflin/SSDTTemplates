﻿CREATE TABLE [dbo].[LeaseOffersEnque]
(
	[LeaseOffersEnqueId]				INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[LeaseOfferId]						INT					NOT	NULL	CONSTRAINT [FK_LeaseOffersEnque_LeaseOffer]			REFERENCES [dbo].[LeaseOffers]([LeaseOfferId]),

	[txInserted]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txInsertedSID]		DEFAULT(SUSER_SID()),
	[txInsertedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txInsertedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseOffersEnque_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txInsertedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseOffersEnque_txInsertedApp]		CHECK([txInsertedApp] <> ''),

	[txModified]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txModified]			DEFAULT(SYSDATETIMEOFFSET()),
	[txModifiedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txModifiedSID]		DEFAULT(SUSER_SID()),
	[txModifiedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txModifiedUser]		DEFAULT(SUSER_SNAME()),
	[txModifiedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txModifiedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseOffersEnque_txModifiedHost]		CHECK([txModifiedHost] <> ''),
	[txModifiedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txModifiedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseOffersEnque_txModifiedApp]		CHECK([txModifiedApp] <> ''),

	[txRowVersion]						ROWVERSION			NOT	NULL	CONSTRAINT [UX_LeaseOffersEnque_txRowVersion]		UNIQUE([txRowVersion]),
	[txRowReplication]					UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_LeaseOffersEnque_txRowReplication]	DEFAULT(NEWSEQUENTIALID()) ROWGUIDCOL,
																		CONSTRAINT [UX_LeaseOffersEnque_txRowReplication]	UNIQUE([txRowReplication]),

	CONSTRAINT [PK_LeaseOffersEnque]	PRIMARY KEY NONCLUSTERED([LeaseOffersEnqueId] ASC),
	CONSTRAINT [UK_LeaseOffersEnque]	UNIQUE CLUSTERED([LeaseOfferId] ASC)
);
GO

CREATE TRIGGER [dbo].[LeaseOffersEnque_Trigger_AfterUpdate]
ON [dbo].[LeaseOffersEnque]
AFTER UPDATE
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [dbo].[LeaseOffersEnque]
	SET
		[txModified]		= SYSDATETIMEOFFSET(),
		[txModifiedSID]		= SUSER_SID(),
		[txModifiedUser]	= SUSER_SNAME(),
		[txModifiedHost]	= HOST_NAME(),
		[txModifiedApp]		= APP_NAME()
	WHERE
		([dbo].[LeaseOffersEnque].[LeaseOffersEnqueId] IN (SELECT [i].[LeaseOffersEnqueId] FROM inserted [i]));

END;