﻿CREATE TABLE [dbo].[LeaseOffers]
(
	[LeaseOfferId]						INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[LeaseAnalysisId]					INT					NOT	NULL	CONSTRAINT [FK_LeaseOffers__LeaseAnalyses]		REFERENCES [dbo].[LeaseAnalyses]([LeaseAnalysisId]),
	[RowNumber]							INT					NOT	NULL,

	[WellName]							NVARCHAR(256)		NOT	NULL,
	[WellCounty]						NVARCHAR(256)		NOT	NULL,
	[WellState]							NVARCHAR(2)			NOT	NULL,
	[WellAcres]							DECIMAL(10, 2)		NOT	NULL,
	[WellSurvey]						NVARCHAR(256)		NOT	NULL,
	[WellAbstract]						NVARCHAR(256)		NOT	NULL,
	[WellOperator]						NVARCHAR(256)		NOT	NULL,

	[OwnerInterestType]					NCHAR(2)			NOT	NULL,
	[OwnerInterestPcnt]					DECIMAL(11, 10)		NOT	NULL,
	[OwnerValue]						MONEY				NOT	NULL,
	[OwnerName]							NVARCHAR(256)		NOT	NULL,
	[OwnerAddress1]						NVARCHAR(256)			NULL,
	[OwnerAddress2]						NVARCHAR(256)		NOT	NULL,
	[OwnerCity]							NVARCHAR(256)		NOT	NULL,
	[OwnerState]						NVARCHAR(2)			NOT	NULL,
	[OwnerPostalCode]					NVARCHAR(24)		NOT	NULL,

	[OfferAmount]						MONEY				NOT	NULL,
	[OfferDate]							DATE				NOT	NULL,
	[OfferEffectiveDate]				DATE				NOT	NULL,
	[OfferLetter]						NVARCHAR(256)		NOT	NULL,
	[OfferAmountLetter]					MONEY				NOT	NULL,

	[WellRevenueMonthly]				MONEY				NOT	NULL,

	[OwnerEMailAddress]					NVARCHAR(256)			NULL,
	[OwnerPhoneNumber]					NVARCHAR(50)			NULL,

	[txInserted]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseOffers_txInserted]			DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseOffers_txInsertedSID]		DEFAULT(SUSER_SID()),
	[txInsertedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffers_txInsertedUser]		DEFAULT(SUSER_SNAME()),
	[txInsertedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffers_txInsertedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseOffers_txInsertedHost]		CHECK([txInsertedHost] <> ''),
	[txInsertedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffers_txInsertedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseOffers_txInsertedApp]		CHECK([txInsertedApp] <> ''),

	[txModified]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_LeaseOffers_txModified]			DEFAULT(SYSDATETIMEOFFSET()),
	[txModifiedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_LeaseOffers_txModifiedSID]		DEFAULT(SUSER_SID()),
	[txModifiedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffers_txModifiedUser]		DEFAULT(SUSER_SNAME()),
	[txModifiedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffers_txModifiedHost]		DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_LeaseOffers_txModifiedHost]		CHECK([txModifiedHost] <> ''),
	[txModifiedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_LeaseOffers_txModifiedApp]		DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_LeaseOffers_txModifiedApp]		CHECK([txModifiedApp] <> ''),

	[txRowVersion]						ROWVERSION			NOT	NULL	CONSTRAINT [UX_LeaseOffers_txRowVersion]		UNIQUE([txRowVersion]),
	[txRowReplication]					UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_LeaseOffers_txRowReplication]	DEFAULT(NEWSEQUENTIALID()) ROWGUIDCOL,
																		CONSTRAINT [UX_LeaseOffers_txRowReplication]	UNIQUE([txRowReplication]),

	CONSTRAINT [PK_LeaseOffers]	PRIMARY KEY NONCLUSTERED([LeaseOfferId] ASC),
	CONSTRAINT [UK_LeaseOffers]	UNIQUE CLUSTERED(
											[LeaseAnalysisId]	ASC,
											[OwnerName]			ASC
										)
);
GO

CREATE TRIGGER [dbo].[LeaseOffers_Trigger_AfterUpdate]
ON [dbo].[LeaseOffers]
AFTER UPDATE
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [dbo].[LeaseOffers]
	SET
		[txModified]		= SYSDATETIMEOFFSET(),
		[txModifiedSID]		= SUSER_SID(),
		[txModifiedUser]	= SUSER_SNAME(),
		[txModifiedHost]	= HOST_NAME(),
		[txModifiedApp]		= APP_NAME()
	WHERE
		([dbo].[LeaseOffers].[LeaseOfferId] IN (SELECT [i].[LeaseOfferId] FROM inserted [i]));

END;