﻿CREATE TABLE [dbo].[Signatories]
(
	[SignatoryId]						INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[SignatoryNameFull]					VARCHAR(48)			NOT	NULL	CONSTRAINT [CK_Signatories_SignatoryNameFull]		CHECK([SignatoryNameFull] <> ''),

	[EMailRfc5321]						VARCHAR(254)		NOT	NULL	CONSTRAINT [CK_Signatories_EMailRfc5321]			CHECK([EMailRfc5321] <> ''),
																		CONSTRAINT [CR_Signatories_EMailRfc5321]			CHECK([EMailRfc5321] LIKE '%@%.%'),

	[PhoneCountry]						VARCHAR(3)				NULL	CONSTRAINT [CK_Signatories_PhoneCountry]			CHECK([PhoneCountry] <> ''),
	[PhoneCity]							VARCHAR(4)				NULL	CONSTRAINT [CK_Signatories_PhoneCity]				CHECK([PhoneCity] <> ''),
	[PhoneLine]							VARCHAR(10)			NOT	NULL	CONSTRAINT [CK_Signatories_PhoneLine]				CHECK([PhoneLine] <> ''),
	[PhoneExtension]					VARCHAR(10)				NULL	CONSTRAINT [CK_Signatories_PhoneExtension]			CHECK([PhoneExtension] <> ''),

	[txInserted]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_Signatories_txInserted]				DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_Signatories_txInsertedSID]			DEFAULT(SUSER_SID()),
	[txInsertedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_Signatories_txInsertedUser]			DEFAULT(SUSER_SNAME()),
	[txInsertedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_Signatories_txInsertedHost]			DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_Signatories_txInsertedHost]			CHECK([txInsertedHost] <> ''),
	[txInsertedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_Signatories_txInsertedApp]			DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_Signatories_txInsertedApp]			CHECK([txInsertedApp] <> ''),

	[txModified]						DATETIMEOFFSET(7)	NOT	NULL	CONSTRAINT [DF_Signatories_txModified]				DEFAULT(SYSDATETIMEOFFSET()),
	[txModifiedSID]						VARBINARY(85)		NOT	NULL	CONSTRAINT [DF_Signatories_txModifiedSID]			DEFAULT(SUSER_SID()),
	[txModifiedUser]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_Signatories_txModifiedUser]			DEFAULT(SUSER_SNAME()),
	[txModifiedHost]					NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_Signatories_txModifiedHost]			DEFAULT(HOST_NAME()),
																		CONSTRAINT [CL_Signatories_txModifiedHost]			CHECK([txModifiedHost] <> ''),
	[txModifiedApp]						NVARCHAR(128)		NOT	NULL	CONSTRAINT [DF_Signatories_txModifiedApp]			DEFAULT(APP_NAME()),
																		CONSTRAINT [CL_Signatories_txModifiedApp]			CHECK([txModifiedApp] <> ''),

	[txRowVersion]						ROWVERSION			NOT	NULL	CONSTRAINT [UX_Signatories_txRowVersion]			UNIQUE([txRowVersion]),
	[txRowReplication]					UNIQUEIDENTIFIER	NOT	NULL	CONSTRAINT [DF_Signatories_txRowReplication]		DEFAULT(NEWSEQUENTIALID()) ROWGUIDCOL,
																		CONSTRAINT [UX_Signatories_txRowReplication]		UNIQUE([txRowReplication]),

	CONSTRAINT [PK_Signatories]	PRIMARY KEY NONCLUSTERED([SignatoryId] ASC),
	CONSTRAINT [UK_Signatories]	UNIQUE CLUSTERED([SignatoryNameFull] ASC)
);
GO

CREATE TRIGGER [dbo].[Signatories_Trigger_AfterUpdate]
ON [dbo].[Signatories]
AFTER UPDATE
AS
BEGIN

	SET NOCOUNT ON;

	UPDATE [dbo].[Signatories]
	SET
		[txModified]		= SYSDATETIMEOFFSET(),
		[txModifiedSID]		= SUSER_SID(),
		[txModifiedUser]	= SUSER_SNAME(),
		[txModifiedHost]	= HOST_NAME(),
		[txModifiedApp]		= APP_NAME()
	WHERE
		([dbo].[Signatories].[SignatoryId] IN (SELECT [i].[SignatoryId] FROM inserted [i]));

END;