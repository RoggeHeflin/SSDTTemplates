﻿CREATE PROCEDURE [dbo].[LeaseOffersDeque_Insert]
(
	@LeaseOfferId		INT
)
AS
BEGIN

	SET NOCOUNT ON;

	INSERT INTO [dbo].[LeaseOffersDeque]
	(
		[LeaseOfferId]
	)
	SELECT
		[t].[LeaseOfferId]
	FROM (VALUES
		(@LeaseOfferId)
		) [t]([LeaseOfferId])
	LEFT OUTER JOIN
		[dbo].[LeaseOffersDeque]		[d]
			ON	([d].[LeaseOfferId]		= [t].[LeaseOfferId])
	WHERE
		([d].[LeaseOfferId]	IS NULL);

END;