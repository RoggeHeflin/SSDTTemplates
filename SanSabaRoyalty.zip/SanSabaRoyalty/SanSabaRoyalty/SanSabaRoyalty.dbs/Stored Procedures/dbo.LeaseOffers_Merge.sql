﻿CREATE PROCEDURE [dbo].[LeaseOffers_Merge]
(
	@LeaseAnalysisId					INT,
	@RowNumber							INT,

	@WellName							NVARCHAR(256),
	@WellCounty							NVARCHAR(256),
	@WellState							NVARCHAR(256),
	@WellAcres							DECIMAL(10, 2),
	@WellSurvey							NVARCHAR(256),
	@WellAbstract						NVARCHAR(256),
	@WellOperator						NVARCHAR(256),

	@OwnerInterestType					NCHAR(2),
	@OwnerInterestPcnt					DECIMAL(11, 10),
	@OwnerValue							MONEY,
	@OwnerName							NVARCHAR(256),
	@OwnerAddress1						NVARCHAR(256),
	@OwnerAddress2						NVARCHAR(256),
	@OwnerCity							NVARCHAR(256),
	@OwnerState							NVARCHAR(2),
	@OwnerPostalCode					NVARCHAR(256),

	@OfferAmount						MONEY,
	@OfferDate							DATE,
	@OfferEffectiveDate					DATE,
	@OfferLetter						NVARCHAR(256),
	@OfferAmountLetter					MONEY,

	@WellRevenueMonthly					MONEY
)
AS
BEGIN

	SET NOCOUNT ON;

	MERGE [dbo].[LeaseOffers] [t]
	USING
	(
		SELECT
			[p].[LeaseAnalysisId],
			[p].[RowNumber],

			[p].[WellName],
			[p].[WellCounty],
			[p].[WellState],
			[p].[WellAcres],
			[p].[WellSurvey],
			[p].[WellAbstract],
			[p].[WellOperator],

			[p].[OwnerInterestType],
			[p].[OwnerInterestPcnt],
			[p].[OwnerValue],
			[p].[OwnerName],
			[p].[OwnerAddress1],
			[p].[OwnerAddress2],
			[p].[OwnerCity],
			[p].[OwnerState],
			[p].[OwnerPostalCode],

			[p].[OfferAmount],
			[p].[OfferDate],
			[p].[OfferEffectiveDate],
			[p].[OfferLetter],
			[p].[OfferAmountLetter],

			[p].[WellRevenueMonthly]
		FROM( VALUES(
			@LeaseAnalysisId,
			@RowNumber,

			@WellName,
			@WellCounty,
			@WellState,
			@WellAcres,
			@WellSurvey,
			@WellAbstract,
			@WellOperator,

			@OwnerInterestType,
			@OwnerInterestPcnt,
			@OwnerValue,
			@OwnerName,
			@OwnerAddress1,
			@OwnerAddress2,
			@OwnerCity,
			@OwnerState,
			@OwnerPostalCode,

			@OfferAmount,
			@OfferDate,
			@OfferEffectiveDate,
			@OfferLetter,
			@OfferAmountLetter,

			@WellRevenueMonthly
		)
		) [p] (
			[LeaseAnalysisId],
			[RowNumber],

			[WellName],
			[WellCounty],
			[WellState],
			[WellAcres],
			[WellSurvey],
			[WellAbstract],
			[WellOperator],

			[OwnerInterestType],
			[OwnerInterestPcnt],
			[OwnerValue],
			[OwnerName],
			[OwnerAddress1],
			[OwnerAddress2],
			[OwnerCity],
			[OwnerState],
			[OwnerPostalCode],

			[OfferAmount],
			[OfferDate],
			[OfferEffectiveDate],
			[OfferLetter],
			[OfferAmountLetter],

			[WellRevenueMonthly]
		)
	) [s]
		ON	([s].[LeaseAnalysisId]		=	[t].[LeaseAnalysisId])
		AND	([s].[WellName]				=	[t].[WellName])
		AND	([s].[OwnerName]			=	[t].[OwnerName])
		AND	([s].[OwnerInterestType]	=	[t].[OwnerInterestType])

	WHEN NOT MATCHED BY TARGET THEN
		INSERT(
			[LeaseAnalysisId],
			[RowNumber],

			[WellName],
			[WellCounty],
			[WellState],
			[WellAcres],
			[WellSurvey],
			[WellAbstract],
			[WellOperator],

			[OwnerInterestType],
			[OwnerInterestPcnt],
			[OwnerValue],
			[OwnerName],
			[OwnerAddress1],
			[OwnerAddress2],
			[OwnerCity],
			[OwnerState],
			[OwnerPostalCode],

			[OfferAmount],
			[OfferDate],
			[OfferEffectiveDate],
			[OfferLetter],
			[OfferAmountLetter],

			[WellRevenueMonthly]
			)
		VALUES(
			[s].[LeaseAnalysisId],
			[s].[RowNumber],

			[s].[WellName],
			[s].[WellCounty],
			[s].[WellState],
			[s].[WellAcres],
			[s].[WellSurvey],
			[s].[WellAbstract],
			[s].[WellOperator],

			[s].[OwnerInterestType],
			[s].[OwnerInterestPcnt],
			[s].[OwnerValue],
			[s].[OwnerName],
			[s].[OwnerAddress1],
			[s].[OwnerAddress2],
			[s].[OwnerCity],
			[s].[OwnerState],
			[s].[OwnerPostalCode],

			[s].[OfferAmount],
			[s].[OfferDate],
			[s].[OfferEffectiveDate],
			[s].[OfferLetter],
			[s].[OfferAmountLetter],

			[s].[WellRevenueMonthly]
		);

END;