﻿CREATE PROCEDURE [dbo].[LeaseOffersEnque_BulkInsert]
AS
BEGIN

	SET NOCOUNT ON;

	INSERT INTO [dbo].[LeaseOffersEnque]
	(
		[LeaseOfferId]
	)
	SELECT DISTINCT
		[o].[LeaseOfferId]
	FROM
		[dbo].[LeaseOffers]				[o]
	LEFT OUTER JOIN
		[dbo].[LeaseOffersEnque]		[e]
			ON	([e].[LeaseOfferId]		= [o].[LeaseOfferId])
	LEFT OUTER JOIN
		[dbo].[LeaseOffersDeque]		[d]
			ON	([d].[LeaseOfferId]		= [o].[LeaseOfferId])
	WHERE
			([e].[LeaseOffersEnqueId]	IS NULL)
		AND	([d].[LeaseOffersDequeId]	IS NULL);

END;