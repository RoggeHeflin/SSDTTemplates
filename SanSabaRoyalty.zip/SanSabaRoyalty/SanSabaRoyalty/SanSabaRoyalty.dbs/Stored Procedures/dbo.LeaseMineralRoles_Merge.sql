﻿CREATE PROCEDURE [dbo].[LeaseMineralRoles_Merge]
(
	@LeaseAnalysisId					INT,
	@RowNumber							INT,

	@WellName							NVARCHAR(256),
	@WellSurvey							NVARCHAR(256),
	@WellAbstract						NVARCHAR(256),
	@WellOperator						NVARCHAR(256),

	@OwnerName							NVARCHAR(256),
	@OwnerAddress1						NVARCHAR(256),
	@OwnerAddress2						NVARCHAR(256),
	@OwnerCounty						NVARCHAR(256),
	@OwnerCity							NVARCHAR(256),
	@OwnerState							NVARCHAR(2),
	@OwnerPostalCode					NVARCHAR(12),
	@OwnerPostalCodeExt					NVARCHAR(12),

	@OwnerInterestType					NCHAR(2),
	@OwnerInterestPcnt					DECIMAL(11, 10),

	@WellField							VARCHAR(256),
	@OwnerValue							MONEY,
	@LeaseAcres							DECIMAL(8, 2),
	@LeaseDate							DATE
)
AS
BEGIN

	SET NOCOUNT ON;

	MERGE INTO [dbo].[LeaseMineralRoles] [t]
	USING
	(
		SELECT
			[p].[LeaseAnalysisId],
			[p].[RowNumber],

			[p].[WellName],
			[p].[WellSurvey],
			[p].[WellAbstract],
			[p].[WellOperator],

			[p].[OwnerName],
			[p].[OwnerAddress1],
			[p].[OwnerAddress2],
			[p].[OwnerCounty],
			[p].[OwnerCity],
			[p].[OwnerState],
			[p].[OwnerPostalCode],
			[p].[OwnerPostalCodeExt],

			[p].[OwnerInterestType],
			[p].[OwnerInterestPcnt],

			[p].[WellField],
			[p].[OwnerValue],
			[p].[LeaseAcres],
			[p].[LeaseDate]
		FROM(VALUES
		(
			@LeaseAnalysisId,
			@RowNumber,

			@WellName,
			@WellSurvey,
			@WellAbstract,
			@WellOperator,

			@OwnerName,
			@OwnerAddress1,
			@OwnerAddress2,
			@OwnerCounty,
			@OwnerCity,
			@OwnerState,
			@OwnerPostalCode,
			@OwnerPostalCodeExt,

			@OwnerInterestType,
			@OwnerInterestPcnt,

			@WellField,
			@OwnerValue,
			@LeaseAcres,
			@LeaseDate
		)
		) [p] (
			[LeaseAnalysisId],
			[RowNumber],

			[WellName],
			[WellSurvey],
			[WellAbstract],
			[WellOperator],

			[OwnerName],
			[OwnerAddress1],
			[OwnerAddress2],
			[OwnerCounty],
			[OwnerCity],
			[OwnerState],
			[OwnerPostalCode],
			[OwnerPostalCodeExt],

			[OwnerInterestType],
			[OwnerInterestPcnt],

			[WellField],
			[OwnerValue],
			[LeaseAcres],
			[LeaseDate]
		)
	) [s]
		ON	([s].[LeaseAnalysisId]		= [t].[LeaseAnalysisId])
		AND	([s].[OwnerName]			= [t].[OwnerName])
		AND	([s].[OwnerInterestType]	= [t].[OwnerInterestType])

	WHEN NOT MATCHED BY TARGET THEN
	INSERT (
		[LeaseAnalysisId],
		[RowNumber],

		[WellName],
		[WellSurvey],
		[WellAbstract],
		[WellOperator],

		[OwnerName],
		[OwnerAddress1],
		[OwnerAddress2],
		[OwnerCounty],
		[OwnerCity],
		[OwnerState],
		[OwnerPostalCode],
		[OwnerPostalCodeExt],

		[OwnerInterestType],
		[OwnerInterestPcnt],

		[WellField],
		[OwnerValue],
		[LeaseAcres],
		[LeaseDate]
	)
	VALUES (
		[s].[LeaseAnalysisId],
		[s].[RowNumber],

		[s].[WellName],
		[s].[WellSurvey],
		[s].[WellAbstract],
		[s].[WellOperator],

		[s].[OwnerName],
		[s].[OwnerAddress1],
		[s].[OwnerAddress2],
		[s].[OwnerCounty],
		[s].[OwnerCity],
		[s].[OwnerState],
		[s].[OwnerPostalCode],
		[s].[OwnerPostalCodeExt],

		[s].[OwnerInterestType],
		[s].[OwnerInterestPcnt],

		[s].[WellField],
		[s].[OwnerValue],
		[s].[LeaseAcres],
		[s].[LeaseDate]
	);

END;