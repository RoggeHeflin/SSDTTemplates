﻿CREATE PROCEDURE [dbo].[LeaseProductionPermits_Merge]
(
	@LeaseAnalysisId					INT,
	@RowNumber							INT,

	@API_Number							NVARCHAR(12),
	@OperatorName						NVARCHAR(256),

	@WellName							NVARCHAR(256),
	@WellCounty							NVARCHAR(256),
	@WellNumber							NVARCHAR(256),

	@Issue_Date							DATE,
	@Depth_Permit						DECIMAL(10, 2),
	@HasImages							NVARCHAR(3),
	@HasDoc								NVARCHAR(256),
	@Depth_Total						DECIMAL(10, 2),
	@WellType							NVARCHAR(256),
	@WellStatus							NVARCHAR(256),

	@Letter								NVARCHAR(256),
	@FieldName							NVARCHAR(256),
	@PracIP_BOD							DECIMAL(10, 4),
	@PracIP_MCFD						DECIMAL(10, 4),
	@ProductionFirst_Date				DATE,
	@ProductionLast_Date				DATE,
	@ProdAvg_BOD						DECIMAL(8, 4),
	@ProdAvg_MCFD						DECIMAL(8, 4),
	@Cumulative_Oil						DECIMAL(10, 2),
	@Cumulative_Gas						DECIMAL(10, 2)
)
AS
BEGIN

	SET NOCOUNT ON;

	MERGE INTO [dbo].[LeaseProductionPermits] [t]
	USING
	(
		SELECT
			[p].[LeaseAnalysisId],
			[p].[RowNumber],

			[p].[API_Number],
			[p].[OperatorName],
			[p].[WellName],
			[p].[WellNumber],
			[p].[WellCounty],

			[p].[Issue_Date],
			[p].[Depth_Permit],
			[p].[HasImages],
			[p].[HasDoc],
			[p].[Depth_Total],
			[p].[WellType],
			[p].[WellStatus],

			[p].[Letter],
			[p].[FieldName],
			[p].[PracIP_BOD],
			[p].[PracIP_MCFD],
			[p].[ProductionFirst_Date],
			[p].[ProductionLast_Date],
			[p].[ProdAvg_BOD],
			[p].[ProdAvg_MCFD],
			[p].[Cumulative_Oil],
			[p].[Cumulative_Gas]
		FROM(VALUES
		(
			@LeaseAnalysisId,
			@RowNumber,

			@API_Number,
			@OperatorName,
			@WellName,
			@WellNumber,
			@WellCounty,

			@Issue_Date,
			@Depth_Permit,
			@HasImages,
			@HasDoc,
			@Depth_Total,
			@WellType,
			@WellStatus,

			@Letter,
			@FieldName,
			@PracIP_BOD,
			@PracIP_MCFD,
			@ProductionFirst_Date,
			@ProductionLast_Date,
			@ProdAvg_BOD,
			@ProdAvg_MCFD,
			@Cumulative_Oil,
			@Cumulative_Gas
		)
		) [p] (
			[LeaseAnalysisId],
			[RowNumber],

			[API_Number],
			[OperatorName],
			[WellName],
			[WellNumber],
			[WellCounty],

			[Issue_Date],
			[Depth_Permit],
			[HasImages],
			[HasDoc],
			[Depth_Total],
			[WellType],
			[WellStatus],

			[Letter],
			[FieldName],
			[PracIP_BOD],
			[PracIP_MCFD],
			[ProductionFirst_Date],
			[ProductionLast_Date],
			[ProdAvg_BOD],
			[ProdAvg_MCFD],
			[Cumulative_Oil],
			[Cumulative_Gas]
		)
	) [s]
		ON	([s].[LeaseAnalysisId]		= [t].[LeaseAnalysisId])
		AND	([s].[API_Number]			= [t].[API_Number])

	WHEN NOT MATCHED BY TARGET THEN
	INSERT (
		[LeaseAnalysisId],
		[RowNumber],

		[API_Number],
		[OperatorName],
		[WellName],
		[WellNumber],
		[WellCounty],

		[Issue_Date],
		[Depth_Permit],
		[HasImages],
		[HasDoc],
		[Depth_Total],
		[WellType],
		[WellStatus],

		[Letter],
		[FieldName],
		[PracIP_BOD],
		[PracIP_MCFD],
		[ProductionFirst_Date],
		[ProductionLast_Date],
		[ProdAvg_BOD],
		[ProdAvg_MCFD],
		[Cumulative_Oil],
		[Cumulative_Gas]
	)
	VALUES (
			[s].[LeaseAnalysisId],
			[s].[RowNumber],

			[s].[API_Number],
			[s].[OperatorName],
			[s].[WellName],
			[s].[WellNumber],
			[s].[WellCounty],

			[s].[Issue_Date],
			[s].[Depth_Permit],
			[s].[HasImages],
			[s].[HasDoc],
			[s].[Depth_Total],
			[s].[WellType],
			[s].[WellStatus],
	
			[s].[Letter],
			[s].[FieldName],
			[s].[PracIP_BOD],
			[s].[PracIP_MCFD],
			[s].[ProductionFirst_Date],
			[s].[ProductionLast_Date],
			[s].[ProdAvg_BOD],
			[s].[ProdAvg_MCFD],
			[s].[Cumulative_Oil],
			[s].[Cumulative_Gas]
	);

END;