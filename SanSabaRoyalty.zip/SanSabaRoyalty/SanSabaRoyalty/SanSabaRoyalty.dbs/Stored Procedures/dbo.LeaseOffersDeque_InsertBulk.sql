﻿CREATE PROCEDURE [dbo].[LeaseOffersDeque_InsertBulk]
AS
BEGIN

	SET NOCOUNT ON;

	INSERT INTO [dbo].[LeaseOffersDeque]
	(
		[LeaseOfferId]
	)
	SELECT DISTINCT
		[e].[LeaseOfferId]
	FROM
		[dbo].[LeaseOffersEnque]		[e]
	LEFT OUTER JOIN
		[dbo].[LeaseOffersDeque]		[d]
			ON	([d].[LeaseOfferId]		= [e].[LeaseOfferId])
	WHERE
		([d].[LeaseOffersDequeId]	IS NULL);

END;