﻿CREATE PROCEDURE [dbo].[LeaseAnalyses_Merge]
(
	@OfferDate							DATE,
	@EffectiveDate						DATE,
	@SignatoryNameFull					NVARCHAR(48),

	@WellName							NVARCHAR(256),
	@WellCounty							NVARCHAR(256),
	@WellState							NVARCHAR(2),
	@WellAcres							DECIMAL(10, 2),

	@WellOperator						NVARCHAR(256),

	@NetRevenue_Pcnt					DECIMAL(11, 10),
	@NetRevenue_Interest_Pcnt			DECIMAL(11, 10),
	@NetRevenue_Month_Gas				MONEY,
	@NetRevenue_Month_Oil				MONEY,
	@NetRevenue_Month					MONEY,

	@InitialProduction_MCFD				DECIMAL(10, 4),
	@InitialProduction_BOPD				DECIMAL(10, 4),
	@GrossProduction_MCFD				DECIMAL(12, 6),
	@GrossProduction_BOPD				DECIMAL(12, 6),

	@Payout_MCF							MONEY,
	@Payout_BBL							MONEY,

	@SeveranceTax_Oil_Pcnt				DECIMAL(7, 6),
	@SeveranceTax_Gas_Pcnt				DECIMAL(7, 6),

	@Price_Gas_MFC						DECIMAL(8, 4),
	@Price_Oil_BBL						DECIMAL(8, 4),

	@PDP_WellCount						INT,
	@PDP_Value							MONEY,
	@PDP_RiskFactor						DECIMAL(8, 4),
	@PDP_NRI_OnePcnt					MONEY,

	@PDP_A_Value						MONEY,
	@PDP_B_Value						MONEY,
	@PDP_PresentWorth_A_Pcnt			DECIMAL(8, 4),
	@PDP_PresentWorth_B_Pcnt			DECIMAL(8, 4),

	@PDP_NoProd_WellCount				INT,
	@PDP_NoProd_Value					MONEY,
	@PDP_NoProd_RiskFactor				DECIMAL(8, 4),
	@PDP_NoProd_NRI_OnePcnt				MONEY,

	@PDP_NoProd_A_Value					MONEY,
	@PDP_NoProd_B_Value					MONEY,
	@PDP_NoProd_PresentWorth_A_Pcnt		DECIMAL(8, 4),
	@PDP_NoProd_PresentWorth_B_Pcnt		DECIMAL(8, 4),

	@PUD1_WellCount						INT,
	@PUD1_Value							MONEY,
	@PUD1_RiskFactor					DECIMAL(8, 4),
	@PUD1_NRI_OnePcnt					MONEY,

	@PUD2_WellCount						INT,
	@PUD2_Value							MONEY,
	@PUD2_RiskFactor					DECIMAL(8, 4),
	@PUD2_NRI_OnePcnt					MONEY,

	@PotentialWells_Count				INT,
	@Permit_Count						INT,
	@Value_Possible						MONEY,
	@Value_PerRoyAcre					MONEY,
	@Value_AddOnMult					DECIMAL(8, 4),
	@Value_AddOnAcreage					DECIMAL(8, 4),

	@ProducingFormations				NVARCHAR(256),

	@Offer_OnePcnt						MONEY,

	@PDP_Pcnt							DECIMAL(8, 4),
	@PUD_Pcnt							DECIMAL(8, 4)
)
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @Id				INT;

	DECLARE @SignatoryId	INT = [dbo].[GetSignatory](@SignatoryNameFull);

	DECLARE @Matched	TABLE
	(
		[MergeAction]	NVARCHAR(10)	NOT	NULL,
		[Id]			INT					NULL
	);

	MERGE INTO [dbo].[LeaseAnalyses] [t]
	USING
	(
		SELECT
			[p].[OfferDate],
			[p].[EffectiveDate],
			[p].[SignatoryId],

			[p].[WellName],
			[p].[WellCounty],
			[p].[WellState],
			[p].[WellAcres],

			[p].[WellOperator],

			[p].[NetRevenue_Pcnt],
			[p].[NetRevenue_Interest_Pcnt],
			[p].[NetRevenue_Month_Gas],
			[p].[NetRevenue_Month_Oil],
			[p].[NetRevenue_Month],

			[p].[InitialProduction_MCFD],
			[p].[InitialProduction_BOPD],
			[p].[GrossProduction_MCFD],
			[p].[GrossProduction_BOPD],

			[p].[Payout_MCF],
			[p].[Payout_BBL],

			[p].[SeveranceTax_Oil_Pcnt],
			[p].[SeveranceTax_Gas_Pcnt],

			[p].[Price_Gas_MFC],
			[p].[Price_Oil_BBL],

			[p].[PDP_WellCount],
			[p].[PDP_Value],
			[p].[PDP_RiskFactor],
			[p].[PDP_NRI_OnePcnt],

			[p].[PDP_A_Value],
			[p].[PDP_B_Value],
			[p].[PDP_PresentWorth_A_Pcnt],
			[p].[PDP_PresentWorth_B_Pcnt],

			[p].[PDP_NoProd_WellCount],
			[p].[PDP_NoProd_Value],
			[p].[PDP_NoProd_RiskFactor],
			[p].[PDP_NoProd_NRI_OnePcnt],

			[p].[PDP_NoProd_A_Value],
			[p].[PDP_NoProd_B_Value],
			[p].[PDP_NoProd_PresentWorth_A_Pcnt],
			[p].[PDP_NoProd_PresentWorth_B_Pcnt],

			[p].[PUD1_WellCount],
			[p].[PUD1_Value],
			[p].[PUD1_RiskFactor],
			[p].[PUD1_NRI_OnePcnt],

			[p].[PUD2_WellCount],
			[p].[PUD2_Value],
			[p].[PUD2_RiskFactor],
			[p].[PUD2_NRI_OnePcnt],

			[p].[PotentialWells_Count],
			[p].[Permit_Count],
			[p].[Value_Possible],
			[p].[Value_PerRoyAcre],
			[p].[Value_AddOnMult],
			[p].[Value_AddOnAcreage],

			[p].[ProducingFormations],

			[p].[Offer_OnePcnt],

			[p].[PDP_Pcnt],
			[p].[PUD_Pcnt]
		FROM(VALUES
		(
			@OfferDate,
			@EffectiveDate,
			@SignatoryId,

			@WellName,
			@WellCounty,
			@WellState,
			@WellAcres,

			@WellOperator,

			@NetRevenue_Pcnt,
			@NetRevenue_Interest_Pcnt,
			@NetRevenue_Month_Gas,
			@NetRevenue_Month_Oil,
			@NetRevenue_Month,

			@InitialProduction_MCFD,
			@InitialProduction_BOPD,
			@GrossProduction_MCFD,
			@GrossProduction_BOPD,

			@Payout_MCF,
			@Payout_BBL,

			@SeveranceTax_Oil_Pcnt,
			@SeveranceTax_Gas_Pcnt,

			@Price_Gas_MFC,
			@Price_Oil_BBL,

			@PDP_WellCount,
			@PDP_Value,
			@PDP_RiskFactor,
			@PDP_NRI_OnePcnt,

			@PDP_A_Value,
			@PDP_B_Value,
			@PDP_PresentWorth_A_Pcnt,
			@PDP_PresentWorth_B_Pcnt,

			@PDP_NoProd_WellCount,
			@PDP_NoProd_Value,
			@PDP_NoProd_RiskFactor,
			@PDP_NoProd_NRI_OnePcnt,

			@PDP_NoProd_A_Value,
			@PDP_NoProd_B_Value,
			@PDP_NoProd_PresentWorth_A_Pcnt,
			@PDP_NoProd_PresentWorth_B_Pcnt,

			@PUD1_WellCount,
			@PUD1_Value,
			@PUD1_RiskFactor,
			@PUD1_NRI_OnePcnt,

			@PUD2_WellCount,
			@PUD2_Value,
			@PUD2_RiskFactor,
			@PUD2_NRI_OnePcnt,

			@PotentialWells_Count,
			@Permit_Count,
			@Value_Possible,
			@Value_PerRoyAcre,
			@Value_AddOnMult,
			@Value_AddOnAcreage,

			@ProducingFormations,

			@Offer_OnePcnt,

			@PDP_Pcnt,
			@PUD_Pcnt
		)
		) [p] (
			[OfferDate],
			[EffectiveDate],
			[SignatoryId],

			[WellName],
			[WellCounty],
			[WellState],
			[WellAcres],

			[WellOperator],

			[NetRevenue_Pcnt],
			[NetRevenue_Interest_Pcnt],
			[NetRevenue_Month_Gas],
			[NetRevenue_Month_Oil],
			[NetRevenue_Month],

			[InitialProduction_MCFD],
			[InitialProduction_BOPD],
			[GrossProduction_MCFD],
			[GrossProduction_BOPD],

			[Payout_MCF],
			[Payout_BBL],

			[SeveranceTax_Oil_Pcnt],
			[SeveranceTax_Gas_Pcnt],

			[Price_Gas_MFC],
			[Price_Oil_BBL],

			[PDP_WellCount],
			[PDP_Value],
			[PDP_RiskFactor],
			[PDP_NRI_OnePcnt],

			[PDP_A_Value],
			[PDP_B_Value],
			[PDP_PresentWorth_A_Pcnt],
			[PDP_PresentWorth_B_Pcnt],

			[PDP_NoProd_WellCount],
			[PDP_NoProd_Value],
			[PDP_NoProd_RiskFactor],
			[PDP_NoProd_NRI_OnePcnt],

			[PDP_NoProd_A_Value],
			[PDP_NoProd_B_Value],
			[PDP_NoProd_PresentWorth_A_Pcnt],
			[PDP_NoProd_PresentWorth_B_Pcnt],

			[PUD1_WellCount],
			[PUD1_Value],
			[PUD1_RiskFactor],
			[PUD1_NRI_OnePcnt],

			[PUD2_WellCount],
			[PUD2_Value],
			[PUD2_RiskFactor],
			[PUD2_NRI_OnePcnt],

			[PotentialWells_Count],
			[Permit_Count],
			[Value_Possible],
			[Value_PerRoyAcre],
			[Value_AddOnMult],
			[Value_AddOnAcreage],

			[ProducingFormations],

			[Offer_OnePcnt],

			[PDP_Pcnt],
			[PUD_Pcnt]
		)
	) [s]
		ON	([s].[WellName]			= [t].[WellName])
		AND	([s].[WellCounty]		= [t].[WellCounty])
		AND	([s].[WellState]		= [t].[WellState])
		AND	([s].[OfferDate]		= [t].[OfferDate])
		AND	([s].[EffectiveDate]	= [t].[EffectiveDate])

	WHEN MATCHED THEN UPDATE
	SET  @Id = [t].[LeaseAnalysisId]

	WHEN NOT MATCHED BY TARGET THEN
	INSERT (
		[OfferDate],
		[EffectiveDate],
		[SignatoryId],

		[WellName],
		[WellCounty],
		[WellState],
		[WellAcres],

		[WellOperator],

		[NetRevenue_Pcnt],
		[NetRevenue_Interest_Pcnt],
		[NetRevenue_Month_Gas],
		[NetRevenue_Month_Oil],
		[NetRevenue_Month],

		[InitialProduction_MCFD],
		[InitialProduction_BOPD],
		[GrossProduction_MCFD],
		[GrossProduction_BOPD],

		[Payout_MCF],
		[Payout_BBL],

		[SeveranceTax_Oil_Pcnt],
		[SeveranceTax_Gas_Pcnt],

		[Price_Gas_MFC],
		[Price_Oil_BBL],

		[PDP_WellCount],
		[PDP_Value],
		[PDP_RiskFactor],
		[PDP_NRI_OnePcnt],

		[PDP_A_Value],
		[PDP_B_Value],
		[PDP_PresentWorth_A_Pcnt],
		[PDP_PresentWorth_B_Pcnt],

		[PDP_NoProd_WellCount],
		[PDP_NoProd_Value],
		[PDP_NoProd_RiskFactor],
		[PDP_NoProd_NRI_OnePcnt],

		[PDP_NoProd_A_Value],
		[PDP_NoProd_B_Value],
		[PDP_NoProd_PresentWorth_A_Pcnt],
		[PDP_NoProd_PresentWorth_B_Pcnt],

		[PUD1_WellCount],
		[PUD1_Value],
		[PUD1_RiskFactor],
		[PUD1_NRI_OnePcnt],

		[PUD2_WellCount],
		[PUD2_Value],
		[PUD2_RiskFactor],
		[PUD2_NRI_OnePcnt],

		[PotentialWells_Count],
		[Permit_Count],
		[Value_Possible],
		[Value_PerRoyAcre],
		[Value_AddOnMult],
		[Value_AddOnAcreage],

		[ProducingFormations],

		[Offer_OnePcnt],

		[PDP_Pcnt],
		[PUD_Pcnt]
		)
	VALUES (
		[s].[OfferDate],
		[s].[EffectiveDate],
		[s].[SignatoryId],

		[s].[WellName],
		[s].[WellCounty],
		[s].[WellState],
		[s].[WellAcres],

		[s].[WellOperator],

		[s].[NetRevenue_Pcnt],
		[s].[NetRevenue_Interest_Pcnt],
		[s].[NetRevenue_Month_Gas],
		[s].[NetRevenue_Month_Oil],
		[s].[NetRevenue_Month],

		[s].[InitialProduction_MCFD],
		[s].[InitialProduction_BOPD],
		[s].[GrossProduction_MCFD],
		[s].[GrossProduction_BOPD],

		[s].[Payout_MCF],
		[s].[Payout_BBL],

		[s].[SeveranceTax_Oil_Pcnt],
		[s].[SeveranceTax_Gas_Pcnt],

		[s].[Price_Gas_MFC],
		[s].[Price_Oil_BBL],

		[s].[PDP_WellCount],
		[s].[PDP_Value],
		[s].[PDP_RiskFactor],
		[s].[PDP_NRI_OnePcnt],

		[s].[PDP_A_Value],
		[s].[PDP_B_Value],
		[s].[PDP_PresentWorth_A_Pcnt],
		[s].[PDP_PresentWorth_B_Pcnt],

		[s].[PDP_NoProd_WellCount],
		[s].[PDP_NoProd_Value],
		[s].[PDP_NoProd_RiskFactor],
		[s].[PDP_NoProd_NRI_OnePcnt],

		[s].[PDP_NoProd_A_Value],
		[s].[PDP_NoProd_B_Value],
		[s].[PDP_NoProd_PresentWorth_A_Pcnt],
		[s].[PDP_NoProd_PresentWorth_B_Pcnt],

		[s].[PUD1_WellCount],
		[s].[PUD1_Value],
		[s].[PUD1_RiskFactor],
		[s].[PUD1_NRI_OnePcnt],

		[s].[PUD2_WellCount],
		[s].[PUD2_Value],
		[s].[PUD2_RiskFactor],
		[s].[PUD2_NRI_OnePcnt],

		[s].[PotentialWells_Count],
		[s].[Permit_Count],
		[s].[Value_Possible],
		[s].[Value_PerRoyAcre],
		[s].[Value_AddOnMult],
		[s].[Value_AddOnAcreage],

		[s].[ProducingFormations],

		[s].[Offer_OnePcnt],

		[s].[PDP_Pcnt],
		[s].[PUD_Pcnt]
	)
	OUTPUT
		$action,
		inserted.[LeaseAnalysisId]
	INTO
		@Matched;

	SELECT
		@Id	= COALESCE([m].[Id], @Id)
	FROM
		@Matched	[m];

	RETURN @Id;

END;