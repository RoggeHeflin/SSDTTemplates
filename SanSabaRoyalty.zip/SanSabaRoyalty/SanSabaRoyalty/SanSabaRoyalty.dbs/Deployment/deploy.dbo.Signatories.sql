﻿CREATE TABLE #Signatories
(
	[SignatoryId]						INT					NOT	NULL	IDENTITY(1, 1)	NOT FOR REPLICATION,

	[SignatoryNameFull]					VARCHAR(48)			NOT	NULL	CONSTRAINT [D_CK_Signatories_SignatoryNameFull]		CHECK([SignatoryNameFull] <> ''),

	[EMailRfc5321]						VARCHAR(254)		NOT	NULL	CONSTRAINT [D_CK_Signatories_EMailRfc5321]			CHECK([EMailRfc5321] <> ''),
																		CONSTRAINT [D_CR_Signatories_EMailRfc5321]			CHECK([EMailRfc5321] LIKE '%@%.%'),

	[PhoneCountry]						VARCHAR(3)				NULL	CONSTRAINT [D_CK_Signatories_PhoneCountry]			CHECK([PhoneCountry] <> ''),
	[PhoneCity]							VARCHAR(4)				NULL	CONSTRAINT [D_CK_Signatories_PhoneCity]				CHECK([PhoneCity] <> ''),
	[PhoneLine]							VARCHAR(10)			NOT	NULL	CONSTRAINT [D_CK_Signatories_PhoneLine]				CHECK([PhoneLine] <> ''),
	[PhoneExtension]					VARCHAR(10)				NULL	CONSTRAINT [D_CK_Signatories_PhoneExtension]			CHECK([PhoneExtension] <> ''),

	CONSTRAINT [D_PK_Signatories]	PRIMARY KEY NONCLUSTERED([SignatoryId] ASC),
	CONSTRAINT [D_UK_Signatories]	UNIQUE CLUSTERED([SignatoryNameFull] ASC)
);

INSERT INTO #Signatories
(
	[SignatoryNameFull],
	[EMailRfc5321],
	[PhoneLine]
)
SELECT
	[t].[SignatoryNameFull],
	[t].[EMailRfc5321],
	[t].[PhoneLine]
FROM (VALUES
	('Jake LaCaze',		'jlacaze@sansabaroyalty.com',	'2144666674'),
	('Spencer Sell',	'ssell@sansabaroyalty.com',		'9723887342')
	) [t] ([SignatoryNameFull], [EMailRfc5321], [PhoneLine]);

MERGE INTO [dbo].[Signatories] [t]
USING
(
	SELECT
		[t].[SignatoryNameFull],
		[t].[EMailRfc5321],
		[t].[PhoneCountry],
		[t].[PhoneCity],
		[t].[PhoneLine],
		[t].[PhoneExtension]
	FROM
		#Signatories	[t]
) [s]
	ON	([t].[SignatoryNameFull] = [s].[SignatoryNameFull])

WHEN NOT MATCHED BY TARGET THEN
	INSERT([SignatoryNameFull],[EMailRfc5321], [PhoneCountry], [PhoneCity], [PhoneLine], [PhoneExtension])
	VALUES([SignatoryNameFull],[EMailRfc5321], [PhoneCountry], [PhoneCity], [PhoneLine], [PhoneExtension])  

WHEN NOT MATCHED BY SOURCE THEN
	DELETE

WHEN MATCHED AND (
			([t].[EMailRfc5321]					<>	[s].[EMailRfc5321])
		AND	([t].[PhoneLine]					<>	[s].[PhoneLine])
		AND	(COALESCE([t].[PhoneCountry],	'')	<>	COALESCE([s].[PhoneCountry],	''))
		AND	(COALESCE([t].[PhoneCity],		'')	<>	COALESCE([s].[PhoneCity],		''))
		AND	(COALESCE([t].[PhoneExtension],	'')	<>	COALESCE([s].[PhoneExtension],	'')))THEN
	UPDATE SET
		[t].[EMailRfc5321]		=	[s].[EMailRfc5321],
		[t].[PhoneCountry]		=	[s].[PhoneCountry],
		[t].[PhoneCity]			=	[s].[PhoneCity],
		[t].[PhoneLine]			=	[s].[PhoneLine],
		[t].[PhoneExtension]	=	[s].[PhoneExtension];