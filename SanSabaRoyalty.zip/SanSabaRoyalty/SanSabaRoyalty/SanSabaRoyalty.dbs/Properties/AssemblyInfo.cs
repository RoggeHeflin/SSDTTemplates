﻿using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with the SQLCLR assembly.
[assembly: AssemblyTitle("SanSaba Title Mailings")]
[assembly: AssemblyDescription("SanSaba Title Mailings")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("RHI")]
[assembly: AssemblyProduct("SanSaba Title Mailings")]
[assembly: AssemblyCopyright("© 2018 Rogge Heflin")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1")]
[assembly: AssemblyFileVersion("1")]
