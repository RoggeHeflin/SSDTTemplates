﻿Client ID: 532-direct-access
Client Secret: a973bd7c-ec61-413a-bda9-887a85570522
API Key: 3c7466645939dba3b07d705ee9900dd9