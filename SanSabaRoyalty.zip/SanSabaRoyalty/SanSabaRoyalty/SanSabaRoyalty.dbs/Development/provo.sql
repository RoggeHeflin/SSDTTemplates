﻿SELECT * FROM [dbo].[LeaseAnalyses];
SELECT * FROM [dbo].[LeaseMineralRoles];
SELECT * FROM [dbo].[LeaseOffers];
SELECT * FROM [dbo].[LeaseProductionPermits];



	SELECT DISTINCT
		[o].[LeaseOfferId]
	FROM
		[dbo].[LeaseOffers]				[o]
	LEFT OUTER JOIN
		[dbo].[LeaseOffersEnque]		[e]
			ON	([e].[LeaseOfferId]		= [o].[LeaseOfferId])
	LEFT OUTER JOIN
		[dbo].[LeaseOffersDeque]		[d]
			ON	([d].[LeaseOfferId]		= [o].[LeaseOfferId])
	WHERE
			([e].[LeaseOffersEnqueId]	IS NULL)
		AND	([d].[LeaseOffersDequeId]	IS NULL);



EXECUTE [dbo].[LeaseOffersEnque_BulkInsert]


SELECT * FROM [dbo].[MailMerge];

SELECT * FROM [dbo].[LeaseOffersEnque];
SELECT * FROM [dbo].[LeaseOffersDeque] (NOLOCK);



TRUNCATE TABLE [dbo].[LeaseOffersEnque];
TRUNCATE TABLE [dbo].[LeaseOffersDeque];
