﻿CREATE VIEW [dbo].[MailMerge]
WITH SCHEMABINDING
AS
SELECT
	[LeaseOfferId]			= [o].[LeaseOfferId],

	[LEASE_NAME]			= [o].[WellName],
	[County]				= [o].[WellCounty],
	[Acres]					= [o].[WellAcres],
	[Survey]				= [o].[WellSurvey],
	[Abstract]				= [o].[WellAbstract],
	[OPERATOR]				= [o].[WellOperator],
	[Owner]					= [o].[OwnerName],
	[ADDRESS1]				= [o].[OwnerAddress1],
	[ADDRESS2]				= [o].[OwnerAddress2],
	[CITY]					= [o].[OwnerCity],
	[ST]					= [o].[OwnerState],
	[ZIP]					= [o].[OwnerPostalCode],
	[OFFER_DATE]			= [o].[OfferDate],
	[Effective_Date]		= [o].[OfferEffectiveDate],
	[Letter_Offer]			= [o].[OfferLetter],
	[Money Offer]			= [o].[OfferAmountLetter],

	[SignatoryName]			= [s].[SignatoryNameFull],
	[SignatoryEMail]		= [s].[EMailRfc5321],
	[SignatoryPhone]		= [s].[PhoneLine]
FROM
	[dbo].[LeaseOffers]					[o]
INNER JOIN
	[dbo].[LeaseAnalyses]				[l]
		ON	([o].[LeaseAnalysisId]	=	[l].[LeaseAnalysisId])
INNER JOIN
	[dbo].[Signatories]					[s]
		ON	([l].[SignatoryId]		=	[s].[SignatoryId])
INNER JOIN
	[dbo].[LeaseOffersEnque]			[e]
		ON	([o].[LeaseOfferId]		=	[e].[LeaseOfferId])
LEFT OUTER JOIN
	[dbo].[LeaseOffersDeque]			[d]
		ON	([o].[LeaseOfferId]		=	[d].[LeaseOfferId])
WHERE
	([d].[LeaseOffersDequeId]	IS NULL);