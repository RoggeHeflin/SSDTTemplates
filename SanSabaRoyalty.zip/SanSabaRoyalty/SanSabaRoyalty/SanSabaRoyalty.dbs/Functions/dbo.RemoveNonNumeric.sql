﻿CREATE FUNCTION [dbo].[RemoveNonNumeric]
(
	@String		AS VARCHAR(MAX)
)
RETURNS VARCHAR(MAX)
AS
BEGIN

	WHILE (PATINDEX('%[^0-9]%', @String) > 0)
	BEGIN
		SET @String = STUFF(@String, PATINDEX('%[^0-9]%', @String), 1, '')
	END;

	RETURN @String;

END;