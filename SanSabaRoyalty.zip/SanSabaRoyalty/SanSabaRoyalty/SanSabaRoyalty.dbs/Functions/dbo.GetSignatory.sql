﻿CREATE FUNCTION [dbo].[GetSignatory]
(
	@SignatoryNameFull		NVARCHAR(48)
)
RETURNS INT
AS
BEGIN
	DECLARE @Id		INT

	SELECT TOP 1
		@Id	= [t].[SignatoryId]
	FROM
		[dbo].[Signatories]	[t]
	WHERE
		([t].[SignatoryNameFull]	= @SignatoryNameFull);

	RETURN @Id

END;