﻿using System;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

[Serializable]
public partial class UserDefinedFunctions
{
	[SqlFunction
		(
			DataAccess = DataAccessKind.None,
			IsDeterministic = true,
			IsPrecise = true,
			Name = "Levenshtein",
			SystemDataAccess = SystemDataAccessKind.None
		)
	]
	public static double Levenshtein(SqlString A, SqlString B)
	{
		string s = (string)A;
		string t = (string)B;

		F23.StringSimilarity.Levenshtein l = new F23.StringSimilarity.Levenshtein();

		return l.Distance(s, t);
	}
}