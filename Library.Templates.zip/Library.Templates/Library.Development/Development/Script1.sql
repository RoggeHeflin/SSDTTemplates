﻿
	/*	Geospatial data columns:
		Latitude		- Stored in Degrees, 6 decimal places results in 0.111 meters of accuracy
		Longitude		- Stored in Degrees
		Elevation		- Range from -32,768 to 32,767 (Challenger Deep is 35,876 feet deep (10935 Meters); Mount Everest is 29,032 feet high (8849 meters))
		AccuracyRadius	- Amount of error in measurement
		Location		- geospatial conversion of Latitude and Longitude; formula is case-sensitive
	*/

	[Latitude]							DECIMAL(8, 6)		NOT	NULL, CONSTRAINT [CR_Latitude] CHECK(([Latitude] >= -90) AND ([Latitude] <=  90)),
	[Longitude]							DECIMAL(9, 6)		NOT	NULL, CONSTRAINT [CR_Longitude] CHECK(([Longitude] >= -180) AND ([Longitude] <=  180)),
	[Elevation_Meter]					SMALLINT()				NULL,
	[AccuracyRadius_Meter]				SMALLINT()				NULL,
	[Location]							AS geography::Point([Latitude], [Longitude], 4326)
										PERSISTED			NOT	NULL,
