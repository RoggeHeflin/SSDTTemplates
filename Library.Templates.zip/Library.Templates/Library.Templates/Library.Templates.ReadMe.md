﻿https://learn.microsoft.com/en-us/visualstudio/ide/template-parameters
https://learn.microsoft.com/en-us/visualstudio/ide/code-snippets-schema-reference