﻿# Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
# powershell.exe ..\..\PostBuildCreateZips.ps1 $(TargetName)

$TemplateGrouping		= $args[0]
$VisualStudioVersion	= 'Visual Studio 2022'

$PathTemplateSource		= $PSScriptRoot + '\Templates\'
$PathTemplateTarget		= [environment]::getfolderpath("mydocuments") + '\' + $VisualStudioVersion + '\Templates\ItemTemplates\' + $TemplateGrouping + '\'

Write-Host 'Creating target template folder:' $PathTemplateTarget
New-Item -ItemType Directory -Force -Path $PathTemplateTarget | Out-Null

Write-Host 'Compressing templates:'
$Folders	= Get-ChildItem -Path $PathTemplateSource -Directory -Force -ErrorAction SilentlyContinue -Name

foreach ($Folder in $Folders)
{
	$PathSource		= ($PathTemplateSource + '\' + $Folder + '\*')
	$PathTargetUsr	= ($PathTemplateTarget + $Folder + '.zip')

	Write-Host ('- ' + $Folder)

	Compress-Archive -Path $PathSource -DestinationPath $PathTargetUsr -Force
}

Write-Host 'Done! Compressed template files:'
Write-Host $PathTemplateTarget

$PathSnippetSource	= $PSScriptRoot + '\Snippets\*'
$PathSnippetTarget	= [environment]::getfolderpath("mydocuments") + '\' + $VisualStudioVersion + '\Code Snippets\SQL_SSDT\My Code Snippets\'

Write-Host 'Copying snippets:'
Copy-Item -Path $PathSnippetSource -Destination $PathSnippetTarget -Recurse -Force

Write-Host 'Done! Snippet files:'
Write-Host $PathSnippetTarget