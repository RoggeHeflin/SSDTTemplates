﻿CREATE FUNCTION $SchemaQualifiedObjectName$
(
	@Paramater1		INT
)
RETURNS @ReturnTable TABLE
(
	[Column1]			INT			NOT	NULL,
	PRIMARY KEY CLUSTERED (
		[Column1]	ASC
	)
)
WITH SCHEMABINDING
AS
BEGIN

	INSERT INTO @ReturnTable
	(
		[Column1]
	)
	SELECT
		[t].*
	FROM
		[$UnknownParentPlaceholder$]		[t];

	RETURN;

END;
GO

EXECUTE sp_addextendedproperty
	@name		= N'MS_Description',
	@value		= N'{Enter Description or Purpose Here}',
	@level0type	= N'schema',	@level0name	= N'$SchemaName$',
	@level1type	= N'function',		@level1name	= N'$rawname$';