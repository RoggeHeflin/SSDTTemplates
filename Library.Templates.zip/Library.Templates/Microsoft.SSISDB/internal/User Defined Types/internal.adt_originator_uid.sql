﻿CREATE TYPE [internal].[adt_originator_uid]
    FROM NVARCHAR (256) NOT NULL;

