﻿CREATE TYPE [internal].[adt_description]
    FROM NVARCHAR (1024) NULL;

