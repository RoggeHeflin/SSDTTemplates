﻿CREATE TYPE [internal].[adt_property_path]
    FROM NVARCHAR (MAX) NULL;

