﻿CREATE TYPE [internal].[adt_property_value]
    FROM VARBINARY (MAX) NULL;

