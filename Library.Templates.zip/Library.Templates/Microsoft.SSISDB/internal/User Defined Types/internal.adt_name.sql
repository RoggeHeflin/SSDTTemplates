﻿CREATE TYPE [internal].[adt_name]
    FROM NVARCHAR (256) NOT NULL;

