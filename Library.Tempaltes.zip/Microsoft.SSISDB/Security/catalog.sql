﻿CREATE SCHEMA [catalog]
    AUTHORIZATION [dbo];

