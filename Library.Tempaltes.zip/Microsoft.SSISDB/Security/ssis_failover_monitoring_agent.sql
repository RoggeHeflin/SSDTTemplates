﻿CREATE ROLE [ssis_failover_monitoring_agent]
    AUTHORIZATION [dbo];

