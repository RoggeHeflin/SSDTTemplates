﻿CREATE SCHEMA [internal]
    AUTHORIZATION [dbo];

