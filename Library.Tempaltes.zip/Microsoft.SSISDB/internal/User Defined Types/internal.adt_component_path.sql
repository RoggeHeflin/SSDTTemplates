﻿CREATE TYPE [internal].[adt_component_path]
    FROM NVARCHAR (1024) NULL;

