﻿CREATE TYPE [internal].[adt_message_text]
    FROM NVARCHAR (MAX) NULL;

