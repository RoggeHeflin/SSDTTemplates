﻿CREATE TYPE [internal].[adt_help_file]
    FROM NVARCHAR (200) NULL;

