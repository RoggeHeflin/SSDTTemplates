﻿CREATE TYPE [internal].[adt_component_id]
    FROM NVARCHAR (50) NULL;

