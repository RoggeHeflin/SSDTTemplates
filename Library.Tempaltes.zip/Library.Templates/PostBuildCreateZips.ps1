﻿# Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
# powershell.exe ..\..\PostBuildCreateZips.ps1 $(TargetName)

$VsProjectName = $args[0]

$PathRoot = $PSScriptRoot

$FileSuffix = '.zip'

$PathMyDocuments   = [environment]::getfolderpath("mydocuments")
$PathUserTemplates = $PathMyDocuments + '\Visual Studio 2022\Templates\ItemTemplates\' + $VsProjectName + '\'

Write-Host ('Creating folder: ' + $PathUserTemplates)
New-Item -ItemType Directory -Force -Path $PathUserTemplates | Out-Null

Write-Host 'Compressing template folders:'

$Folders = Get-ChildItem -Path $PathRoot -Exclude bin,obj,Icons -Directory -Force -ErrorAction SilentlyContinue -Name

foreach ($Folder in $Folders)
{
    $PathSource    = ($PathRoot + '\' + $Folder + '\*')
    $PathTargetUsr = ($PathUserTemplates + $Folder + $FileSuffix)

    Write-Host ($Folder + '\*')

    Compress-Archive -Path $PathSource -DestinationPath $PathTargetUsr -Force
}

Write-Host 'Compressed template files:'
Write-Host $PathUserTemplates