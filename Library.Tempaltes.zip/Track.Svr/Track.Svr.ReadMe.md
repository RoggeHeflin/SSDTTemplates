﻿# TrackSvr

## Installation
Publish [Track.Svr] as it's own database. Referencing databases will use the [Track.Svr] published database name in SQLCMD Variable Value.

[Referencing Database] > Properties > SQLCMD Variables > $(TrackSvr)

## ToDo:
- Calculate flags for stored procedures executions:
	- Mean, median, box plot