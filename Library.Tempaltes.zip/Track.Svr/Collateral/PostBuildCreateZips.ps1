﻿# Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
# powershell.exe ..\..\PostBuildCreateZips.ps1 $(TargetName)

$VsProjectName = $args[0]

$FileSuffix = '.zip'

$PathMyDocuments   = ([environment]::getfolderpath("mydocuments"))
$PathUserTemplates = ($PathMyDocuments + '\Visual Studio 2022\Templates\ProjectTemplates\' + $VsProjectName + $FileSuffix)

$PathSource		   = (Split-Path -Path $PSScriptRoot -Parent) + '\'

$FileList = New-Object Collections.Generic.List[String]

$FileList.Add($PathSource + 'Track.Svr.sqlproj')
$FileList.Add($PathSource + 'Track.Svr.ReadMe.md')
$FileList.Add($PathSource + 'Microsoft.SSISDB.dacpac')

$FileList.Add($PathSource + 'Collateral\DatabaseServer.png')
$FileList.Add($PathSource + 'Collateral\Track.Svr.vstemplate')

$FileList.Add($PathSource + 'track\Procedures\track.Insert_ProcedureLogOrphan.sql')
$FileList.Add($PathSource + 'track\Tables\track.ProcedureLogBegin.sql')
$FileList.Add($PathSource + 'track\Tables\track.ProcedureLogEnd.sql')
$FileList.Add($PathSource + 'track\Tables\track.ProcedureLogErrors.sql')
$FileList.Add($PathSource + 'track\Tables\track.ProcedureLogOrphans.sql')
$FileList.Add($PathSource + 'track\Views\track.ProcedureLog.sql')
$FileList.Add($PathSource + 'track\Views\track.SqlAgentHistory.sql')
$FileList.Add($PathSource + 'track\Views\track.SqlAgentSchedule.sql')
$FileList.Add($PathSource + 'track\Views\track.SqlAgentScheduleBase.sql')
$FileList.Add($PathSource + 'track\Views\track.SsisCatalogTasks.sql')
$FileList.Add($PathSource + 'track\track.sql')

Compress-Archive -Path $FileList -DestinationPath $PathUserTemplates -Force

Write-Host 'Compressed template files:'
Write-Host $PathUserTemplates