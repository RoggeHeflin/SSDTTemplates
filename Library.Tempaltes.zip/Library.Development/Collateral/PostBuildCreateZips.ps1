﻿# Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
# powershell.exe ..\..\Collateral\PostBuildCreateZips.ps1 $(TargetName)

$VsProjectName = $args[0]

$FileSuffix = '.zip'

$PathMyDocuments   = ([environment]::getfolderpath("mydocuments"))
$PathUserTemplates = ($PathMyDocuments + '\Visual Studio 2022\Templates\ProjectTemplates\' + $VsProjectName + $FileSuffix)

$PathSource		   = (Split-Path -Path $PSScriptRoot -Parent) + '\'

$FileList = New-Object Collections.Generic.List[String]

$FileList.Add($PathSource + 'Library.Development.sqlproj')
$FileList.Add($PathSource + 'Library.Development.ReadMe.md')

$FileList.Add($PathSource + 'Collateral\DatabaseServer.png')
$FileList.Add($PathSource + 'Collateral\Library.Development.vstemplate')

$FileList.Add($PathSource + 'Deployment\Script.PostDeployment.sql')
$FileList.Add($PathSource + 'Deployment\dim\insert.dim.CalendarDates.sql')

$FileList.Add($PathSource + 'clc\clc.sql')
$FileList.Add($PathSource + 'dim\dim.sql')
$FileList.Add($PathSource + 'dim\Functions\dim.HierarchyPrefix.sql')
$FileList.Add($PathSource + 'dim\Functions\dim.Select_CalendarDates.sql')
$FileList.Add($PathSource + 'dim\Tables\dim.Calendar.sql')
$FileList.Add($PathSource + 'doc\doc.sql')
$FileList.Add($PathSource + 'doc\Views\doc.TableProperties.sql')
$FileList.Add($PathSource + 'fct\fct.sql')
$FileList.Add($PathSource + 'rpt\rpt.sql')
$FileList.Add($PathSource + 'stg\stg.sql')

Compress-Archive -Path $FileList -DestinationPath $PathUserTemplates -Force

Write-Host 'Compressed template files:'
Write-Host $PathUserTemplates