import DrillingInfo as Di

import concurrent.futures


def di_api_engine() -> Di.ApiEngine:
    init_key: str = '3c7466645939dba3b07d705ee9900dd9'
    init_client: str = '532-direct-access'
    init_secret: str = 'a973bd7c-ec61-413a-bda9-887a85570522'

    # data_sql_driver: str = 'SQL Server Native Client 11.0'
    data_sql_driver: str = 'ODBC Driver 17 for SQL Server'
    data_sql_server: str = 'ThinkPadT440p\\SQL'
    data_sql_port: str = '54075'
    data_sql_database: str = 'DrillingInfo'
    data_sql_schema: str = 'stg'

    return Di.ApiEngine(init_key, init_client, init_secret,
                        data_sql_driver, data_sql_server, data_sql_port,
                        data_sql_database, data_sql_schema)


class Proc:
    @staticmethod
    def rigs(dia: Di.ApiEngine):
        print('Beg: Rigs')
        tgt: str = 'DrillingInfoRigs'
        src: str = 'rigs'

        ftr: dict = {}
        ftr.clear()
        ftr['pagesize'] = 200
        ftr['DIStateProvinceCode'] = 'TX'
        ftr['DeletedDate'] = 'eq(null)'

        dia.process_stage(tgt, src, ftr)
        print('End: Rigs')

    @staticmethod
    def deals_for_sale(dia: Di.ApiEngine):
        print('Beg: Deals')
        tgt: str = 'DrillingInfoDealsForSale'
        src: str = 'deals-for-sale'

        ftr: dict = {}
        ftr.clear()
        ftr['pagesize'] = 10000

        dia.process_stage(tgt, src, ftr)
        print('End: Deals')

    @staticmethod
    def permits(dia: Di.ApiEngine):
        print('Beg: Permits')
        tgt: str = 'DrillingInfoPermits'
        src: str = 'permits'

        ftr: dict = {}
        ftr.clear()
        ftr['pagesize'] = 10000
        ftr['StateProvince'] = 'TX'
        ftr['UpdatedDate'] = 'gt(2021-03-01)'

        dia.process_stage(tgt, src, ftr)
        print('End: Permits')

    @staticmethod
    def leases_legal(dia: Di.ApiEngine):
        print('Beg: Legal')
        tgt: str = 'DrillingInfoLeasesLegal'
        src: str = 'legal-leases'

        ftr: dict = {}
        ftr.clear()
        ftr['pagesize'] = 10000
        ftr['State'] = 'TX'
        # ftr['UpdatedDate'] = 'gt(2021-02-01)'

        dia.process_stage(tgt, src, ftr)
        print('End: Legal')

    @staticmethod
    def leases_landtrac(dia: Di.ApiEngine):
        print('Beg: Landtrac')
        tgt: str = 'DrillingInfoLeasesLandtrac'
        src: str = 'landtrac-leases'

        ftr: dict = {}
        ftr.clear()
        ftr['pagesize'] = 10000
        ftr['State'] = 'TX'
        # ftr['UpdatedDate'] = 'gt(2021-02-01)'

        dia.process_stage(tgt, src, ftr)
        print('End: Landtrac')

    @staticmethod
    def wells(dia: Di.ApiEngine):
        print('Beg: Wells')
        tgt: str = 'DrillingInfoWells'
        src: str = 'well-origins'

        ftr: dict = {}
        ftr.clear()
        ftr['pagesize'] = 10000
        ftr['ProvinceState'] = 'TEXAS'
        # ftr['DeletedDate'] = 'eq(null)'

        dia.process_stage(tgt, src, ftr)
        print('End: Wells')


if __name__ == '__main__':
    eng = di_api_engine()

    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        fs = {executor.submit(Proc.rigs, eng),
              executor.submit(Proc.deals_for_sale, eng),
              executor.submit(Proc.permits, eng),
              executor.submit(Proc.leases_legal, eng),
              executor.submit(Proc.leases_landtrac, eng),
              executor.submit(Proc.wells, eng)}

        for f in concurrent.futures.as_completed(fs):
            try:
                i: int = f.result()
            except Exception as exc:
                print(exc)
            else:
                print(f'results: {i}')

    # Proc.rigs(eng)
    # Proc.deals_for_sale(eng)
    # Proc.permits(eng)
    # Proc.leases_legal(eng)
    # Proc.leases_landtrac(eng)
    # Proc.wells(eng)

    print('Complete!')
