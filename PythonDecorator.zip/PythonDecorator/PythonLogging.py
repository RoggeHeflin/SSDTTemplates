from abc import ABC, abstractmethod

import datetime
import inspect
import os
import platform
import sys

import pandas as pd
import sqlalchemy
import sqlite3


class ILogger(ABC):

    @abstractmethod
    def beg(self, application_name: str, class_path: str, method_name: str) -> int:
        return 0

    @abstractmethod
    def end(self, idx: int):
        pass

    @abstractmethod
    def err(self, idx: int, error_message: str):
        pass


class LogFactory:
    def __init__(self, log: ILogger):
        self.log: ILogger = log

    def __call__(self, fcn):
        def wrapper(cls, *args, **kwargs):
            application_name: str = sys.argv[0]

            if inspect.isclass(cls):
                class_path: str = cls.__qualname__
            else:
                class_path: str = cls.__class__.__qualname__

            idx = self.log.beg(application_name, class_path, fcn.__name__)

            try:
                output = fcn(cls, *args, **kwargs)
                self.log.end(idx)
                return output

            except Exception as ex:
                msg: str = str(ex)
                self.log.err(idx, msg)
                return ex

        return wrapper


class LoggerSqlServer(ILogger):
    def __init__(self, sql_driver: str, sql_server: str, sql_port: str, sql_database: str):
        self.eng: sqlalchemy.engine = sqlalchemy.create_engine(
            f'mssql+pyodbc://{sql_server}:{sql_port}/{sql_database}?driver={sql_driver}'). \
            execution_options(isolation_level='SERIALIZABLE', fast_executemany=True)

    def beg(self, application_name: str, class_path: str, method_name: str) -> int:
        with self.eng.begin() as con:
            res: sqlalchemy.engine.result = con.execute('[track].[InsertApplicationLogBegin] ?, ?, ?, ?, ?',
                                                        [application_name, class_path, method_name,
                                                         sys.version, platform.platform()])
            idx: int = res.fetchone()[0]
            return idx

    def end(self, idx: int):
        with self.eng.begin() as con:
            con.execute('[track].[InsertApplicationLogEnd] ?', [idx])

    def err(self, idx: int, error_message: str):
        with self.eng.begin() as con:
            con.execute('[track].[InsertApplicationLogError] ?, ?', [idx, error_message])


class LoggerSqlite(ILogger):
    def __init__(self, db_path: str):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute('''CREATE TABLE IF NOT EXISTS ApplicationLogBegin
                          (ApplicationLogId     INTEGER         PRIMARY KEY AUTOINCREMENT,
                          NameClass             VARCHAR(128)    NOT NULL,
                          NameFunction          VARCHAR(128)    NOT NULL,
                          ApplicationVersion    VARCHAR(128)    NOT NULL,
                          ApplicationPlatform   VARCHAR(128)    NOT NULL,

                          txInserted            DATETIME        NOT NULL,
                          txInsertedUser        NVARCHAR(128)   NOT NULL,
                          txInsertedHost        NVARCHAR(128)   NOT NULL,
                          txInsertedApp         NVARCHAR(128)   NOT NULL
                          )''')

        self.conn.execute('''CREATE TABLE IF NOT EXISTS ApplicationLogEnd
                           (ApplicationLogId    INT             NOT NULL,
                           txInserted           DATETIME        NOT NULL,
                           FOREIGN KEY(ApplicationLogId) REFERENCES ApplicationLogBegin(ApplicationLogId)
                           )''')

        self.conn.execute('''CREATE TABLE IF NOT EXISTS ApplicationLogErrors
                          (ApplicationLogId     INT             NOT NULL,
                          ErrorMessage          NVARCHAR        NOT NULL,
                          txInserted            DATETIME        NOT NULL,
                          FOREIGN KEY(ApplicationLogId) REFERENCES ApplicationLogBegin(ApplicationLogId)
                          )''')

    def beg(self, application_name: str, class_path: str, method_name: str) -> int:
        sql_insert = f'''INSERT INTO ApplicationLogBegin
                 (NameClass, NameFunction, ApplicationVersion, ApplicationPlatform,
                 txInserted, txInsertedUser, txInsertedHost, txInsertedApp)
             VALUES
                 (?, ?, ?, ?, ?, ?, ?, ?)'''

        sql_values = (class_path, method_name, sys.version, platform.platform(),
                      datetime.datetime.now(), os.getlogin(), platform.node(), application_name)

        cur = self.conn.cursor()
        cur.execute(sql_insert, sql_values)
        idx = cur.lastrowid

        self.conn.commit()
        cur.close()

        return idx

    def end(self, idx: int):
        sql_insert = f'''INSERT INTO ApplicationLogEnd
                 (ApplicationLogId, txInserted)
             VALUES
                 (?, ?)'''

        sql_values = (idx, datetime.datetime.now())

        cur = self.conn.cursor()
        cur.execute(sql_insert, sql_values)

        self.conn.commit()
        cur.close()

    def err(self, idx: int, message: str):
        sql_insert = f'''INSERT INTO ApplicationLogErrors
                 (ApplicationLogId, ErrorMessage, txInserted)
             VALUES
                 (?, ?, ?)'''

        sql_values = (idx, message, datetime.datetime.now())

        cur = self.conn.cursor()
        cur.execute(sql_insert, sql_values)

        self.conn.commit()
        cur.close()


class LoggerSqlite3(ILogger):
    def __init__(self, db_path: str):
        self.eng: sqlalchemy.engine = sqlalchemy.create_engine(f'sqlite:///{db_path}')
#         self.eng.execute('''CREATE VIEW IF NOT EXISTS [Log]
# AS
# SELECT
#     [b].[LogId],
#
#     [b].[NameClass],
#     [b].[NameFunction],
#     [b].[ApplicationVersion],
#     [b].[ApplicationPlatform],
#
#     [b].[txInsertedUser]        [ApplicationUser],
#     [b].[txInsertedHost]    	[ApplicationHost],
#     [b].[txInsertedApp]         [ApplicationApp],
#     [b].[txInserted]        	[ApplicationBegin],
#
#     [e].[txInserted]            [ApplicationEnd],
#     [r].[txInserted]        	[ApplicationError],
#
#     COALESCE([e].[txInserted], [r].[txInserted])    [Terminate],
#     COALESCE([e].[txInserted], [r].[txInserted], DATE('NOW'))   [TerminateStamp],
#
#     NULL                    	[Duration],
#     NULL	                    [DurationMinutes],
#     NULL	                    [DurationSeconds],
#
#     [r].[ErrorMessage]
# FROM
#     [main].[LogBegin]        	[b]
# LEFT OUTER JOIN
#     [main].[LogEnd]	    		[e]
#         ON	([b].[LogId]	=	[e].[LogId])
# LEFT OUTER JOIN
#     [main].[LogErrors]		    [r]
#         ON	([b].[LogId]	=	[r].[LogId]);''')

    def beg(self, application_name: str, class_path: str, method_name: str) -> int:
        import uuid
        idx = uuid.uuid4().int

        dc = ['LogId', 'NameClass', 'NameFunction', 'ApplicationVersion', 'ApplicationPlatform',
              'txInserted', 'txInsertedUser', 'txInsertedHost', 'txInsertedApp']
        dt = [[str(idx), class_path, method_name, sys.version, platform.platform(),
              datetime.datetime.now(), os.getlogin(), platform.node(), application_name]]
        df = pd.DataFrame(dt, columns=dc)
        df.to_sql('LogBegin', self.eng, if_exists='append', index=False)

        return idx

    def end(self, idx: int):
        dc = ['LogId', 'txInserted']
        dt = [[str(idx), datetime.datetime.now()]]
        df = pd.DataFrame(dt, columns=dc)
        df.to_sql('LogEnd', self.eng, if_exists='append', index=False)

    def err(self, idx: int, error_message: str):
        dc = ['LogId', 'ErrorMessage', 'txInserted']
        dt = [[str(idx), error_message, datetime.datetime.now()]]
        df = pd.DataFrame(dt, columns=dc)
        df.to_sql('LogErrors', self.eng, if_exists='append', index=False)


class BatchLogger:
    def __init__(self, sql_driver: str, sql_server: str, sql_port: str, sql_database: str):
        self.eng: sqlalchemy.engine = sqlalchemy.create_engine(
            f'mssql+pyodbc://{sql_server}:{sql_port}/{sql_database}?driver={sql_driver}'). \
            execution_options(isolation_level='SERIALIZABLE', fast_executemany=True)

    def beg(self, sql_schema_target: str, sql_table_target: str, api_dataset: str) -> int:
        with self.eng.begin() as con:
            res: sqlalchemy.engine.result = con.execute('[track].[InsertBatchLogBegin] ?, ?, ?',
                                                        [sql_schema_target, sql_table_target, api_dataset])
            idx: int = res.fetchone()[0]
            return idx

    def end(self, batch_id: int, row_count: int, update_date_beg, update_date_end, source_notes: str):
        with self.eng.begin() as con:
            con.execute('[track].[InsertBatchLogEnd] ?, ?, ?, ?, ?',
                        [batch_id, row_count, update_date_beg, update_date_end, source_notes])

    def end_stage(self, batch_id: int, sql_schema_target: str, sql_table_target: str):
        with self.eng.begin() as con:
            con.execute(f'[{sql_schema_target}].[InsertBatchLogEnd_{sql_table_target}] ?',
                        [batch_id])


if __name__ == '__main__':
    import time
    import concurrent.futures

    # sql_driver: str = 'ODBC Driver 17 for SQL Server'
    # sql_driver: str = 'SQL Server Native Client RDA 11.0'
    sql_driver: str = 'SQL Server Native Client 11.0'
    sql_server: str = 'ThinkPadT440p\\SQL'
    sql_port: str = '54075'
    sql_database: str = 'DrillingInfo'


    class Primary:
        class Secondary:
            @LogFactory(LoggerSqlite('D:/Data SQLite/PythonLogger.db'))
            @LogFactory(LoggerSqlite3('D:/Data SQLite/PythonLogger.db'))
            def fibonacci(self, n: int) -> int:
                fibs = [0, 1, 1]
                for f in range(2, n):
                    print(f'              f: {fibs[-1]}')
                    fibs.append(fibs[-1] + fibs[-2])
                    # time.sleep(0.2)
                return fibs[n]

            # @LogFactory(LoggerSqlite('D:/Data SQLite/PythonLogger.db'))
            @LogFactory(LoggerSqlite3('D:/Data SQLite/PythonLogger.db'))
            # @LogFactory(LoggerSqlServer(sql_driver, sql_server, sql_port, sql_database))
            def factorial(self, n: int, acc: int = 1) -> int:
                print(f'n: {n} - a: {acc}')
                # time.sleep(0.3)

                acc = acc * n
                n = n - 1

                if n == 0:
                    return acc
                else:
                    return self.factorial(n, acc)


    p: Primary = Primary()
    s: Primary.Secondary = p.Secondary()
    print(f'Factorial: {s.factorial(10)}')
    print(f'Fibonacci: {s.fibonacci(8)}')

    # https://docs.python.org/3/library/concurrent.futures.html

    # with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
    #     print('enqueue')
    #     fs = {executor.submit(s.fibonacci, 8),
    #           executor.submit(s.factorial, 4)}
    #
    #     for f in concurrent.futures.as_completed(fs):
    #         print(f'dequeue')
    #         try:
    #             i: int = f.result()
    #         except Exception as exc:
    #             print(exc)
    #         else:
    #             print(f'results: {i}')
