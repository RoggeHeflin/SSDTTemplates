import base64
from datetime import datetime, timedelta
import http.client
import json
import pandas as pd
import sqlalchemy

import PythonLogging as Pl


log_driver: str = 'SQL Server Native Client 11.0'
log_server: str = 'ThinkPadT440p\\SQL'
log_port: str = '54075'
log_database: str = 'DrillingInfo'


class ApiEngine:
    @Pl.LogFactory(Pl.LoggerSqlServer(log_driver, log_server, log_port, log_database))
    def __init__(self, api_key: str, api_id: str, api_secret: str,
                 sql_driver: str,
                 sql_server: str, sql_port: str, sql_database: str,
                 sql_schema: str
                 ):
        self.sql_schema: str = sql_schema
        self.eng: sqlalchemy.engine = sqlalchemy.create_engine(
            f'mssql+pyodbc://{sql_server}:{sql_port}/{sql_database}?driver={sql_driver}'). \
            execution_options(isolation_level="AUTOCOMMIT", fast_executemany=True)
        self.di: ApiEngine.DirectAccess = self.DirectAccess(api_key, api_id, api_secret)

    class DirectAccess:
        url: str = 'di-api.drillinginfo.com'
        url_version: str = '/v2/direct-access'
        user_agent: str = 'San Saba Royalty'

        def __init__(self, api_key: str, api_id: str, api_secret: str):
            self.api_key: str = api_key
            self.api_token = self.Token(api_key, api_id, api_secret, self.url, self.url_version, self.user_agent)

        class Token:
            def __init__(self, api_key: str, api_id: str, api_secret: str, url: str, url_version: str, user_agent: str):
                self.api_key = api_key
                self.api_id = api_id
                self.api_secret = api_secret

                self.url = url
                self.url_version = url_version
                self.user_agent = user_agent

                self.jsn = self.__get_api_token()
                self.expires_at: datetime = datetime.now() + timedelta(seconds=self.jsn['expires_in'])

            @Pl.LogFactory(Pl.LoggerSqlServer(log_driver, log_server, log_port, log_database))
            def __get_api_token(self) -> dict:
                url_suffix: str = self.url_version + '/tokens'
                content_type: str = 'application/x-www-form-urlencoded'
                payload: str = "grant_type=client_credentials"
                api_encrypted: str = 'basic ' + base64.b64encode(
                    (self.api_id + ":" + self.api_secret).encode()).decode()
                headers = {
                    'X-API-KEY': self.api_key,
                    'Content-Type': content_type,
                    'Authorization': api_encrypted,
                    'User - Agent': self.user_agent
                }

                con = http.client.HTTPSConnection(self.url)
                con.request("POST", url_suffix, payload, headers)

                res = con.getresponse()
                byt = res.read()
                jsn = json.loads(byt)

                return jsn

            def __is_expired(self) -> bool:
                return datetime.now() >= self.expires_at

            def bearer(self) -> str:
                if self.__is_expired():
                    self.jsn = self.__get_api_token()
                return 'bearer ' + self.jsn['access_token']

        def populate_database_recursive(self, batch_id: int, url_suffix: str, sql_table: str, sql_schema: str, eng: sqlalchemy.engine,
                                        row_count: int = 0) -> int:
            payload = ''
            headers = {
                'X-API-KEY': self.api_key,
                'Authorization': self.api_token.bearer()
            }

            print(url_suffix)

            con = http.client.HTTPSConnection(self.url)
            con.request('GET', self.url_version + url_suffix, payload, headers)

            res = con.getresponse()
            byt = res.read()
            dtf = pd.read_json(byt)

            dtf['txUrlLinkSuffix'] = url_suffix
            dtf['txBatchId'] = batch_id

            dtf.to_sql(name=sql_table, schema=sql_schema, con=eng,
                       if_exists='append', index=False,
                       chunksize=10000)

            hdr = res.getheader('Link')
            hdr = hdr[1:len(hdr) - 13]

            itm: int = len(dtf.index)

            row_count = row_count + itm

            if itm == 0:
                return row_count
            else:
                return self.populate_database_recursive(batch_id, hdr, sql_table, sql_schema, eng, row_count)

    @Pl.LogFactory(Pl.LoggerSqlServer(log_driver, log_server, log_port, log_database))
    def populate_stage(self, sql_table: str, api_dataset: str, api_filter: dict) -> int:
        sfx = '?'

        for k, v in api_filter.items():
            sfx = sfx + ('' if (sfx == '?') else '&') + f'{k}={v}'

        url_suffix = '/' + api_dataset + sfx

        bl: Pl.BatchLogger = Pl.BatchLogger(log_driver, log_server, log_port, log_database)
        batch_id: int = bl.beg(self.sql_schema, sql_table, api_dataset)

        row_count: int = self.di.populate_database_recursive(batch_id, url_suffix, sql_table, self.sql_schema, self.eng)

        if row_count == 0 or row_count == 'None':
            bl.end(batch_id, 0, None, None, url_suffix)
        else:
            bl.end_stage(batch_id, url_suffix)

        return row_count

    @Pl.LogFactory(Pl.LoggerSqlServer(log_driver, log_server, log_port, log_database))
    def process_stage(self, sql_table: str, api_dataset: str, api_filter: dict) -> int:

        print(f'Beginning: {api_dataset} -> {sql_table}')

        sql_delete: str = f'[{self.sql_schema}].[Delete{sql_table}]'

        with self.eng.connect().execution_options(autocommit=True) as con:
            con.execute(sql_delete)

        if 'DeletedDate' not in api_filter and 'UpdatedDate' not in api_filter:
            sql_return: str = f'[{self.sql_schema}].[Return{sql_table}_LastApiUpdate]'

            with self.eng.connect() as con:
                update_datestamp: str = str(con.execute(sql_return).fetchone()[0])

            if update_datestamp == 'None':
                api_filter['DeletedDate'] = 'eq(null)'
            else:
                update_datestamp = f'''{update_datestamp[0:23].replace(' ', 'T')}Z'''
                api_filter['UpdatedDate'] = f'gt({update_datestamp})'

        row_count: int = self.populate_stage(sql_table, api_dataset, api_filter)

        print(f'Complete:  {api_dataset} -> {sql_table}')

        return row_count
