﻿CREATE FUNCTION $SchemaQualifiedObjectName$
(
	@Paramater1		INT
)
RETURNS INT
WITH SCHEMABINDING, RETURNS NULL ON NULL INPUT
AS
BEGIN

	DECLARE @ReturnValue		INT;

	SELECT TOP(1)
		@ReturnValue = [t].[1]
	FROM
		[$UnknownParentPlaceholder$]		[t];

	RETURN @ReturnValue;

END;
GO

EXECUTE sp_addextendedproperty
	@name		= N'MS_Description',
	@value		= N'{Enter Description or Purpose Here}',
	@level0type	= N'schema',	@level0name	= N'$SchemaName$',
	@level1type	= N'function',		@level1name	= N'$rawname$';