﻿CREATE FUNCTION $SchemaQualifiedObjectName$
(
	@Paramater1		INT
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
	SELECT
		[t].*
	FROM
		[$UnknownParentPlaceholder$]		[t];
);
GO

EXECUTE sp_addextendedproperty
	@name		= N'MS_Description',
	@value		= N'{Enter Description or Purpose Here}',
	@level0type	= N'schema',	@level0name	= N'$SchemaName$',
	@level1type	= N'function',		@level1name	= N'$rawname$';