﻿CREATE TABLE [$SchemaName$].[$rawname$Parent]
(
	[txId_$rawname$]						INT						NOT	NULL	CONSTRAINT [FK_$rawname$Parent_$rawname$LookUp]			FOREIGN KEY ([txId_$rawname$])	REFERENCES [$SchemaName$].[$rawname$LookUp]([txId_$rawname$]),
	[ParentId]								INT						NOT	NULL	CONSTRAINT [FK_$rawname$Parent_$rawname$LookUp_Parent]	FOREIGN KEY ([ParentId])	REFERENCES [$SchemaName$].[$rawname$LookUp]([txId_$rawname$]),
																				CONSTRAINT [FK_$rawname$Parent_$rawname$LookUp_Self]	FOREIGN KEY ([ParentId])	REFERENCES [$SchemaName$].[$rawname$Parent]([txId_$rawname$]),
	[IsRoot]								AS CONVERT(BIT, CASE WHEN ([txId_$rawname$] = [ParentId]) THEN 1 ELSE 0 END)
											PERSISTED				NOT	NULL,

	[txInserted]							DATETIMEOFFSET(7)		NOT	NULL	CONSTRAINT [DF_$rawname$Parent_txInserted]				DEFAULT(SYSDATETIMEOFFSET()),
	[txInsertedSID]							VARBINARY(85)			NOT	NULL	CONSTRAINT [DF_$rawname$Parent_txInsertedSID]			DEFAULT(SUSER_SID()),
	[txInsertedUser]						NVARCHAR(128)			NOT	NULL	CONSTRAINT [DF_$rawname$Parent_txInsertedUser]			DEFAULT(SUSER_SNAME()),
	[txInsertedHost]						NVARCHAR(128)			NOT	NULL	CONSTRAINT [DF_$rawname$Parent_txInsertedHost]			DEFAULT(HOST_NAME()),
	[txInsertedApp]							NVARCHAR(128)			NOT	NULL	CONSTRAINT [DF_$rawname$Parent_txInsertedApp]			DEFAULT(HOST_NAME()),
	[txRowReplication]						UNIQUEIDENTIFIER		NOT	NULL	CONSTRAINT [DF_$rawname$Parent_txRowReplication]		DEFAULT(NEWSEQUENTIALID())	ROWGUIDCOL,
	[txRowVersion]							ROWVERSION				NOT	NULL,

	CONSTRAINT [PK_$rawname$Parent]			PRIMARY KEY CLUSTERED([txId_$rawname$]	ASC)
);
GO

CREATE UNIQUE NONCLUSTERED INDEX [UX_$rawname$Parent_Function]
ON [$SchemaName$].[$rawname$Parent]
(
	[txId_$rawname$]		ASC
)
INCLUDE
(
	[ParentId]
);
GO

CREATE TRIGGER [$SchemaName$].[$rawname$Parent_AfterUpdate]
ON [$SchemaName$].[$rawname$Parent]
AFTER INSERT, UPDATE
AS
BEGIN

	EXECUTE	[$SchemaName$].[Update_$rawname$ParentHierarchy];
	EXECUTE	[$SchemaName$].[Update_$rawname$ParentNest];
	EXECUTE	[$SchemaName$].[Update_$rawname$Bridge];

END;