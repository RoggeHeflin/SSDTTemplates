﻿CREATE VIEW [$SchemaName$].[$rawname$]
WITH SCHEMABINDING, VIEW_METADATA
AS
SELECT
	[l].[txId_$rawname$],

	[l].[$rawname$Tag],
	[l].[$rawname$Abbr],
	[l].[$rawname$Name],
	[l].[$rawname$Desc],

	[l].[SortKey],
	[l].[Operator],
	[l].[Multiplier],

	[p].[ParentId],
	[p].[IsRoot],

	[h].[Hierarchy],
	[h].[HierarchyPath],
	[h].[HierarchyItem],
	[h].[HierarchyDepth],
	[h].[HierarchyDepthMax],
	[h].[HierarchyChildren],
	[h].[HierarchyIsLeaf],
	[h].[HierarchyPrefix],

	[n].[NestLeft],
	[n].[NestRight],
	[n].[NestSpan]
FROM
	[$SchemaName$].[$rawname$LookUp]			[l]
INNER JOIN
	[$SchemaName$].[$rawname$Parent]			[p]
		ON	([l].[txId_$rawname$]	=	[p].[txId_$rawname$])
INNER JOIN
	[$SchemaName$].[$rawname$ParentHierarchy]	[h]
		ON	([l].[txId_$rawname$]	=	[h].[txId_$rawname$])
INNER JOIN
	[$SchemaName$].[$rawname$ParentNest]		[n]
		ON	([l].[txId_$rawname$]	=	[n].[txId_$rawname$]);
GO

CREATE UNIQUE CLUSTERED INDEX [UC_$rawname$]
ON [$SchemaName$].[$rawname$]
(
	[txId_$rawname$],

	[$rawname$Tag],
	[$rawname$Abbr],
	[$rawname$Name],
	[$rawname$Desc],

	[SortKey],
	[Operator],
	[Multiplier],

	[ParentId],
	[IsRoot],

	[Hierarchy],
	[HierarchyPath],
	[HierarchyItem],
	[HierarchyDepth],
	[HierarchyDepthMax],
	[HierarchyChildren],
	[HierarchyIsLeaf],
	[HierarchyPrefix],

	[NestLeft],
	[NestRight],
	[NestSpan]
);
GO

CREATE VIEW [$SchemaName$].[$rawname$_Path]
WITH SCHEMABINDING, VIEW_METADATA
AS
SELECT
	[t].[txId_$rawname$],

	[t].[$rawname$Tag],
	[t].[$rawname$Abbr],
	[t].[$rawname$Name],
	[t].[$rawname$Desc],

	[t].[SortKey],
	[t].[Operator],
	[t].[Multiplier],

	[t].[ParentId],
	[t].[IsRoot],

	[t].[Hierarchy],
	[t].[HierarchyPath],
	[t].[HierarchyItem],
	[t].[HierarchyDepth],
	[t].[HierarchyDepthMax],
	[t].[HierarchyChildren],
	[t].[HierarchyIsLeaf],
	[t].[HierarchyPrefix],

	[t].[NestLeft],
	[t].[NestRight],
	[t].[NestSpan],

	[PathName]	= STUFF(((
		SELECT		N'|' + [x].[$rawname$Name]
		FROM		[dim].[$rawname$Ancestors]([t].[txId_$rawname$]) [x]
		ORDER BY	[x].[Hierarchy] ASC
		FOR XML PATH (N''),
		TYPE).value(N'(./text())[1]', N'NVARCHAR(MAX)')), 1, 1, N''),

	[PathSort]	= STUFF(((
		SELECT		N'|' + CAST([x].[SortKey] AS NVARCHAR(MAX))
		FROM		[dim].[$rawname$Ancestors]([t].[txId_$rawname$]) [x]
		ORDER BY	[x].[Hierarchy] ASC
		FOR XML PATH (N''),
		TYPE).value(N'(./text())[1]', N'NVARCHAR(MAX)')), 1, 1, N'')

FROM
	[$SchemaName$].[$rawname$]	[t]	WITH(NOEXPAND);
