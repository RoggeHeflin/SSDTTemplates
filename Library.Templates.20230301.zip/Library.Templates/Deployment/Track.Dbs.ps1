﻿Write-Host '--------------------------------------------------------------------------------------------------------------------------------------------'
Write-Host 'Deploying SSDT Project Template: Track.Dbs...'

$VisualStudioVersion	= $args[0]
$ProjectTemplateName	= $args[1]

$PathTemplate			= $PSScriptRoot + '\' + $ProjectTemplateName + '\'
$PathProject			= (Get-Item $PSScriptRoot).parent.parent.FullName + '\' + $ProjectTemplateName + '\'

$PathTemplateTarget		= ([environment]::getfolderpath("mydocuments") + '\' + $VisualStudioVersion + '\Templates\ProjectTemplates\' + $ProjectTemplateName + '.zip')

$FileList				= New-Object Collections.Generic.List[String]

$FileList.Add($PathTemplate + '\Track.Dbs.png')
$FileList.Add($PathTemplate + '\Track.Dbs.vstemplate')
$FileList.Add($PathTemplate + '\Track.Dbs.sqlproj')

$FileList.Add($PathProject + 'Track.Dbs.ReadMe.md')

$FileList.Add($PathProject + 'track\Procedures\track.Insert_ProcedureLogBegin.sql')
$FileList.Add($PathProject + 'track\Procedures\track.Insert_ProcedureLogEnd.sql')
$FileList.Add($PathProject + 'track\Procedures\track.Insert_ProcedureLogError.sql')
$FileList.Add($PathProject + 'track\track.sql')

Compress-Archive -Path $FileList -DestinationPath $PathTemplateTarget -Force

Write-Host 'Compressed project template file:'
Write-Host $PathTemplateTarget