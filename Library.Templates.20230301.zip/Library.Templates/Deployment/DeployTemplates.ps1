﻿# Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
# powershell.exe ..\..\PostBuildCreateZips.ps1 $(TargetName)

$VisualStudioVersion	= $args[0]
$TemplateGrouping		= $args[1]

& ($PSScriptRoot + '\Library.Templates.Snippets.ps1')	$VisualStudioVersion
& ($PSScriptRoot + '\Library.Templates.Objects.ps1')	$VisualStudioVersion 'Library.Templates'
& ($PSScriptRoot + '\Library.Development.ps1')			$VisualStudioVersion 'Library.Development'
& ($PSScriptRoot + '\Track.Svr.ps1')					$VisualStudioVersion 'Track.Svr'
& ($PSScriptRoot + '\Track.Dbs.ps1')					$VisualStudioVersion 'Track.Dbs'
