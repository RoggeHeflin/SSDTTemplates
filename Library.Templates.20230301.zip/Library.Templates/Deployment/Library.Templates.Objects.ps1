﻿Write-Host '--------------------------------------------------------------------------------------------------------------------------------------------'
Write-Host 'Deploying SSDT Item Templates...'

$VisualStudioVersion	= $args[0]
$TemplateGrouping		= $args[1]

$PathProject			= (Get-Item $PSScriptRoot).parent.FullName + '\'

$PathTemplateSource		= $PathProject + 'Objects\'
$PathTemplateTarget		= [environment]::getfolderpath("mydocuments") + '\' + $VisualStudioVersion + '\Templates\ItemTemplates\' + $TemplateGrouping + '\'

Write-Host 'Creating target template folder:' $PathTemplateTarget
New-Item -ItemType Directory -Force -Path $PathTemplateTarget | Out-Null

Write-Host 'Compressing object templates:'
$Folders	= Get-ChildItem -Path $PathTemplateSource -Directory -Force -ErrorAction SilentlyContinue -Name

foreach ($Folder in $Folders)
{
	$PathSource		= ($PathTemplateSource + '\' + $Folder + '\*')
	$PathTargetUsr	= ($PathTemplateTarget + $Folder + '.zip')

	Write-Host ('- ' + $Folder)

	Compress-Archive -Path $PathSource -DestinationPath $PathTargetUsr -Force
}

Write-Host 'Done! Compressed object template files:'
Write-Host $PathTemplateTarget
