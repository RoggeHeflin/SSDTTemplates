﻿Write-Host '--------------------------------------------------------------------------------------------------------------------------------------------'
Write-Host 'Deploying SSDT Project Template: Track.Svr...'

$VisualStudioVersion	= $args[0]
$ProjectTemplateName	= $args[1]

$PathTemplate			= $PSScriptRoot + '\' + $ProjectTemplateName + '\'
$PathProject			= (Get-Item $PSScriptRoot).parent.parent.FullName + '\' + $ProjectTemplateName + '\'

$PathTemplateTarget		= ([environment]::getfolderpath("mydocuments") + '\' + $VisualStudioVersion + '\Templates\ProjectTemplates\' + $ProjectTemplateName + '.zip')

$FileList				= New-Object Collections.Generic.List[String]

$FileList.Add($PathTemplate + '\Track.Svr.png')
$FileList.Add($PathTemplate + '\Track.Svr.vstemplate')
$FileList.Add($PathTemplate + '\Track.Svr.sqlproj')

$FileList.Add($PathProject + 'Track.Svr.ReadMe.md')
$FileList.Add($PathProject + 'Microsoft.SSISDB.dacpac')

$FileList.Add($PathProject + 'track\Procedures\track.Insert_ProcedureLogOrphan.sql')
$FileList.Add($PathProject + 'track\Tables\track.ProcedureLogBegin.sql')
$FileList.Add($PathProject + 'track\Tables\track.ProcedureLogEnd.sql')
$FileList.Add($PathProject + 'track\Tables\track.ProcedureLogErrors.sql')
$FileList.Add($PathProject + 'track\Tables\track.ProcedureLogOrphans.sql')
$FileList.Add($PathProject + 'track\Views\track.ProcedureLog.sql')
$FileList.Add($PathProject + 'track\Views\track.SqlAgentHistory.sql')
$FileList.Add($PathProject + 'track\Views\track.SqlAgentSchedule.sql')
$FileList.Add($PathProject + 'track\Views\track.SqlAgentScheduleBase.sql')
$FileList.Add($PathProject + 'track\Views\track.SsisCatalogTasks.sql')
$FileList.Add($PathProject + 'track\track.sql')

Compress-Archive -Path $FileList -DestinationPath $PathTemplateTarget -Force

Write-Host 'Compressed project template file:'
Write-Host $PathTemplateTarget