﻿Write-Host '--------------------------------------------------------------------------------------------------------------------------------------------'
Write-Host 'Deploying SSDT Snippets...'

$VisualStudioVersion	= $args[0]


$PathProject			= (Get-Item $PSScriptRoot).parent.FullName + '\'

$PathSnippetSource		= $PathProject + 'Snippets\*'
$PathSnippetTarget		= [environment]::getfolderpath("mydocuments") + '\' + $VisualStudioVersion + '\Code Snippets\SQL_SSDT\My Code Snippets\'

Write-Host 'Copying snippets...'
Copy-Item -Path $PathSnippetSource -Destination $PathSnippetTarget -Recurse -Force

Write-Host 'Done! Snippet files:'
Write-Host $PathSnippetTarget
