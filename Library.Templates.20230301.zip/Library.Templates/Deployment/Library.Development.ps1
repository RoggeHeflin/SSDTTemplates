﻿Write-Host '--------------------------------------------------------------------------------------------------------------------------------------------'
Write-Host 'Deploying SSDT Project Template: Library.Development...'

$VisualStudioVersion	= $args[0]
$ProjectTemplateName	= $args[1]

$PathTemplate			= $PSScriptRoot + '\' + $ProjectTemplateName + '\'
$PathProject			= (Get-Item $PSScriptRoot).parent.parent.FullName + '\' + $ProjectTemplateName + '\'

$PathTemplateTarget		= ([environment]::getfolderpath("mydocuments") + '\' + $VisualStudioVersion + '\Templates\ProjectTemplates\' + $ProjectTemplateName + '.zip')

$FileList				= New-Object Collections.Generic.List[String]

$FileList.Add($PathTemplate + '\Library.Development.png')
$FileList.Add($PathTemplate + '\Library.Development.vstemplate')
$FileList.Add($PathTemplate + '\Library.Development.sqlproj')

$FileList.Add($PathProject + 'Library.Development.ReadMe.md')

$FileList.Add($PathProject + 'Deployment\Script.PostDeployment.sql')
$FileList.Add($PathProject + 'Deployment\dim\insert.dim.CalendarDates.sql')

$FileList.Add($PathProject + 'Development\Script.sql')

$FileList.Add($PathProject + 'clc\clc.sql')
$FileList.Add($PathProject + 'dim\dim.sql')
$FileList.Add($PathProject + 'dim\Functions\dim.HierarchyPrefix.sql')
$FileList.Add($PathProject + 'dim\Functions\dim.Select_CalendarDates.sql')
$FileList.Add($PathProject + 'dim\Tables\dim.Calendar.sql')
$FileList.Add($PathProject + 'doc\doc.sql')
$FileList.Add($PathProject + 'doc\Views\doc.TableProperties.sql')
$FileList.Add($PathProject + 'fct\fct.sql')
$FileList.Add($PathProject + 'rpt\rpt.sql')
$FileList.Add($PathProject + 'stg\stg.sql')

Compress-Archive -Path $FileList -DestinationPath $PathTemplateTarget -Force

Write-Host 'Compressed project template file:'
Write-Host $PathTemplateTarget