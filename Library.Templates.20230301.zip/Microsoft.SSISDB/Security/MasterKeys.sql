﻿CREATE MASTER KEY ENCRYPTION BY PASSWORD= N'npoiWkwdptpYoo %gq{ch^tgmsFT7_&#$!~<Zpfcewzopmcc';

