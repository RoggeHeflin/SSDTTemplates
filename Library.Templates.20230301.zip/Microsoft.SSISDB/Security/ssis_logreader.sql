﻿CREATE ROLE [ssis_logreader]
    AUTHORIZATION [dbo];


GO
