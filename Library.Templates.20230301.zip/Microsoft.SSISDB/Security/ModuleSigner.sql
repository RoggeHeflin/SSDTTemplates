﻿CREATE USER [ModuleSigner] FOR CERTIFICATE [MS_SQLISSigningCertificate];

