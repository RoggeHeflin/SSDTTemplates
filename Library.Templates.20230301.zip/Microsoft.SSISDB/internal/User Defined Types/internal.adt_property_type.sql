﻿CREATE TYPE [internal].[adt_property_type]
    FROM NVARCHAR (50) NULL;

