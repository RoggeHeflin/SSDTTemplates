﻿CREATE TYPE [internal].[adt_custom_event_name]
    FROM NVARCHAR (1024) NULL;

