﻿CREATE TYPE [internal].[adt_sid]
    FROM VARBINARY (85) NOT NULL;

