﻿CREATE TYPE [internal].[adt_sname]
    FROM NVARCHAR (128) NOT NULL;

