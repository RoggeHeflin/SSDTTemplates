﻿CREATE TYPE [internal].[adt_sub_component]
    FROM NVARCHAR (200) NULL;

